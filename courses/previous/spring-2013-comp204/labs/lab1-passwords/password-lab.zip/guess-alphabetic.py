import sys
import random
import time
import math

def random_alphabetic_character():
    return chr(random.randrange(ord('a'), ord('z')+1))

def random_alphabetic_string(length):
    random_characters = []
    for i in range(length):
        random_characters.append(random_alphabetic_character())
    return ''.join(random_characters)

def usage():
    print "Error: This program expected a single numeric commandline argument.  Exiting."
    sys.exit()
    

if len(sys.argv) != 2:
    usage()

password_length = sys.argv[1]
if not password_length.isdigit():
    usage()

password_length = int(password_length)


password = raw_input('Enter a %d-character alphabetic password (using all lowercase letters): ' % password_length)
if not password.isalpha() or not password.islower() or len(password) != password_length:
    print "That wasn't a %d-character alphabetic lowercase password. Exiting."  % password_length
    sys.exit()

done = False
start_time = time.time()
while not done:
    guess = random_alphabetic_string(password_length)
    if guess == password:
        elapsed_time = time.time() - start_time
        print 'I guessed your password after %.2f seconds' % elapsed_time
        done = True


