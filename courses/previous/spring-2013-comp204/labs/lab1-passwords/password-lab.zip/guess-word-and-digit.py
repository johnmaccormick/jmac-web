import sys
import random
import time

with open('words.txt', 'r') as content_file:
    content = content_file.read()
words = content.split()
wordset = set(words)
num_words = len(words)
print 'Finished loading dictionary of', num_words, 'English words.'

password = raw_input('Enter an English word followed by a single numeric digit as your password: ')     #####
password_word = password[:-1]     #####
password_digit = password[-1:]    #####

if password_word not in wordset or not password_digit.isdigit():
    print "Sorry, that word isn't an English word followed by a single numeric digit. Exiting."   #####
    sys.exit()

done = False
start_time = time.time()
while not done:
    guess_word = words[random.randrange(num_words)]
    guess_number = str(random.randrange(10))  #####
    guess = guess_word + guess_number
    if guess == password:
        elapsed_time = time.time() - start_time
        print 'I guessed your password after %.2f seconds' % elapsed_time
        done = True

