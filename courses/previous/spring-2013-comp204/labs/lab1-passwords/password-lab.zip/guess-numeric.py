import sys
import random
import time
import math

def usage():
    print "Error: This program expected a single numeric commandline argument.  Exiting."
    sys.exit()
    

if len(sys.argv) != 2:
    usage()

password_length = sys.argv[1]
if not password_length.isdigit():
    usage()

password_length = int(password_length)

password = raw_input('Enter a %d-digit numeric password: ' % password_length)
if not password.isdigit() or len(password) != password_length:
    print "That wasn't a %d-digit numeric password. Exiting." % password_length
    sys.exit()

numeric_password = int(password)
done = False
start_time = time.time()
max_password = math.pow(10,password_length)
while not done:
    guess = random.randrange(max_password)
    if guess == numeric_password:
        elapsed_time = time.time() - start_time
        print 'I guessed your password after %.2f seconds' % elapsed_time
        done = True
