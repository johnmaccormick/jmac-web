import sys
import random
import time

with open('words.txt', 'r') as content_file:
    content = content_file.read()
words = content.split()
wordset = set(words)
num_words = len(words)
print 'Finished loading dictionary of', num_words, 'English words.'

password = raw_input('Enter an English word as your password: ')
if password not in wordset:
    print "Sorry, that word isn't in my dictionary. Exiting."
    sys.exit()

done = False
start_time = time.time()
while not done:
    guess = words[random.randrange(num_words)]
    if guess == password:
        elapsed_time = time.time() - start_time
        print 'I guessed your password after %.2f seconds' % elapsed_time
        done = True

