
/**
 * This class is intended to be used by meteorologists who are recording
 * weather conditions at various locations over a long period of time.
 * The information stored about each site observation includes the location,
 * the date, the current temperature and the current wind speed.
 * This class also provides various methods for changing the wind speed,
 * for determining whether or not it is cold, and for calculating the windchill.
 * 
 * @author Tim Wahls
 * @author (YOUR NAME HERE) 
 * @version (PUT DATE HERE)
 */
public class SiteObservation
{
	// declare your fields here

	/**
	 * Create a site observation with the specified location, date, temperature
	 * and wind speed.
	 */
	public SiteObservation(String initLocation, String initDate, int initTemperature,
	                       int initWindSpeed)
	{
		// add your code here
	}

	/**
	 * get the location of the observation
	 * @return the location of the observation
	 */
	public String getLocation()
	{
		// replace with your own code
		return "";
	}

	/**
	 * get the date of the observation
	 * @return the date of the observation
	 */
	public String getDate()
	{
		// replace with your own code
		return "";
	}

	/**
	 * get the temperature of the observation
	 * @return the temperature of the observation
	 */
	public int getTemperature()
	{
		// replace with your own code
		return 0;
	}

	/**
	 * get the wind speed of the observation
	 * @return the wind speed of the observation
	 */
	public int getWindSpeed()
	{
		// replace with your own code
		return 0;
	}
	
	/**
	 * increase the wind speed by the specified amount
	 * @param speed the amount to increase the wind speed by
	 */
	public void increaseWindSpeed(int speed) {
	    // add your code here
	}
	
	/**
	 * an observation is considered cold if the temperature is 32 degrees
	 * Fahrenheit or less
	 * @return whether or not the observation is cold
	 */
	public boolean isCold() {
		// replace with your own code
		return false;
	}
	
	/**
	 * Calculate the windchill from the temperature and wind speed.
	 * See the assignment sheet for a description of how windchill is
	 * calculated.
	 * @return the windchill for the observation
	 */
	public int calculateWindchill() {
		// replace with your own code
	    return 0;
	}
}
