/**
 * simple representation of bank accounts
 * 
 * @author Tim Wahls
 * @date 2/16/2006
 */

public class Account {
    private int balance; // in pennies
    private int interestRate; // in pct.
   
    /**
     * Constructor for an Account with a specified
     * account number and interest rate.
     * @param balance the balance.
     * @param initInterestRate the interest rate.
     */
    public Account(int balance, int interestRate) {
        this.balance = balance;
        this.interestRate = interestRate;
    }
    
    
    /**
     *  deposit money into the account
     *  @param depAmount the amount to deposit
     */
    public void deposit(int depAmount) {
        balance = balance + depAmount;
    }
    
    /** 
     * withdraw money from the account
     * @param withAmount the amount to withdraw
     */
    public void withdraw(int withAmount) {
        if (balance >= withAmount) {
           balance = balance - withAmount;
        } else {
           System.out.println("Error: there are only " + balance +
                              " cents in this account!");
        }
    } 

    /** 
     * check the account balance (an accessor method)
     * @return the account balance
     */
    public int getBalance() {
        return balance;
    }
    
    /**
     * display the account number and balance on the screen
     */
    public void print() {
      System.out.println("Balance is: $" + (balance / 100) + "." + 
                        (balance % 100) / 10 + "" + (balance % 100) % 10 + ".");
    }
    
    
    public static void main(String[] args) {
           int initBalance = Integer.parseInt(args[0]);
           int initInterest = Integer.parseInt(args[1]);
           int withdrawAmount = Integer.parseInt(args[2]);
           Account account = new Account(initBalance, initInterest);
           account.withdraw(withdrawAmount);
           int newBalance = account.getBalance();
           System.out.println("New balance is " + newBalance);
     }

}
