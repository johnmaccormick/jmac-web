

/**
 * The test class CoinTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class CoinTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class CoinTest
     */
    public CoinTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	public void testConstructor()
	{
		Coin coin1 = new Coin("testType", 1902, "mint", 22.22);
		assertEquals("mint", coin1.getCondition());
		assertEquals("testType", coin1.getType());
		assertEquals(22.22, coin1.getValue(), 0.5);
		assertEquals(1902, coin1.getYear());
	}

	public void testSetValue()
	{
		Coin coin1 = new Coin("test", 1999, "fair", 22.22);
		coin1.setValue(45.67);
		assertEquals(45.67, coin1.getValue(), 0.5);
	}

	public void testToString()
	{
		Coin coin1 = new Coin("test", 1998, "fair", 12.34);
		assertEquals("Type : test\nYear : 1998\nCondition : fair\nValue : 12.34\n", coin1.toString());
	}
}



