
/**
 * Write a description of class NestedFor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NestedFor
{
    
    public NestedFor()
    {
    }

    public void doNestedLoop1()
    {
        for (int i=0; i<3; i++) {
            System.out.println("apple");
            System.out.println("banana");
            for (int j=0; j<4; j++) {
                System.out.print("chocolate!! ");
            }
            System.out.println("donut");            
        }
    }    
    
    public void doNestedLoop2()
    {
        int[] numbers = new int[3];
        
        numbers[0] = 6;
        numbers[1] = 7;
        numbers[2] = 8;
        
        for (int i=0; i<3; i++) {
            for (int j=0; j<3; j++) {
                System.out.println(numbers[i] + "," + numbers[j]);
            }
        }
    }
}
