

/**
 * The test class AccountTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class AccountTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class AccountTest
     */
    public AccountTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	public void testConstructor()
	{
		Account account1 = new Account(5, 10, 100);
		assertEquals(100, account1.getBalance(), 0.001);
		assertEquals(10, account1.getHighInterestRate(), 0.001);
		assertEquals(5, account1.getLowInterestRate(), 0.001);
		assertEquals(1000.0, account1.getThreshold(), 0.001);
	}

	public void testPrintFutureBalance()
	{
		Account account1 = new Account(5, 10, 100);
		account1.printFutureBalance(1);
	}

	public void testAddAnnualInterest()
	{
		Account account1 = new Account(5, 10, 100);
		account1.addAnnualInterest(1);
		assertEquals(105, account1.getBalance(), 0.001);
		Account account2 = new Account(5, 10, 2000);
		account2.addAnnualInterest(1);
		assertEquals(2200, account2.getBalance(), 0.001);
		Account account3 = new Account(5, 10, 10000);
		account3.addAnnualInterest(3);
		assertEquals(13310, account3.getBalance(), 0.001);
	}
}



