import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

/**
 * The DiseaseSimulator class runs a simulation of disease 
 * spreading. This simulator uses an SEIR model. In this model 
 * each person in the population is either Susceptible, Exposed,
 * Infectious or Removed.  Susceptible (S) people have a specified 
 * probability of being infected with the disease when one of 
 * their neighbors has the disease. Exposed (E) people are those that have
 * been infected with the disease but are not yet capable of 
 * spreading the disease to others. Infectious (I) people have the disease
 * and are capable of spreading it to their neighbors. Removed (R) people
 * have either recovered from the disease and are now immune or they have
 * died from the disease. 
 * 
 * @author Grant Braught
 * @version July 14, 2005
 */
public class DiseaseSimulator
{

    private static final int DELAY=150;
    
    private Population pop;
    private Disease disease;
    private String name;
    private PopulationDisplay popGui;
    private DataTable dataTable;
    
    private javax.swing.Timer stepTimer = null;
    private javax.swing.Timer trialTimer = null;
    
    /**
     * Create a new DiseaseSimulator object. 
     * 
     * @param disease the Disease that is spreading within the Population.
     * @param population the Population through which the Disease is spreading.
     * @param name a name for this DiseaseSimulator.
     */
    public DiseaseSimulator(Disease disease, Population population, String name) {
        this.disease = disease;
        this.name = name;
        pop = population;
        popGui = new PopulationDisplay(pop, name);
        dataTable = new DataTable(name);
    }
    
    /**
     * Get the name of this DiseaseSimulator.
     * 
     * @return the name of this DiseaseSimulator.
     */
    public String getName() {
        return name;
    }
    
    /**
     * Display the graphical representation of the population.
     * Note that graphical representation is nice for seeing what
     * is going on. However, the simulation runs much faster when the
     * graphical representation is not shown.
     */
    public void showGUI() {   
        pop.addObserver(popGui);
        //pop.notifyObservers();
        popGui.update(null,null);
        popGui.setVisible(true);
        
        /**
        int x = popGui.getX();
        int y = popGui.getY();
        try {
            Robot rob = new Robot();
            rob.mouseMove(x+5,y+5);
            Thread.sleep(500);
            rob.mousePress(InputEvent.BUTTON1_MASK);
            rob.mouseRelease(InputEvent.BUTTON1_MASK);
        }
        catch (Exception e) {
        }
        */
    }
    
    /**
     * Hide the graphical representation of the population.
     * Note that graphical representation is nice for seeing what
     * is going on. However, the simulation runs much faster when the
     * graphical representation is not shown. 
     */
    public void hideGUI() {
        popGui.hide();
        pop.deleteObservers();
    }
    
    /**
     * Display the data table that shows the results of the
     * last set of trials that have been run.  Note that
     * only results obtained by calls to the runTrials
     * method are displayed in the data table.
     */
    public void showDataTable() {
        dataTable.show();
    }
    
    /**
     * Hide the data table.
     */
    public void hideDataTable() {
        dataTable.hide();
    }
    
    /**
     * Advance the simulation by a single day.
     */
    public synchronized void step() {
        pop.update(disease);
    }
    
    /**
     * Advance the simulation by a specified number of days.
     * 
     * @param days the number of days by which to 
     * advance the simulation.
     */
    public synchronized void step(int days) {
        
        if (stepTimer == null) {    // Don't allow concurrent runs.
            EpiRun runner = new EpiRun(days);
            int delay = 1;
            if (popGui.isShowing()) {
                delay = DELAY;
            }
            stepTimer = new javax.swing.Timer(delay, runner);
            stepTimer.start();
        }
    }
    
    /**
     * Run the specified number of trials, each with the specified
     * number of days. The results of each trial will be displayed
     * in the data table.  To see the data table, call the showDataTable
     * method.
     * 
     * @param days the number of days in each trial.
     * @pram trials the number of trials to run.
     */
    public synchronized void runTrials(int days, int trials) {
        if (trialTimer == null) {   // Don't allow concurrent runs.
            dataTable.clear();
            pop.reset();
            TRun runner = new TRun(days, trials);
            trialTimer = new javax.swing.Timer(1, runner);
            trialTimer.start();
        }
    }
    
    class TRun implements ActionListener {
        private int steps;
        private int trials;
        private int t;
        private int n;
        
        private double[] pctSus;
        private double[] pctExp;
        private double[] pctInf;
        private double[] pctQuar;
        private double[] pctRem;
        private double[] pctEIQR;
        
        public TRun(int steps, int trials) {
            this.steps = steps;
            this.trials = trials;
            t=1;
            n=0;
            
            pctSus = new double[trials];
            pctExp = new double[trials];
            pctInf = new double[trials];
            pctQuar = new double[trials];
            pctRem = new double[trials];
            pctEIQR = new double[trials];
        }
        
        public void actionPerformed(ActionEvent e) {
            if (t <= trials) {
                if (n < steps) {
                    n++;
                    step();
                
                    if (popGui.isShowing()) {
                        trialTimer.setDelay(DELAY);
                    }
                    else {
                        trialTimer.setDelay(1);
                    }
                }
                else {
                    pctSus[t-1] = pop.getPercentSusceptible();
                    pctExp[t-1] = pop.getPercentExposed();
                    pctInf[t-1] = pop.getPercentInfectious();
                    pctQuar[t-1] = pop.getPercentQuarantined();
                    pctRem[t-1] = pop.getPercentRecovered();
                    pctEIQR[t-1] = pctExp[t-1] + pctInf[t-1] + pctQuar[t-1] + pctRem[t-1];
                    
                    dataTable.append(t, 
                        pctSus[t-1],
                        pctExp[t-1],
                        pctInf[t-1],
                        pctQuar[t-1],
                        pctRem[t-1],
                        pctEIQR[t-1]
                        );
                    dataTable.invalidate();
                    
                    n=0;
                    t++;
                    
                    if (t <= trials) {
                        pop.reset();
                    }
                }
            }
            else {
                trialTimer.stop();
                trialTimer = null;
                
                dataTable.appendSummary("Mean:", 
                    BasicStatistics.getMean(pctSus),
                    BasicStatistics.getMean(pctExp),
                    BasicStatistics.getMean(pctInf),
                    BasicStatistics.getMean(pctQuar),
                    BasicStatistics.getMean(pctRem),
                    BasicStatistics.getMean(pctEIQR));
                dataTable.appendSummary("Standard Deviation:", 
                    BasicStatistics.getStdDev(pctSus),
                    BasicStatistics.getStdDev(pctExp),
                    BasicStatistics.getStdDev(pctInf),
                    BasicStatistics.getStdDev(pctQuar),
                    BasicStatistics.getStdDev(pctRem),
                    BasicStatistics.getStdDev(pctEIQR));                    
                    
                dataTable.invalidate();
                
                showDataTable();
            }
        }
    }
    
    /*
     * NOTE: Class name obfuscated because the network file system is limiting 
     * file names to 32 characters for silly technical reasons.
     */
    class EpiRun implements ActionListener {
        private int steps;
        private int n;
        
        public EpiRun(int steps) {
            this.steps = steps;
            n = 0;
        }
        
        public void actionPerformed(ActionEvent e) {
            if (n < steps) {
                n++;
                step();
                
                if (popGui.isShowing()) {
                    stepTimer.setDelay(DELAY);
                }
                else {
                    stepTimer.setDelay(1);
                }
            }
            else {
                stepTimer.stop();
                stepTimer = null;
                showGUI();
            }
        }
    }
}
