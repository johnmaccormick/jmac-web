import javax.swing.*;
import java.awt.*;

/**
 * Write a description of class PersonDisplay here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PersonDisplay extends JPanel 
{
    private int state;
    
    public void setState(int state) {
        this.state = state;
    }
 
    public void paintComponent(Graphics g) {
        
        Color bgColor = Color.red;
        
        if (state == Person.SUSCEPTIBLE) {
            bgColor = Color.white;
        }
        else if (state == Person.EXPOSED) {
            bgColor = Color.green;
        }
        else if (state == Person.INFECTIOUS) {
            bgColor = Color.yellow;
        }
        else if (state == Person.REMOVED) {
            bgColor = Color.black;
        }
        else if (state == Person.QUARANTINED) {
            bgColor = Color.cyan;
        }
        
        g.setColor(bgColor);
        g.fill3DRect(0,0,10,10,true);
    }
    
    public Dimension getPreferredSize() {
        return new Dimension(10,10);
    }
    
    public Dimension getMaximumSize() {
        return getPreferredSize();
    }
    
    public Dimension getMinimumSize() {
        return getPreferredSize();
    }
}