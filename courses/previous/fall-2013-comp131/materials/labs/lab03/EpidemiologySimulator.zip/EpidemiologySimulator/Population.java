import java.util.*;

/**
 * The Population class represents a population of individuals
 * among which a disease is spreading. The individuals are 
 * arranged in a lattice with periodic boundries (i.e. a torus);
 * A torus is used to ensure that all people have an equal number
 * of neighbors.
 * 
 * @author Grant Braught
 * @version July 14, 2005
 */
public class Population extends Observable
{
    private Person[][] pop;
    private boolean useQuarantine;
    private int rows;
    private int columns;
    private int day;
    
    /**
     * Create a new Population object.  By default this Population object
     * will not use quarantining. Initially all individuals, save one,
     * are in the Susceptible state. The remaining individual is in the
     * Exposed state.
     */
    public Population() {
        useQuarantine = false;
        rows = 25;
        columns = 25;
        reset();
    }
    
    /**
     * Create a new Population object. Initially all individuals, save one,
     * are in the Susceptible state. The remaining individual is in the
     * Exposed state.
     * 
     * @param useQuarantine true if people should be quarantined when they
     * show symptoms of infection.
     */
    public Population(boolean useQuarantine) {
        this.useQuarantine = useQuarantine; 
        rows = 25;
        columns = 25;
        reset();
    }
    
    /**
     * Reset the population so that all but one of the people are 
     * in the susceptable state and one is in the exposed state.
     */
    public void reset() {
        day = 0;
                
        /*
         * Fill the population with individuals who are
         * all in the SUSCPEPTABLE state.
         */
        pop = new Person[rows][columns];
        for (int i=0; i<pop.length; i++) {
            for (int j=0; j<pop[0].length; j++) {
                pop[i][j] = new Person();    
            }
        }
        
        /*
         * Put in one person who is in the EXPOSED state
         * to get things started.
         */
        pop[pop.length/2][pop[0].length/2] = new Person(Person.EXPOSED);
        
        setChanged();
        notifyObservers();
    }
    
    /**
     * Get the percentage of the population that is currently
     * in the susceptible state.
     *
     * @return the percentage of the population in the susceptible state.
     */
    public double getPercentSusceptible() {
        return countState(Person.SUSCEPTIBLE);
    }
    
    /*
     * Find the percentage of people that are in the specified state.
     */
    private double countState(int state) {
        int cnt = 0;
        for (int i=0; i<pop.length; i++) {
            for (int j=0; j<pop[0].length; j++) {
                if (pop[i][j].getState() == state) {
                    cnt++;
                }
            }
        }
        return cnt / ((double) pop.length * pop[0].length) * 100;
    }
    
    /**
     * Get the percentage of the population that is currently
     * in the exposed state.
     * 
     * @return the percentage of the population in the exposed state.
     */
    public double getPercentExposed() {
        return countState(Person.EXPOSED);
    }
    
    /**
     * Get the percentage of the population that is currently 
     * in the infectious state.
     * 
     * @return the percentage of the population in the infected state.
     */
    public double getPercentInfectious() {
        return countState(Person.INFECTIOUS);
    }
    
    /**
     * Get the percentage of the population that is currently quarantined.
     * 
     * @return the percentage of the population that is quarantined.
     */
    public double getPercentQuarantined() {
        return countState(Person.QUARANTINED);
    }
    
    /**
     * Get the percentage of the population that has recovered from
     * the population.
     * 
     * @return the percentage of the population that has recovered.
     */
    public double getPercentRecovered() {
        return countState(Person.REMOVED);
    }
    
    /**
     * Get the current Day of simulation for this Population. A population begins at
     * Day 0 and the Day is incremented each time the update 
     * method is called.
     * 
     * @return the day for this Population.
     */
    public int getDay() {
        return day;
    }
    
    /**
     * Get the Person at location i, j.
     * 
     * @return the Person at location i,j.
     */
    public Person getPerson(int i, int j) {
        return pop[i][j];
    }
    
    /**
     * Get the number of rows of people in this Population.
     * 
     * @return the number of rows in this Population.
     */
    public int getRows() {
        return rows;
    }
    
    /**
     * Get the number of columns of people in this Population.
     * 
     * @return the number of columns in this Population.
     */
    public int getColumns() {
        return columns;
    }
    
    /**
     * Update this Population to the next time step.  During each update
     * each Person in the population comes into contact with each of their
     * neighbors.  Note that the update is done asynchronously, meaning that
     * every Person is updated before the Population is updated.
     */
    public void update(Disease disease) {
        
        day++;
        Person[][] newPop = new Person[pop.length][pop[0].length];
        
        for (int i=0; i<pop.length; i++) {
            for (int j=0; j<pop[0].length; j++) {
                newPop[i][j] = updatePerson(i,j, disease);
            }
        }
        
        pop = newPop;
        
        setChanged();
        notifyObservers();
    }   
    
    /*
     * Update an individual person.  If quarantining is being used 
     * and the person is showing symptoms then they are quarantined.
     */
    private Person updatePerson(int i, int j, Disease disease) {
        Person p = (Person) pop[i][j].clone();
         
        ArrayList hood = getNeighbors(i,j);       
        p.tick(hood, disease); 
        
        /*
         * See if the person should be quarantined.
         */
        if (useQuarantine) {
            if (p.hasSymptoms()) {
                p.quarantine();
            }
        }
        
        return p;
    }
    
    /*
     * Get the collection of Person objects that are 
     * neighbors of the Person at location i,j.
     */
    private ArrayList getNeighbors(int i, int j) {
        
        ArrayList hood = new ArrayList();
        
        /*
         * Go from one row above the current row to one row
         * below the current row.
         */
        for (int ii=i-1; ii<=i+1; ii++) {
            int row = ii;
            /*
             *  Handle the wrap around from top to bottm and
             *  bottom to top.
             */
            if (row < 0) {
                row = pop.length-1;
            }
            else if (row >= pop.length) {
                row = 0;
            }
            
            /*
             * Go from one column left of the current column to
             * one column right of the current column.
             */
            for (int jj=j-1; jj<=j+1; jj++) {    
                int col = jj;
                
                /*
                 * Handle the wrap around from left to right 
                 * and right to left.
                 */
                if (col < 0) {
                    col = pop[0].length - 1;
                }
                else if (col >= pop[0].length) {
                    col = 0;
                }
                
                /*
                 * Skip the actual person being considered.
                 */
                if (! (row == i && col == j)) {
                    /*
                     * If quarantineing is not being used or the person
                     * is not quarantined then add them as a neighbor.
                     * Otherwise, leave out any neighbor that has been
                     * quarantined.
                     */
                    if (!useQuarantine || !pop[row][col].isQuarantined()) {
                        hood.add(pop[row][col]);
                    }
                }
            }
        }
        
        return hood;
    }
}
