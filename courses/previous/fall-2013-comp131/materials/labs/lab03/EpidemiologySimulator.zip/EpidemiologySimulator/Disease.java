
/**
 * This class represents a particular Disease.  Each
 * disease has its own infectivity, latency period and
 * infectious period.
 * 
 * @author Grant Braught 
 * @version July 14, 2005
 */
public class Disease
{
    private int infectivity;
    private int incubationPeriod;
    private int latencyPeriod;
    private int infectiousPeriod;
    
    /**
     * Create a new Disease object. 
     * 
     * @param infectivity the percent of susceptible individuals that will 
     * become infected when exposed to an infectious person on a given day.
     * @param incubationPeriod the number of days before an infected person
     * begins to show symptoms indicating that they are infected.
     * @param latencyPeriod the number of days before an infected person
     * become infectious and can pass on the infection.
     * @param infectiousPeriod the number of days that a person remains
     * infectious before recovering and becoming immune (or dying).
     */
    public Disease(int infectivity, int incubationPeriod, 
                    int latencyPeriod, int infectiousPeriod) {      
        this.infectivity = infectivity;
        this.incubationPeriod = incubationPeriod;
        this.latencyPeriod = latencyPeriod;
        this.infectiousPeriod = infectiousPeriod;
    }
    
    /**
     * Create a default disease object.
     */
    public Disease() {
        infectivity = 30;
        incubationPeriod = 6;
        latencyPeriod = 4;
        infectiousPeriod = 2;
    }
    
    /**
     * Get the infectivity of this Disease.
     * 
     * @return the infectivity of this Disease.
     */
    public int getInfectivity() {
        return infectivity;
    }
    
    /**
     * Get the incubation period for this Disease.
     * 
     * @return the incubation period for this Disease.
     */
    public int getIncubationPeriod() {
        return incubationPeriod;
    }
    
    /**
     * Get the latency period for this Disease.
     * 
     * @return the latency period for this Disease.
     */
    public int getLatencyPeriod() {
        return latencyPeriod;
    }
    
    /**
     * Get the infectious period for this Disease.
     * 
     * @return the infectious period for this Disease.
     */
    public int getInfectiousPeriod() {
        return infectiousPeriod;
    }
}
