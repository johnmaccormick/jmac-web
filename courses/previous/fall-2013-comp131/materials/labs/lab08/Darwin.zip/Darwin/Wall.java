/** @author Tim Wahls <br>
    purpose: walls in Darwin's world <br>
    @version 7/13/2005 */
   
public class Wall {
  private int x, y; // coordinates

  public Wall(int xpos, int ypos) {
    x = xpos;
    y = ypos;
  }

  public int getXPos() {return x;}
  public int getYPos() {return y;}

  public static void main(String argv[]) {
  }
}
