

/**
 * The test class SongTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SongTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class SongTest
     */
    public SongTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

    public void testConstructor()
    {
        Song song1 = new Song("Paint the Sky", "master.mp3", "Great Big Sea", "Road Rage", 5);
        assertEquals("Road Rage", song1.getAlbumName());
        assertEquals("Paint the Sky", song1.getSongName());
        assertEquals("Great Big Sea", song1.getArtistName());
        assertEquals("master.mp3", song1.getFileName());
        assertEquals(5, song1.getRating());
    }
}

