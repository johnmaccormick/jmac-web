import java.util.ArrayList;

/**
 * A class that maintains information about an arbitrarily large 
 * play list of songs to be played by an audio player.  Individual 
 * songs may be accessed based on the order that they are inserted.  
 * 
 * @author Grant Braught, Tim Wahls, Louis Ziantz
 * @author (YOUR NAME HERE)
 * @version (PUT DATE HERE)
 */
public class PlayList {

    // Declare your fields here.

    /**
     * Creates a new PlayList.
     * 
     * @initListName the name of the PlayList.
     */
    public PlayList(String initListName) {
        // Fill in code here for the constructor.
    }
    
    /**
     * Returns the name of the PlayList.
     * 
     * @return the name of the PlayList.
     */
    public String getPlayListName() { 
        return "";  // replace this return with correct code
    }
    
    /**
     * Returns the number of songs in the PlayList.
     * 
     * @return the number of songs in the PlayList.
     */
    public int getNumSongs() { 
        return -1;  // replace this return with correct code
    }

    /**
     * Rename this PlayList to the newName.
     * 
     * @param newName the new name of this PlayList.
     */
    public void setPlayListName(String newName) {
        // add your code here.
    }
    
    /**
     * Returns true if a given Song is in the PlayList.
     * When comparing songs, two songs are considered to be the same
     * if they have the same song name, artist name and album name and
     * rating.
     * 
     * @param searchSong The Song to search for in the PlayList.
     * @return true if the given Song is in the list; false otherwise.
     */
    public boolean containsSong(Song searchSong) {
        return false;   // replace this return with correct code
    }
    
    /**
     * Adds a Song to the PlayList if it does not already exist
     * in the list.  Returns true if the Song was successfully added;
     * false if the Song could not be added since it already appeared
     * in the list.
     * 
     * @param song The Song to be added to the PLayList.
     * @return true if the Song was added successfully; false otherwise.
     */
    public boolean addSong(Song song) {  
        return false;  // replace this return with correct code
    }

    /**
     * Returns the Song at the indicated position in the PlayList. 
     * Prints an error message and returns null if the specified 
     * position is not valid.
     * 
     * @param position The position in the play list of the song to be returned.
     * @return the Song at the given position in the PlayList; null
     * if the position is outside the valid range.
     */
    public Song getSongAtPosition(int position) {
        return null;    // replace this return with correct code
    }
        
    /**
     * Returns true if the PlayList is empty; false otherwise.
     * 
     * @return true if the PlayList is empty; false otherwise.
     */
    public boolean isEmpty() { 
        return false;   // replace this return with correct code
    }
    
    /**
     * Removes the Song at the indicated position in the PlayList.
     * Print a message if the position is not valid.
     * 
     * @param position The position in the PlayList of the Song to be removed.
     */
    public void removeSongAtPosition(int position) {
        //add your code here       
    }
    
    /**
     * Get the average rating of the songs in this PlayList.
     * The average is always rounded down to the nearest 
     * integer (e.g. 3.8 becomes 3). If the list is empty
     * then this method returns -1.
     * 
     * @return the average rating of the songs.
     */
    public int getAverageRating() {
        return -1;  // replace this return with correct code
    }
    
    /**
     * Get index the index at which the specified song is stored.
     * If the specified song is not in the collection or the 
     * collection is empty then return -1.
     * 
     * @return the index of the song or -1.
     */
    public int getIndexOfSong(Song searchSong) {
        return -1;  // replace this return with correct code
    }
    
    /**
     * Returns a new PlayList containing all songs from this PlayList
     * with the given artist name.  Returns an empty list if there are 
     * no songs by the specified artist.
     * 
     * @param newListName The name of the new sub list.
     * @param searchArtistName The name of the artist whose Songs are to appear 
     * in the returned PlayList.
     * @return a PlayList containing all songs from the current PlayList
     * that have the given artist's name; the returned list is empty if
     * no such Song exists.
     */
    public PlayList subListByArtist(String newListName, 
                                    String searchArtistName) {
        return null; // replace this return with correct code
    }

    /**
     * Return a new PlayList containing all Songs from this PlayList
     * with the given rating or better.  Returns an empty list if no such
     * Song exists.
     * 
     * @param newListName The name of the new PlayList.
     * @param searchRating The minimum rating of songs to appear in 
     * the returned PlayList.
     * @return a PlayList containing all Songs from the current PlayList
     * with the given rating or better; an empty list is returned if
     * no Song with the given rating or higher is found.
     */
    public PlayList subListByRating(String newListName, 
                                    int searchRating) {
        return null; // replace this return with correct code
    }
    
    /**
     * Print a list of the names of all of the Songs in this PlayList.
     * If there are no songs in this PlayList then this method prints
     * "No Songs in list."
     */
    public void printSongNames() {
        // add your code here.
    }
    
    /**
     * Print the complete information about each Song in this playlist.
     * If there are no songs in this PlayList then this method prints
     * "No Songs in list."
     */
    public void print() {
        // add your code here.
    }
    
    /**
     * Bonus: Shuffle the playlist.  The list can be suffled by repeating the
     * following process N times where N is the number of songs in the PlayList.
     *   Get the Song at a random location
     *   Remove that song from the PlayList 
     *   Add it back into the playlist at the end.
     *   
     * If you choose to complete this Bonus you will need to read 
     * about the Random class on-line or in the textbook.
     * 
     * Leave this method here even if you elect not to complete the bonus.
     * 
     * Whether you choose to complete the bonus or not you will need to include
     * a test case that calls this method in order for WebCAT to give you full 
     * credit for achieving statement coverage for your program.
     */
    public void shuffle() {
        System.out.println("Shuffle not implemented."); // Change this to correct code.
    }
}
