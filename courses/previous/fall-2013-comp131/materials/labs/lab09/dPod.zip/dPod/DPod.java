import java.lang.reflect.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * DPod is the main control program for the DPod.  It
 * creates the GUI and provides the hooks into the 
 * DPodMP3File for playing the songs.
 * 
 * @author Grant Braught
 * @version October 2006
 */
public class DPod
{
    private DPodGUI theGUI;
    
    private DPodMP3File playingSong;
    
    private PlayList masterPlayList;
    private ArrayList<PlayList> playLists;
    
    private boolean playingInMPL;
    private boolean playingInPL;
    private boolean playingPL;
    
    public DPod() {
        addJars();  // Add mp3 libraries to the classpath.
        
        readAllFiles();  
        
        playingInMPL = false;
        playingInPL = false;
        playingPL = false;
        
        theGUI = new DPodGUI(this);
        theGUI.showGUI();
    }
    
    public void saveAllFiles() {
  
        // Save the master playlist
        writePlayListToFile("MasterPlayList.txt", masterPlayList);
        
        // Save the list of playlists
        writePlayListListToFile();
        
        // Save the contents of each playlist.
        for (int i=0; i<playLists.size(); i++) {
            PlayList pl = playLists.get(i);
            writePlayListToFile(pl.getPlayListName() + ".txt", pl);
        }
    }
    
    public void readAllFiles() {
        
        masterPlayList = readPlayListFromFile("MasterPlayList.txt");
        if (masterPlayList == null) {
            // No master playlist! Gotta start from scratch.
            masterPlayList = new PlayList("Master PlayList");
            playLists = new ArrayList<PlayList>();
        }
        else {
            ArrayList<String> listNames = readPlayListListFromFile();
            playLists = new ArrayList<PlayList>();
            if (listNames != null) {
                // Read the playlists...
                for (int i=0; i<listNames.size(); i++) {
                    String filename = listNames.get(i) + ".txt";
                    playLists.add(readPlayListFromFile(filename));
                }
            }
        }
    }
    
    /**
     * Read contents of playlist from a file. Ideally this would be in 
     * the PlayList class but the student's haven't dealt with I/O yet so
     * it is in here.
     */
    private PlayList readPlayListFromFile(String filename) {

        try {
            BufferedReader in = new BufferedReader(new FileReader(filename));
            String listName = in.readLine();
            PlayList newList = new PlayList(listName);
            String name;
            while ((name = in.readLine()) != null) {
                String file = in.readLine();
                String artist = in.readLine();
                String album = in.readLine();
                String rating = in.readLine();
                int intRating = Integer.parseInt(rating);
                Song newSong = new Song(name, file, artist, album, intRating);
                newList.addSong(newSong);
            }
            in.close();
            return newList;
            
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Write out a playlist to a text file.
     */
    private void writePlayListToFile(String filename, PlayList theList) {
                     
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter(filename));
            out.write(theList.getPlayListName() + "\n");
            
            for (int i=0; i<theList.getNumSongs(); i++) {
                Song song = theList.getSongAtPosition(i);
                out.write(song.getSongName() + "\n");
                out.write(song.getFileName() + "\n");
                out.write(song.getArtistName() + "\n");
                out.write(song.getAlbumName() + "\n");
                out.write(song.getRating() + "\n");
            }
            out.close();
        } catch (IOException e) {
        }
    }
    
    private void writePlayListListToFile() {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("PlayListList.txt"));
            
            for (int i=0; i<playLists.size(); i++) {
                PlayList pl = playLists.get(i);
                out.write(pl.getPlayListName() + "\n");
            }
            out.close();
        } catch (IOException e) {
        }
    }
    
    private ArrayList<String> readPlayListListFromFile() {
        try {
            ArrayList<String> theList = new ArrayList<String>();
            
            BufferedReader in = new BufferedReader(new FileReader("PlayListList.txt"));
            String name;
            while ((name = in.readLine()) != null) {
                theList.add(name);
            }
            in.close();
            return theList;
            
        } catch (Exception e) {
            return null;
        }
    }
    
    public PlayList getMPL() {
        return masterPlayList;
    }
    
    public ArrayList<PlayList> getPlayLists() {
        return playLists;
    }
    
    private void sortPlayList(PlayList theList, Comparator<Song> comp) {
        // Should really be a method in the PlayList class but the students
        // haven't dealt with sorting yet.  So it's hacked in here.
        Song[] songList = new Song[theList.getNumSongs()];
        for (int i=0; i<songList.length; i++) {
            songList[i] = theList.getSongAtPosition(0);
            theList.removeSongAtPosition(0);
        }
        
        Arrays.sort(songList, comp);

        for (int i=0; i<songList.length; i++) {
            theList.addSong(songList[i]);
        }
    }
    
    private void sortPlayLists(Comparator<PlayList> comp) {
        PlayList[] theList = new PlayList[playLists.size()];
        for (int i=0; i<theList.length; i++) {
            theList[i] = playLists.get(0);
            playLists.remove(0);
        }
        
        Arrays.sort(theList, comp);

        for (int i=0; i<theList.length; i++) {
            playLists.add(theList[i]);
        }
    }
    
    private boolean playListWithNameExists(String name) {
        for (PlayList pl : playLists) {
            if (pl.getPlayListName().equals(name)) {
                return true;
            }
        }
        return false;
    }
    
    /*
     * dPod menu stuff.
     */
    

    public void addSongToMPL() {
        AddSongDialog asd = new AddSongDialog(theGUI, true);
        asd.setVisible(true);
        
        if (!asd.addWasCancelled() && asd.addIsValid()) {
            Song newSong = new Song(asd.getSongName(), asd.getFileName(), asd.getArtistName(), asd.getAlbumName(), 0);
            masterPlayList.addSong(newSong);
        }
        
        sortMPLByName();
    }
    
    public void deleteSongFromMPL(int index) {
        // Need to account for the ripple effect through all of the playlists.
        System.out.println("Deleting Song from MPL not yet implemented.");
    }
    
    public void sortMPLByName() {
        sortPlayList(masterPlayList, new SongNameComparator());
    }
    
    public void sortMPLByRating() {
        sortPlayList(masterPlayList, new SongRatingComparator());
    }
    
    private class SongNameComparator implements Comparator<Song> {
        public int compare(Song o1, Song o2) {
            return o1.getSongName().compareToIgnoreCase(o2.getSongName());
        }
    }
    
    private class SongRatingComparator implements Comparator<Song> {
        public int compare(Song o1, Song o2) {
            if (o1.getRating() > o2.getRating()) {
                return 1;
            }
            else if (o1.getRating() < o2.getRating()) {
                return -1;
            }
            else {
                return 0;
            }
        }
    }
    
    public void sortPlayListsByName() {
        System.out.println("Sorting PlayLists by name not yet implemented.");
    }
    
    public void sortPlayListsByRating() {
        System.out.println("Sorting PlayLists by average rating not yet implemented.");
    }
    
    public void printMPLNames() {
        masterPlayList.printSongNames();
    }
    
    public void printMPL() {
        masterPlayList.print();
    }

    /*
     * PlayList menu stuff.
     */
    
    public boolean newEmptyPlayList(String listName) {
        if (!playListWithNameExists(listName)) {
            playLists.add(new PlayList(listName));
            sortPlayLists(new PlayListNameComparator());
            return true;
        }
        else {
            return false;
        }   
    }
    
    public boolean newPlayListByArtist(String artistName) {
        String listName = "Songs by " + artistName;
        if (!playListWithNameExists(listName)) {
            playLists.add(masterPlayList.subListByArtist(listName, artistName));
            sortPlayLists(new PlayListNameComparator());
            return true;
        }
        else {
            return false;
        }
    }
    
    private class PlayListNameComparator implements Comparator<PlayList> {
        public int compare(PlayList o1, PlayList o2) {
            return o1.getPlayListName().compareToIgnoreCase(o2.getPlayListName());
        }
    }
    
    public boolean newPlayListByRating(int rating) {
        String listName = rating + " Star Songs";
        if (!playListWithNameExists(listName)) {
            playLists.add(masterPlayList.subListByRating(listName, rating));
            sortPlayLists(new PlayListNameComparator());
            return true;
        }
        else {
            return false;
        }
    }
        
    public void deletePlayList(int playListIndex) {
        playLists.remove(playListIndex);
    }
    
    public boolean renamePlayList(int playListIndex, String listName) {
        if (!playListWithNameExists(listName)) {
            playLists.get(playListIndex).setPlayListName(listName);
            sortPlayLists(new PlayListNameComparator());
            return true;
        }
        else {
            return false;
        }
    }
    
    public boolean addSongToPlayList(int songIndex, int playListIndex) {
        PlayList pl = playLists.get(playListIndex);
        Song song = masterPlayList.getSongAtPosition(songIndex);
        if (!pl.containsSong(song)) {
            pl.addSong(song);
            return true;
        }
        else {
            return false;
        }
    }
    
    public void removeSongFromPlayList(int songIndex, int playListIndex) {
        PlayList pl = playLists.get(playListIndex);
        pl.removeSongAtPosition(songIndex);
    }
    
    public void sortSongsInPlayListByName(int playListIndex) {
        System.out.println("Sort songs by name not yet implemented");
    }
    
    public void sortSongsInPlayListByRating(int playListIndex) {
        System.out.println("Sort Songs by rating not yet implemented");
    }
    
    public void shufflePlayList(int playListIndex) {
        PlayList pl = playLists.get(playListIndex);
        pl.shuffle();
    }
    
    public void printSongNames(int playListIndex) {
        playLists.get(playListIndex).printSongNames();
    }
    
    public void printSongs(int playListIndex) {
        playLists.get(playListIndex).print();
    }
    
    /*
     * Song Menu stuff...
     */
    
    public void setSongRating(int songIndex, int newRating) {
        masterPlayList.getSongAtPosition(songIndex).setRating(newRating);
    }
    
    public void printSongInformation(int songIndex) {
        System.out.println(masterPlayList.getSongAtPosition(songIndex));
    }
    
    /*
     * Controls menu stuff... 
     */
    
    public void playSongInMPL(int songIndex) {
        if (playingSong != null) {
            System.out.println("Tried to playSongInMPL when already playing another song.");
            System.exit(-1);
        }
        else {
            playingInMPL = true;
            Song song = masterPlayList.getSongAtPosition(songIndex);
            playingSong = new DPodMP3File(song.getFileName(), this);
            theGUI.setPlayingLine(song.getSongName() + " from Master PlayList.");
            playingSong.start();
        }
    }
    
    public void playSongInPL(int songIndex, int playListIndex) {
        if (playingSong != null) {
            System.out.println("Tried to playSongInPL when already playing another song.");
            System.exit(-1);
        }
        else {
            playingInPL = true;
            PlayList pl = playLists.get(playListIndex);
            Song song = pl.getSongAtPosition(songIndex);
            playingSong = new DPodMP3File(song.getFileName(), this);
            theGUI.setPlayingLine(song.getSongName() + " from PlayList " + pl.getPlayListName() + ".");
            playingSong.start();
        }
    }
    
    public void playPlayList(int playListIndex) {
        if (playingSong != null) {
            System.out.println("Tried to playPL when already playing another song.");
            System.exit(-1);
        }
        else {
            if (theGUI.selectFirstSongInActivePL()) {
                playingPL = true;
                int plIndex = theGUI.getPlayListListIndex(); 
                playSongInPL(0, plIndex);
            }
        } 
    }
    
    public void pauseResumePlayback() {
        if (playingSong == null) {
            System.out.println("Tried to pause/resume when no song is playing.");
            System.exit(-1);
        }
        else {
            playingSong.pauseSong();
        }
    }
    
    public void skipToNext() {
        if (playingSong == null) {
            System.out.println("Tried to skip to next with no song playing.");
            System.exit(-1);
        }
        else {
            playingSong.stopSong();
            playingSong = null;
            if (playingInMPL) {
                int songIndex = theGUI.selectNextSongInMPL();
                playSongInMPL(songIndex);
            }
            else if (playingInPL || playingPL) {
                int songIndex = theGUI.selectNextSongInActivePL();
                int plIndex = theGUI.getPlayListListIndex(); 
                playSongInPL(songIndex, plIndex);
            }
            else {
                System.out.println("Tried to skip to next but playing?? flag not set.");
                System.exit(-1);
            }
        }
    }
    
    public void skipToPrev() {
        if (playingSong == null) {
            System.out.println("Tried to skip to prev with no song playing.");
            System.exit(-1);
        }
        else {
            playingSong.stopSong();
            playingSong = null;
            if (playingInMPL) {
                int songIndex = theGUI.selectPrevSongInMPL();
                playSongInMPL(songIndex);
            }
            else if (playingInPL || playingPL) {
                int songIndex = theGUI.selectPrevSongInActivePL();
                int plIndex = theGUI.getPlayListListIndex();
                playSongInPL(songIndex, plIndex);
            }
            else {
                System.out.println("Tried to skip to prev but playing?? flag not set.");
                System.exit(-1);
            }
        }
    }
         
    public void stopPlayback() {
        if (playingSong == null) {
            System.out.println("Tried to stopPlayback when no song is playing.");
            System.exit(-1);
        }
        else {
            playingSong.stopSong();
            theGUI.setGUINotPlaying();
            theGUI.setPlayingLine("none");
            playingSong = null;
            playingInMPL = false;
            playingInPL = false;
            playingPL = false;
        }
    }
    
    /**
     * Gets called from the DPodMP3File when it finishes playing normally.
     */
    public void playFinished() {
        if (playingInMPL) {
            if (theGUI.getSelectedIndexInMPL() < masterPlayList.getNumSongs() - 1) {
                skipToNext();
            }
            else {
                stopPlayback();
            }
        }
        else if (playingInPL || playingPL) {
            int plIndex = theGUI.getPlayListListIndex();
            if (theGUI.getSelectedIndexInPL() < playLists.get(plIndex).getNumSongs() - 1) {
                skipToNext();
            }
            else {
                stopPlayback();
            }
        }
        else {
            System.out.println("Got a callback after playing but playing?? flag not set.");
            System.exit(-1);
        }
    }
    
    /*
     * Need to invoke this first thing so that the libraries
     * are on the classpath.  This is a hack to get the code
     * to work within BlueJ without requiring students to 
     * edit the CLASSPATH.  Note: using the +libs directory
     * as described on the BlueJ site did not work.
     */
    private static void addJars() {
        try {
            if (!libsLoaded()) {
                addFile("mp3libs/jl1.0.jar");
                addFile("mp3libs/mp3spi1.9.4.jar");
                addFile("mp3libs/tritonus_share.jar");
            }
        }
        catch (IOException e) {
            System.out.println("Missing one of the library files needed " +
            "to play MP3 files.");
            System.out.println(e);
            System.exit(-1);
        }
    }
    
    public static boolean libsLoaded() {
        //Get the System Classloader
        ClassLoader sysClassLoader = ClassLoader.getSystemClassLoader();

        //Get the URLs
        URL[] urls = ((URLClassLoader)sysClassLoader).getURLs();

        boolean jlLoaded = false;
        boolean mp3Loaded = false;
        boolean tritonusLoaded = false;
        
        for(int i=0; i< urls.length; i++)
        {
            jlLoaded = jlLoaded || urls[i].getFile().contains("jl1.0.jar");
            mp3Loaded = mp3Loaded || urls[i].getFile().contains("mp3spi1.9.4.jar");
            tritonusLoaded = tritonusLoaded || urls[i].getFile().contains("tritonus_share.jar");
        }
        
        return jlLoaded && mp3Loaded && tritonusLoaded;
    }
    
    /*
     * The code below adds files to the classpath of the JVM at
     * runtime.  This is necessary to get JVM started by BlueJ
     * to pickup the MP3 libraries. 
     * 
     * This code was copied from:
     * http://forum.java.sun.com/thread.jspa?threadID=300557&start=0&tstart=0
     */
    
    private static final Class[] parameters = new Class[]{URL.class};
    
    private static void addFile(String s) throws IOException {
        File f = new File(s);
        addFile(f);
    }
 
    private static void addFile(File f) throws IOException {
        //MMC (4/2011): replaced next line of code to remove call to deprecated method File:toURL().
        // addURL(f.toURL());
        addURL(f.toURI().toURL());
    }
 
    private static void addURL(URL u) throws IOException {
        
        URLClassLoader sysloader = (URLClassLoader)ClassLoader.getSystemClassLoader();
        //MMC (4/2011): added <?> to the line below to remove an "unchecked call to getDeclaredMethod()" warning later
        Class<?> sysclass = URLClassLoader.class;
 
        try {
            Method method = sysclass.getDeclaredMethod("addURL",parameters);
            method.setAccessible(true);
            method.invoke(sysloader,new Object[]{ u });
        } catch (Throwable t) {
            t.printStackTrace();
            throw new IOException("Error, could not add URL to system classloader");
        }    
    }
}
