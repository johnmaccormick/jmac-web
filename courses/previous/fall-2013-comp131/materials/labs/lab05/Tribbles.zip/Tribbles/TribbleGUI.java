/**<CODE>TribbleGUI</CODE> provides a graphical user interface to simulate a
*a world of tribbles in. It provides the user with easy access to information
*as well as a way to step through each day of the simulation.
*@author Sean Shappell
*@author Dickinson College
*@version 1.0
**/

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.util.*;

public class TribbleGUI extends JFrame {
  //public constants for the simulation
  /**The maximum age of any given Tribble**/
  public static final int MAXAGE = 5;
  /**The number of days the simulation will run**/
  public static final int NUMDAYS = 20;
  /**The width of the simulation world**/
  public static final int XSIZE = 75;
  /**The height of the simulation world**/
  public static final int YSIZE = 15;
  /**The size of the tribble**/
  public static final int TSIZE = 20;
 
  //private constants
  //the width of the world canvas
  private static final int WORLDX = (XSIZE*10)+(TSIZE*2);
  //the height of the world canvas
  private static final int WORLDY = (YSIZE*10)+(TSIZE*2);
  //the width of the world panel
  private static final int WPX = WORLDX+10;
  //the height of the world panel
  private static final int WPY = WORLDY+10;
  
  
  //swing components
  private JTable dayData;
  private JPanel dayPanel;
  private JPanel endPanel;
  private JScrollPane endSP;
  private JTextPane endTextArea;
  private JPanel initialPanel;
  private JScrollPane initialSP;
  private JTextPane initialTextArea;
  private JButton simulate;
  private Canvas worldCanvas;
  private JPanel worldPanel;
  
  //button click state
  private static boolean started = false;
  
  //list of all the tribbles in the world
  private ArrayList<Tribble> world;
  
  //the day in the simulation
  private int day;
  // the total number of tribbles (living and dead)
  private int numTribbles;
  // the number of dead tribbles
  private int numDead;
  
  /**Creates a new TribbleGUI**/
  public TribbleGUI() {
    initComponents();
    day = 0;
    numTribbles = 0;
    numDead = 0;
  }
  
  private void initComponents() {
    //layout manager
    GridBagConstraints gridBagConstraints;
    
    //initialize all swing components
    worldPanel = new JPanel();
    dayPanel = new JPanel();
    dayData = new JTable();
    initialPanel = new JPanel();
    initialSP = new JScrollPane();
    initialTextArea = new JTextPane();
    endPanel = new JPanel();
    endSP = new JScrollPane();
    endTextArea = new JTextPane();
    simulate = new JButton();
    worldCanvas = new TribbleWorld(this);
    
    //set they layout for the main window
    getContentPane().setLayout(new GridBagLayout());
    
    //set the properties of the main window
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    setTitle("Tribble Simulator");
    setResizable(false);
    
    //add a listener to the main window to listen for quit clicks
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent evt) {
        exitForm(evt);
      }
    });
    
    //set the properties of the world panel
    worldPanel.setBorder(new CompoundBorder(new TitledBorder("Tribble World"), 
    new EmptyBorder(new Insets(1, 
                               1, 
                               1, 
                               1))));
    worldPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
    worldPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
    worldPanel.setFocusable(false);
    worldPanel.setMaximumSize(new Dimension(WPX, WPY));
    worldPanel.setMinimumSize(new Dimension(WPX, WPY));
    
    //set they layour of the world panel
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;
    gridBagConstraints.gridheight = GridBagConstraints.RELATIVE;
    gridBagConstraints.anchor = GridBagConstraints.NORTHWEST;
    gridBagConstraints.weightx = 1.0;
    gridBagConstraints.insets = new Insets(10, 10, 10, 5);
    
    //add the world panel to the main window
    getContentPane().add(worldPanel, gridBagConstraints);
    
    //set the world canvas properties
    worldCanvas.setSize(WORLDX,WORLDY);
    
    //add the world canvas to the world panel
    worldPanel.add(worldCanvas);
    
    //set the day panel properties
    dayPanel.setLayout(new BoxLayout(dayPanel, BoxLayout.Y_AXIS));
    dayPanel.setBorder(new CompoundBorder(new TitledBorder("Today"), 
    new EmptyBorder(new Insets(3, 
                               3, 
                               3, 
                               3))));
    dayPanel.setAlignmentY(Component.LEFT_ALIGNMENT);
    dayPanel.setMaximumSize(new Dimension(200, 200));
    dayPanel.setMinimumSize(new Dimension(200, 75));
    dayPanel.setName("Today");
    dayPanel.setPreferredSize(new Dimension(200, 75));
    
    //set the day data table properties
    dayData.setBackground(new Color(204, 204, 204));
    dayData.setModel(new DefaultTableModel(
    new Object [][] {
      {"Day", null},
      {"Total Tribbles", null},
      {"Living Tribbles", null}
    },
    new String [] {
      "", ""
    }
    ) {
      Class[] types = new Class [] {
        java.lang.String.class, java.lang.Integer.class
      };
      boolean[] canEdit = new boolean [] {
        false, false
      };
      
      public Class getColumnClass(int columnIndex) {
        return types [columnIndex];
      }
      
      public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit [columnIndex];
      }
    });
    dayData.setFocusable(false);
    dayData.setMinimumSize(new Dimension(150, 48));
    dayData.setRequestFocusEnabled(false);
    dayData.setRowSelectionAllowed(false);
    dayData.setShowHorizontalLines(false);
    dayData.setShowVerticalLines(false);
    
    //add the day data table to the day panel
    dayPanel.add(dayData);
    
    //set the layout of the day panel
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    gridBagConstraints.gridheight = GridBagConstraints.RELATIVE;
    gridBagConstraints.anchor = GridBagConstraints.NORTH;
    gridBagConstraints.insets = new Insets(10, 5, 0, 10);
    
    //add the day panel to the main window
    getContentPane().add(dayPanel, gridBagConstraints);
    
    //set the properties of the initial information panel
    initialPanel.setLayout(new BoxLayout(initialPanel, BoxLayout.Y_AXIS));
    initialPanel.setBorder(new CompoundBorder(new TitledBorder("Initial World " 
    + "State"), 
    new EmptyBorder(new Insets(5, 
                               5, 
                               5,
                               5))));
    initialPanel.setFocusable(false);
    initialPanel.setMaximumSize(new Dimension(500, 500));
    initialPanel.setMinimumSize(new Dimension(250, 125));
    
    //set the properties of the initial information scroll panel
    initialSP.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    initialSP.setAlignmentX(Component.LEFT_ALIGNMENT);
    initialSP.setAlignmentY(Component.LEFT_ALIGNMENT);
    initialSP.setDoubleBuffered(true);
    initialSP.setMinimumSize(new Dimension(268, 103));
    
    //set the properties of the initial information text area
    initialTextArea.setEditable(false);
    initialTextArea.setAlignmentX(Component.LEFT_ALIGNMENT);
    initialTextArea.setAlignmentY(Component.LEFT_ALIGNMENT);
    initialTextArea.setMinimumSize(new Dimension(250, 100));
    initialTextArea.setPreferredSize(new Dimension(250, 100));
    
    //add the initial information text area to the initial information scroll
    //panel
    initialSP.setViewportView(initialTextArea);
    
    //add the initial information scroll panel to the initial information panel
    initialPanel.add(initialSP);
    
    //set the layout for the initial information panel
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 2;
    gridBagConstraints.gridheight = GridBagConstraints.REMAINDER;
    gridBagConstraints.fill = GridBagConstraints.BOTH;
    gridBagConstraints.weightx = 1.0;
    gridBagConstraints.insets = new Insets(5, 10, 10, 10);
    
    //add the initial information panel to the main window
    getContentPane().add(initialPanel, gridBagConstraints);
    
    //set the properties of the end information panel
    endPanel.setLayout(new BoxLayout(endPanel, BoxLayout.Y_AXIS));
    endPanel.setBorder(new CompoundBorder(new TitledBorder("End World State"), 
    new EmptyBorder(new Insets(5, 
                               5, 
                               5, 
                               5))));
    endPanel.setFocusable(false);
    endPanel.setMinimumSize(new Dimension(288, 137));
    
    //set the properties of the end information scroll panel
    endSP.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    endSP.setAlignmentX(Component.LEFT_ALIGNMENT);
    endSP.setMinimumSize(new Dimension(268, 103));
    
    //set the properties of the end information text area
    endTextArea.setEditable(false);
    endTextArea.setAlignmentX(Component.LEFT_ALIGNMENT);
    endTextArea.setAlignmentY(Component.LEFT_ALIGNMENT);
    endTextArea.setMinimumSize(new Dimension(250, 100));
    endTextArea.setPreferredSize(new Dimension(250, 100));
    
    //add the end information text area to the end information scroll panel
    endSP.setViewportView(endTextArea);
    
    //add the end information scroll panel to the end information panel
    endPanel.add(endSP);
    
    //set the layout for the end information panel
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 2;
    gridBagConstraints.gridheight = GridBagConstraints.REMAINDER;
    gridBagConstraints.fill = GridBagConstraints.BOTH;
    gridBagConstraints.weightx = 1.0;
    gridBagConstraints.insets = new Insets(5, 10, 10, 5);
    
    //add the end information panel to the main window
    getContentPane().add(endPanel, gridBagConstraints);
    
    //set the properties for the simulate button
    simulate.setText("Start");
    simulate.setAlignmentY(Component.LEFT_ALIGNMENT);
    simulate.setHorizontalTextPosition(SwingConstants.CENTER);
    
    //add an action listener to listen for a button click
    simulate.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        buttonClick(evt);
      }
    });
    
    //set the layout for the simulate button
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
    gridBagConstraints.gridheight = GridBagConstraints.REMAINDER;
    gridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstraints.insets = new Insets(0, 25, 0, 25);
    
    //add the simulate button to the main window
    getContentPane().add(simulate, gridBagConstraints);
    
    //pack the main window
    pack();
  }
  
  //determines the actions to take for each click of the simulate button
  //depending on its current state
  private void buttonClick(ActionEvent evt) {
    //if the simulation has not yet started or has ended
    if(!started) {
      //set that the simulation has started
      started = true;
      
      //initialize a new ArrayList to hold the list of tribbles
      world = new ArrayList<Tribble>();
      
      //set the day to the first day
      day = 1;
      
      //add five new tribbles to the simulation
      numTribbles++;
      world.add(new Tribble(numTribbles, "red", 24, 10));
      numTribbles++;
      world.add(new Tribble(numTribbles, "green", 25, 5));
      numTribbles++;
      world.add(new Tribble(numTribbles));
      numTribbles++;
      world.add(new Tribble(numTribbles, "magenta", 60, 12));
      numTribbles++;
      world.add(new Tribble(numTribbles, "cyan", 45, 7));
            
      //clear the text areas
      initialTextArea.setText(null);
      endTextArea.setText(null);
      
      //print the state of the world initially
      initialTextArea.setText(print());
      
      //set the values of day data table
      dayData.setValueAt(String.valueOf(0),0,1);
      dayData.setValueAt(String.valueOf(numTribbles),1,1);
      dayData.setValueAt(String.valueOf(numTribbles - numDead),2,1);
      
      //set the graphical representation of the world
      worldCanvas.repaint();
      
      //change the text of the simulate button to represent a running state
      simulate.setText("Next Day");
    }
    //if the simulation is running and the number of days is less than the max
    else if (day <= NUMDAYS && (numTribbles - numDead) > 0) {
      //allow tribbles to reproduce
      reproduce();
      //allow tribbles to age and die
      ageAndDie();
      //allow tribbles to move
      move();
      
      //update the values of day data table
      dayData.setValueAt(String.valueOf(day),0,1);
      dayData.setValueAt(String.valueOf(numTribbles),1,1);
      dayData.setValueAt(String.valueOf(numTribbles - numDead),2,1);
      
      //update the graphical representation of the world
      worldCanvas.repaint();
      
      //change the text of the simulate button to represent an ending state
      if(day == NUMDAYS || (numTribbles - numDead) <= 0) {
        simulate.setText("End");
      }
      
      //add one to the number of days simulated
      day++;
    }
    //if the simulation has completed
    else {
      //set that the simulation has ended
      started = false;
      
      //print the state of the world at the end
      endTextArea.setText(print());
      
      //change the text of the simulate button to represent a non-running state
      simulate.setText("Start");
      
      //reset all of the tribble static variables in the Tribble class
      numTribbles = 0;
      numDead = 0;
    }
  }
  
  /**
  *Returns the <code>String</code> representation of the tribbles in the current
  *state of the simulation.
  *@return
  *A string representation of each tribble in the world. The format is that
  *specified in the <code>toString</code> method of the <code>Tribble</code>
  *class.   
  **/   
  public String print() {
    if(numTribbles - numDead > 0) {
      String tmp = "";
      
      ListIterator<Tribble> li = world.listIterator();
      while (li.hasNext()) {
        tmp = tmp + li.next().toString() + "\n";
      }
      
      return tmp;
    }
    else {
      return "All the Tribbles have died!!";
    }
  }
  
  /**
  *Iterates through all of the tribbles in the simulation and gives each
  *one a 20% chance of reproducing.
  *<dt><b>Postcondition:</b><dd>
  *Any offspring are added to the simulation.
  **/
  public void reproduce() {
    ListIterator<Tribble> li = world.listIterator();
    Tribble t;
    
    while (li.hasNext()) {
      t = li.next();
      if (Math.random() > 0.8) {
        numTribbles++;
        li.add(new Tribble(numTribbles, t.getColor(),
               t.getXPos(), t.getYPos()));
      }
    }
  }
  
  /**
  *Iterates through all of the tribbles in the simulation and ages each by one
  *day.
  *<dt><b>Postcondition:</b><dd>
  *All tribbles are one day older. Tribbles over <code>MAXAGE</code> old are 
  *removed from the simulation.
  **/
  public void ageAndDie() {
    ListIterator<Tribble> li = world.listIterator();
    Tribble t;
    
    while (li.hasNext()) {
      t = li.next();
      t.age();
      if (t.getAge() > MAXAGE) {
        numDead++;
        li.remove();
      }
    }
  }
  
  /**
  *Moves the passed tribble in one of 8 possible directions with equal
  *probability.
  *@param <code>t</code>
  *A tribble to move.
  *<dt><b>Postcondition:</b><dd>
  *The tribble occupies the new (or same) location in the world.
  **/
  private static void moveTribble(Tribble t) {
    double coin;
    coin = Math.random();
    if (coin < 0.125) {
      t.moveLeft();
      t.moveLeft();
    } else if (coin < 0.25) {
      t.moveLeft();
      t.moveUp();
    } else if (coin < 0.375) {
      t.moveUp();
      t.moveUp();
    } else if (coin < 0.5) {
      t.moveUp();
      t.moveRight();
    } else if (coin < 0.625) {
      t.moveRight();
      t.moveRight();
    } else if (coin < 0.75) {
      t.moveRight();
      t.moveDown();
    } else if (coin < 0.875) {
      t.moveDown();
      t.moveDown();
    } else {
      t.moveDown();
      t.moveLeft();
    }
  }
  
  /**
  *Iterates through all of the tribbles in the simulation and moves each one.
  *<dt><b>Postcondition:</b><dd>
  *Each tribble is in the location determined by its call to the <code>
  *moveTribble</code> method.
  **/
  public void move() {
    // post: all Tribbles in the world move
    ListIterator<Tribble> li = world.listIterator();
    
    while (li.hasNext()) {
      moveTribble(li.next());
    }
  }
  
  /**
  *Return the <code>ArrayList</code> containing the tribbles in the
  *simulation.
  *@return
  *An <code>ArrayList</code> containing the tribbles in the simulation.     
  **/   
  public ArrayList<Tribble> getTribbles() {
    return world;
  }
  
  public static boolean isStarted() {
    return started;
  }
  
  //quit the application
  private void exitForm(WindowEvent evt) {
    System.exit(0);
  }
  
  public void display() {
      setVisible(true);
  }
  
  public static void main(String args[]) {
    //set the look and feel
    try {
      UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
    } 
    catch (Exception e) { 
      System.out.println(e);
    }
    
    //create and show the GUI  
    new TribbleGUI().setVisible(true);
  }
  
  //TribbleWorld is an extension of the canvas class the provides a graphical
  //representation of the tribbles' world.
  private class TribbleWorld extends Canvas {
    //the GUI with which the world is associated
    private TribbleGUI tg;
    
    //create a new tribble world
    public TribbleWorld(TribbleGUI initTg) {
      tg = initTg;
      
      setBackground(Color.WHITE);
      setForeground(Color.BLACK);
    }
    
    //paints the tribbles in the world based on the current world state
    public void paint(Graphics g) {
      if(TribbleGUI.isStarted()) {
        //convert the Graphics object to a Graphics2D object
        Graphics2D g2 = (Graphics2D) g;
        
        //get the ArrayList of all the tribbles in the world
        ArrayList tribbles = tg.getTribbles();
        
        //a temporary tribble
        Tribble t;
        
        //tribble coordinates
        int x;
        int y;
        
        //for every tribble in the list
        for(int i = 0; i < tribbles.size(); i++) {
          //assign the tribble to the temporary tribble
          t = (Tribble)tribbles.get(i);
          
          //set the tribble's color and stroke
          g2.setPaint(translateColor(t.getColor()));
          
          //get the tribbles coordinates
          x = (t.getXPos()*10)+(TribbleGUI.TSIZE/2);
          y = (t.getYPos()*10)+(TribbleGUI.TSIZE/2);
          
          //draw the tribble
          g2.fill(new Ellipse2D.Double(x, 
                                       y, 
                                       TribbleGUI.TSIZE, 
                                       TribbleGUI.TSIZE));
          
          //set the text color                             
          g2.setPaint(Color.BLACK);
          
          //draw the tribble's number
          g2.drawString(String.valueOf(t.getNumber()), x, y);
        }
      }
    }
      
    //Returns the Color object associated with the passed color. The Color 
    //object will have an alpha value of 100.
    private Color translateColor(String color) {
      if(color.equals("black")) {
        return Color.BLACK;
      }
      else if(color.equals("blue")) {
        return new Color(Color.BLUE.getRed(),   
        Color.BLUE.getGreen(),
        Color.BLUE.getBlue(),
        100);
      }
      else if(color.equals("cyan")) {
        return new Color(Color.CYAN.getRed(),   
        Color.CYAN.getGreen(),
        Color.CYAN.getBlue(),
        100);
      }
      else if(color.equals("gray")) {
        return new Color(Color.GRAY.getRed(),   
        Color.GRAY.getGreen(),
        Color.GRAY.getBlue(),
        100);
      }
      else if(color.equals("green")) {
        return new Color(Color.GREEN.getRed(),   
        Color.GREEN.getGreen(),
        Color.GREEN.getBlue(),
        100);
      }
      else if(color.equals("magenta")) {
        return new Color(Color.MAGENTA.getRed(),   
        Color.MAGENTA.getGreen(),
        Color.MAGENTA.getBlue(),
        100);
      }
      else if(color.equals("orange")) {
        return new Color(Color.ORANGE.getRed(),   
        Color.ORANGE.getGreen(),
        Color.ORANGE.getBlue(),
        100);
      }
      else if(color.equals("pink")) {
        return new Color(Color.PINK.getRed(),   
        Color.PINK.getGreen(),
        Color.PINK.getBlue(),
        100);
      }
      else if(color.equals("red")) {
        return new Color(Color.RED.getRed(),   
        Color.RED.getGreen(),
        Color.RED.getBlue(),
        100);
      }
      else if(color.equals("yellow")) {
        return new Color(Color.YELLOW.getRed(),   
        Color.YELLOW.getGreen(),
        Color.YELLOW.getBlue(),
        100);
      }
      else {
        return new Color(Color.WHITE.getRed(),   
        Color.WHITE.getGreen(),
        Color.WHITE.getBlue(),
        100);
      }
    }
  }
}
