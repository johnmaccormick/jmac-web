/**
 * This class defines an object that can be used to compute what type of coffee
 * to buy on a particular day, and to keep track of how much has been spent on
 * coffee that day. The type of coffee drink to buy (for example, cappuccino or
 * latte) depends on the current temperature, and whether or not it is a
 * weekend. The constructor and methods for this class are described in detail
 * below.
 * 
 * @author John MacCormick
 * @author (YOUR NAME HERE)
 * @version (PUT DATE HERE)
 */
public class CoffeeCalculator {
    // declare your fields here

	/**
	 * This constructor creates a new CoffeeCalculator using the given initial
	 * temperature and a Boolean value specifying whether or not it is a
	 * weekend. The amount spent on coffee so far is initialized to zero.
	 */
	public CoffeeCalculator(int initTemperature, boolean initIsWeekend) {
        // add your code here
	}

	/**
	 * return the temperature.
	 */
	public int getTemperature() {
        // replace this code with your own
		return 0;
	}

	/**
	 * change the temperature to a new value.
	 */
	public void setTemperature(int newTemperature) {
        // add your code here
	}

	/**
	 * return whether or not it is a weekend.
	 */
	public boolean getIsWeekend() {
        // replace this code with your own
        return false;
	}

	/**
	 * return the amount spent on coffee so far today.
	 */
	public int getAmountSpent() {
        // replace this code with your own
        return 0;
	}

	/**
	 * The daily coffee budget is five dollars. This method returns true if the
	 * amount spent on coffee so far today is more than five dollars, and
	 * otherwise returns false.
	 */
	public boolean isOverBudget() {
        // replace this code with your own
        return false;
	}

	/**
	 * Return the type of coffee to be ordered based on current conditions. On
	 * weekends, the rule is simple: when the temperature is below 50, a latte
	 * is ordered; whereas if the temperature is 50 or above, a regular coffee
	 * is ordered. On weekdays, the rule is more complex: for temperatures below
	 * 40, a mocha is ordered; for temperatures between 40 and 70 inclusive, a
	 * cappuccino is ordered; and for temperatures above 70, an iced coffee is
	 * ordered. Note that capitalization and spelling is important, and this
	 * method should return one of the following coffee types: "mocha",
	 * "cappuccino", "iced coffee", "latte", "regular coffee".
	 */
	public String calculateCoffeeType() {
        // replace this code with your own
        return "";
	}

	/**
	 * Increase the amount spent so far on coffee by the discounted cost of one
	 * coffee. All coffees have the same base price, which is $2.75. However, a
	 * different discount is applied to the price of a coffee every time one is
	 * purchased. The parameter discountPercent specifies the amount of the
	 * discount as a percentage. For example, if discountPercent is 10, then
	 * the price of the coffee is discounted by 10%, so the discounted cost is
	 * $2.48. The amount of the discount is always rounded down to the nearest
	 * cent before it is subtracted from the base price.
	 */
	public void buyCoffee(int discountPercent) {
        // add your code here
	}

}
