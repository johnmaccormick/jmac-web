package singleton;

public class Apple extends Fruit {

}
