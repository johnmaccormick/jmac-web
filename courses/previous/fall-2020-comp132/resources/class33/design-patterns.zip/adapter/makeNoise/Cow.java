package adapter.makeNoise;

public class Cow implements MakesNoise {

	@Override
	public int getVolume() {
		return 12;
	}

}
