package adapter.farmyard;

import java.util.ArrayList;

import adapter.makeNoise.AdaptedSheep;
import adapter.makeNoise.Cow;
import adapter.makeNoise.Horse;
import adapter.makeNoise.MakesNoise;
import adapter.makeSounds.Sheep;

public class Farmyard {

	public static int howNoisy(ArrayList<MakesNoise> animals) {
		int totalVolume = 0;
		for (MakesNoise animal : animals) {
			totalVolume += animal.getVolume();
		}
		return totalVolume;
	}

	public static void main(String[] args) {
		Cow c1 = new Cow();
		Cow c2 = new Cow();
		Horse h1 = new Horse();

		ArrayList<MakesNoise> animals = new ArrayList<MakesNoise>();
		animals.add(c1);
		animals.add(c2);
		animals.add(h1);

		int totalNoise = howNoisy(animals);
		System.out.println(
				"Total amount of noise in the farmyard is " + totalNoise);
		
//		Sheep sheep = new Sheep();
//		AdaptedSheep adaptedSheep = new AdaptedSheep(sheep);
//		animals.add(adaptedSheep);
//		System.out.println("Even noisier with a sheep: " + howNoisy(animals));
	}

}
