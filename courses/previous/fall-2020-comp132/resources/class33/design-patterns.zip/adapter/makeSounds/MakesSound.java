package adapter.makeSounds;

public interface MakesSound {
    void makeSound();
    int howLoud();
}
