package adapter.makeSounds;


public class Sheep implements MakesSound {

	// fields, constructors, and methods for Sheep omitted

	// implementation of the MakesSound interface
	public void makeSound() {
		System.out.println("Baaaaa");
	}

	public int howLoud() {
		return 4;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
