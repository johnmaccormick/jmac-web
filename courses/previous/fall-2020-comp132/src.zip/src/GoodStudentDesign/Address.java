package GoodStudentDesign;


/**
 * A class representing an individual's home address. 
 * Note that if we happened to have another application,
 * maybe a banking system, that required keeping track
 * of individual's home addresses we could simply reuse
 * this class instead of writing new code!
 * 
 * @author Grant Braught
 * 
 */
public class Address
{
    private int houseNumber;
    private String streetName;
    private String city;
    private String state;
    private String zipCode;
    
    /*
     * The constructors, accessors and mutators have been 
     * intentionally omitted for this example.
     */
}
