package GoodStudentDesign;


/**
 * A class representing a Student.  This class improves on the
 * design shown in BadStudentDesign by using Composition to 
 * create the Student. Separate classes are used to represent
 * the Address and Courses.
 * 
 * @author Grant Braught
 * 
 */
public class Student
{
    // Student information.
    private String name;
    private int hubBox;
    private String studentID;

    // Student's home address information.
    private Address homeAddress;
    
    // Student's local address information.
    private Address localAddress;
    
    // Student's course information.
    private Course course1;
    private Course course2;
    private Course course3;
    private Course course4;
    
    /*
     * The constructors, accessors and mutators have been 
     * intentionally omitted for this example.
     */
}
