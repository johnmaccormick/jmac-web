
public class BasicFor {
	public static void main(String[] args) {
		
		System.out.println("Entering loop...");
		
		for (
			  int i = 0; 
				         i < 4; 
					             i++) {
			
			System.out.println(i);
			
		}
		
		System.out.println("Loop has terminated");
		
	}
}
