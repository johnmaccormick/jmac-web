package Bank;

/**
 * The test class AccountTest.
 *
 */
public class AccountTest extends junit.framework.TestCase
{
    private Account savingsAccount;

    /**
     * Default constructor for test class AccountTest
     */
    public AccountTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
        savingsAccount = new Account(23, 3);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

    public void testOneParamConstructor()
    {
    	Account someAccount = new Account(242);
        assertEquals(242, someAccount.getAccountNumber());
        assertEquals(0, someAccount.getBalance());
        assertEquals(2, someAccount.getInterestRate());
    }
    
    public void testNoParamConstructor()
    {
        Account someAccount = new Account();
        assertEquals(0, someAccount.getAccountNumber());
        assertEquals(0, someAccount.getBalance());
        assertEquals(2, someAccount.getInterestRate());
    }
    
    public void testTwoParamConstructor()
    {
        Account someAccount = new Account(1234, 5);
        assertEquals(1234, someAccount.getAccountNumber());
        assertEquals(0, someAccount.getBalance());
        assertEquals(5, someAccount.getInterestRate());
    }
    
    public void testWithdrawValid()
    {
        savingsAccount.deposit(112);
        savingsAccount.withdraw(23);
        assertEquals(89, savingsAccount.getBalance());
    }
    
    public void testWithdrawOverdraft() {
        savingsAccount.deposit(85);
        savingsAccount.withdraw(111);
        assertEquals(85, savingsAccount.getBalance());
    }
    
    public void testDepositValid()
    {
        savingsAccount.deposit(100);
        savingsAccount.deposit(200);
        assertEquals(300, savingsAccount.getBalance());
    }
    
    public void testDepositNegative()
    {
        savingsAccount.deposit(-100);
        assertEquals(0, savingsAccount.getBalance());
    }
}




