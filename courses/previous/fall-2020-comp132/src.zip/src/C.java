public class C extends B {
	public void print() {
		System.out.println("cherry");
	}
}
