package examples.adt;

public class CS132SinglyLinkedList implements CS132List {

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void add(Object element) {
		// TODO Auto-generated method stub

	}

	@Override
	public Object get(int index) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void set(int index, Object element) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub

	}

	@Override
	public void insert(int index, Object element) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub

	}

	@Override
	public Object remove(int index) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		return null;
	}

}
