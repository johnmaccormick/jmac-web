package examples.conditionals;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class Account3Test {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testValidWithDraw() {
		Account3 a = new Account3();
		a.deposit(1000);
		a.withdraw(200);
		assertEquals("",800,a.getBalance());
	}
	
	@Test
	public void testInvalidWithDraw() {
		Account3 a = new Account3();
		a.deposit(1000);
		a.withdraw(2000);
		assertEquals("",1000,a.getBalance());
	}

}
