package examples.sorting;

import java.util.*;

/**
 * Demonstration of using the Collections.sort method to sort objects into their
 * natural order (as defined by the compareTo method) and using the
 * Collections.binarySearch method to find an element in the sorted list.
 * 
 * @author Grant Braught, revisions by Farhan Siddiqui
 * @author Dickinson College
 * @version Aug 10, 2019
 */
public class CollectionSortingSearching {

    public static void main(String[] args) {
        Student3 s1 = new Student3(1, "Sam", 2008, 2.3);
        Student3 s2 = new Student3(2, "Pam", 2008, 3.8);
        Student3 s3 = new Student3(3, "Jam", 2007, 2.9);
        Student3 s4 = new Student3(4, "Kim", 2007, 3.5);
        Student3 s5 = new Student3(5, "Bob", 2006, 3.3);

        /*
         * Add the students so that they are not initially in idNumber order.
         * Don't add s5 so that we have one not in the list for later.
         */
        ArrayList<Student3> stuList = new ArrayList<Student3>();
        stuList.add(s4);
        stuList.add(s2);
        stuList.add(s3);
        stuList.add(s1);

        /*
         * Sort the list into its natural (idNumber) order.  The Collections.sort
         * method uses the Student Object's the compareTo method.
         */
        Collections.sort(stuList);
        for (Student3 s : stuList) {
            System.out.println(s);
        }
        System.out.println();

        /*
         * Use the binary search built into the Collections class to search the
         * already sorted list.  The output is the index at which the object is found or
         * the negative of the index where it would be inserted if it does not
         * appear in the list.
         */
        int kimIndex = Collections.binarySearch(stuList, s4);
        int bobIndex = Collections.binarySearch(stuList, s5);
        System.out.println("Kim (" + kimIndex + ")");
        System.out.println("Bob (" + bobIndex + ")");
    }
}
