package examples.sorting;

import java.util.Comparator;

/**
 * A Comparator for Student objects that orders them first by
 * increasing graduation year and then by decreasing GPA. So at the
 * top of the list is the earliest graduate with the highest GPA.
 *
 * @author Grant Braught, revisions by Farhan Siddiqui
 * @author Dickinson College
 * @version Aug 10, 2019
 */
public class YearGPAOrdering implements Comparator<Student3> {

    public int compare(Student3 o1, Student3 o2) {
        if (o1.getGradYear() < o2.getGradYear()) {
            return -1;      // o1 graduates before o2
        }
        else if (o1.getGradYear() > o2.getGradYear()) {
            return 1;       // o1 graduates after o2
        }
        else {
            // o1 and o2 graduate in the same year.
            if (o1.getGpa() > o2.getGpa()) {
                return -1;  // o1 has a higher gpa than o2
            }
            else if (o1.getGpa() < o2.getGpa()) {
                return 1;   // o1 has a lower gpa than o2
            }
            else {
                return 0;   // o1 and o2 have the same gpa.
            }
        }
    }
}