package examples.interfaces;

/**
 * The Duck class implements both the MakesSound and Swims
 * interfaces.
 *
 * @author Grant Braught, revisions by Farhan Siddiqui
 * @author Dickinson College
 * @version Aug 10, 2019
 */
public class Duck implements MakesSound, Swims {

    private String species;
    
    public Duck(String species) {
        this.species = species;
    }
    
    public String getSpecies() {
        return species;
    }
    
    // === Implementation of the MakesSound interface (two methods below) ===
    
    public void makeSound() {
        System.out.println("Quack, Quack");
    }
    
    public int howLoud() {
        return 4;
    }

    // === Implementation of the Swims interface (one method below) ===
    
    public void swim() {
        System.out.println("Paddling my feet, Paddling my feet");
    }
}
