package examples.exceptions;

import java.util.*;

/**
 * A sample program that illustrates Java's try/catch blocks for handling
 * exceptions.
 * 
 * @author Grant Braught, revisions by Farhan Siddiqui
 * @author Dickinson College
 * @version Aug 10, 2019
 */
public class RollSimulator {

	/**
	 * Read a number of rolls and a number of sides from the user. Then roll a
	 * die with the specified number of sides the specified number of times.
	 * 
	 * @param args none.
	 */
	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);

		System.out.print("How many times would you like to roll?  ");
		String rollsStr = scr.nextLine();
		System.out.print("How many sides should the die have?  ");
		String sidesStr = scr.nextLine();

		try {
			// These lines may generate a NumberFormatException.
			int rolls = Integer.parseInt(rollsStr);
			int sides = Integer.parseInt(sidesStr);

			// This line may generate an IllegalArgument Exception.
			Die d = new Die(sides);

			for (int r = 0; r < rolls; r++) {
				System.out.println(r + ": " + d.roll());
			}
		} catch (NumberFormatException e) {
			System.out.println("Either rolls or die is not valid");
		}catch (IllegalArgumentException e) {
			System.out.println("Die sides should be >= 4");
		}
		
			/*
			 * The code in this catch block will execute if either of the calls
			 * to parseInt above generate a NumberFormatException.
			 */
			
		
			/*
			 * The code in this catch block will execute if the call to the Die
			 * constructor above generates an IllegalArgumentException.
			 */

		

		scr.close();
	}
}
