public class B extends A {
	public void print() {
		System.out.println("banana");
	}

}
