public interface MakesSound {
    void makeSound();
    int howLoud();
}
