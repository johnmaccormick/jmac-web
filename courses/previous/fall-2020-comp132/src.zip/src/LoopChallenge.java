
public class LoopChallenge {

	public static void main(String[] args) {

		// Rewrite this as a while loop
		for (int i = -3; i < 10; i = i + 2) {
			System.out.println(i);
		}
	}

}
