
/**
 * A class representing a Course that may be taken by 
 * a Student.  Notice that if we were to happen to have
 * an another application, maybe a high school course scheduler,
 * we could reuse this class as opposed to writing new code.
 * Also, notice that, the code for accessing and mutating the 
 * fields of a course will only need to be written once, as opposed
 * to the BadStudentDesign where we would have had to write them
 * once for each course.
 * 
 * @author Grant Braught
 * @version Oct. 2, 2007
 */
public class Course
{
    private String name;
    private String department;
    private String location;
    private String time;
    private String instructor;
    
    /*
     * The constructors, accessors and mutators have been 
     * intentionally omitted for this example.
     */
}
