import java.util.HashMap;

/**
 * A demonstration of the use of the HashMap class.
 * 
 * @author Grant Braught
 * @version November 2005
 */
public class FirstHashMap
{
	private HashMap<String, String> phoneNumbers;
	
	public FirstHashMap() {
	    phoneNumbers = new HashMap<String, String>();
	}
	
	public void demoHashMap() {
	    phoneNumbers.put("Jenny", "867-5309eine");
	    phoneNumbers.put("Tommy Tutone", "555-1234");
	    
	    String jennysNum = phoneNumbers.get("Jenny");
	    System.out.println("Jenny: " + jennysNum);
	    
	    String mauricesNum = phoneNumbers.get("Maurice");
	    System.out.println("Maurice: " + mauricesNum);
	}
}
