
/**
 * Play a simple guessing game.  I'm thinking of a number between 1 and
 * 10 - can you guess what it is?
 * 
 * The constructor is used to set the number.
 * 
 * The guess method is used for the player to guess the number.
 * 
 * @author Tim Wahls
 * @author (YOUR NAME HERE)
 * @version (PUT DATE HERE)
 */
public class Game
{
    // add your fields here
    
    /**
     * set the number
     * @param initNum the number to guess
     */
    public Game(int initNum)
    {
        // add your code here
    }

    /**
     * the player tries to guess the number
     * this method replies with:
     *   - "Your guess is out of range!" if the guess is not between 1 and 10
     *   - "You win!" if the guess is correct
     *   - "Your guess is too high!" if the guess is too high
     *   - "Your guess is too low!" if the guess is too low
     * 
     * @param  guessNum the number guessed
     */
    public String guess(int guessNum)
    {
        // add your code here
        return "";
    }
}
