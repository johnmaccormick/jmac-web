import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

/**
 * A Dfa object models a deterministic finite automaton (dfa).
 * Please see the book <i>An Introduction to Formal
 * Languages and Automata</i>, by Peter Linz, for a detailed
 * description of dfas.
 * 
 * <P>
 * A Dfa object has the capability of reading a dfa from a
 * text file. An example of the format of a dfa text file
 * is:
 * 
 * <BLOCKQUOTE><TT>transitions<br>
 * Q0 a Q1<br>
 * Q0 b Q2<br>
 * Q1 a Q1<br>
 * Q1 b Q2<br>
 * Q2 a Q3<br>
 * Q2 b Q3<br>
 * Q3 a Q2<br>
 * Q3 b Q2<br>
 * finalStates<br>
 * Q1 Q3</TT></BLOCKQUOTE>
 * <P>
 * 
 * The file consists of two sections: (i) a section listing
 * the dfa's transitions, which starts with a line
 * consisting of the string "transitions"; (ii) a section
 * listing the dfa's final states, which starts with a line
 * consisting of the string "finalStates".
 * 
 * <P>
 * The transitions section specifies one transition per
 * line. Each transition is specified by three strings
 * separated by whitespace. The three strings represent,
 * respectively, the label of the state where the transition
 * begins, the symbol that triggers the transition (which
 * must consist of a single character), and the label of the
 * state to which the transition moves the dfa. The initial
 * state of the dfa is hardwired as "Q0". Conventionally,
 * the other states are named "Q1", "Q2" etc., but this is
 * not enforced. The alphabet and list of labels for the dfa
 * are not defined explicitly; rather, they are defined to
 * be everything that is encountered in the transitions
 * section of the dfa file. States are <i>not</i> required
 * to have a transition for each symbol; missing transitions
 * are assumed to move the dfa into a trap state that is not
 * explicitly represented.
 * 
 * <P>
 * The finalStates section consists of a single line (in
 * addition to the line marking the start of the section).
 * This line contains a sequence of strings separated by
 * whitespace, where each string is the name of a label that
 * is a final state of the dfa.
 * 
 * 
 * @author jmac
 * 
 */
public class Dfa {

	/**
	 * The label of the initial state of the dfa.
	 */
	public static final String INITIAL_STATE = "Q0";

	// A map containing the vertices in the dfa. The keys
	// are the labels of the vertices (e.g. Q0, Q1, Q2), and
	// the values are the corresponding DfaVertex objects.
	private HashMap<String, DfaVertex> vertices;

	// A set containing the labels (e.g. Q0, Q1) of the
	// final states of the dfa.
	private Set<String> finalStates;

	// When reading the dfa from a file, lineNumber stores
	// the number of the most recently read line.
	private int lineNumber;

	/**
	 * Create a new, empty dfa object
	 */
	public Dfa() {
		vertices = new HashMap<String, DfaVertex>();
		finalStates = new TreeSet<String>();
		lineNumber = 0;
	}

	/**
	 * Read a description of the dfa from a file. Please see
	 * the documentation of the Dfa object for a description
	 * of the file format.
	 * 
	 * @param filename
	 *            the name of the file to be read
	 * @throws FileNotFoundException
	 *             if the file isn't found
	 * @throws DfaException
	 *             if the contents of the file does not
	 *             represent a legal dfa
	 */
	public void readFromFile(String filename)
			throws FileNotFoundException, DfaException {
		Scanner scanner = null;
		try {
			File file = new File(filename);
			scanner = new Scanner(file);
			readTransitions(scanner);
			readFinalStates(scanner);
		} finally {
			// ensure the underlying stream is always closed
			if (scanner != null)
				scanner.close();
		}

	}

	// Read the transitions from the dfa file. The given
	// scanner is assumed to be at the very start of the
	// file, so the first line read should be "transitions"
	private void readTransitions(Scanner scanner)
			throws DfaException {
		// read the first line, which should be
		// "transitions"
		checkForLine(scanner);
		lineNumber++;
		String line = scanner.nextLine();
		if (!line.equals("transitions")) {
			throw new DfaException(
					"expected 'transitions' at line "
							+ lineNumber);
		}

		// read the transition information, which is
		// described by one line per transition. When the
		// transitions end, we encounter the list of final
		// states which are marked by the line "finalStates"
		boolean finishedTransitions = false;
		while (!finishedTransitions) {
			checkForLine(scanner);
			lineNumber++;
			line = scanner.nextLine();
			if (line.equals("finalStates")) {
				finishedTransitions = true;
			} else {
				processTransition(line);
			}
		}

		// check that the dfa has a valid initial state
		if (!vertices.containsKey(INITIAL_STATE)) {
			throw new DfaException(
					"finished processing transitions, but initial state "
							+ INITIAL_STATE
							+ " was not found");
		}

	}

	// process a single transition in the dfa file (which is
	// specified by the given line of the file), by adding
	// the relevant information to this Dfa object
	private void processTransition(String line)
			throws DfaException {
		// split the line on whitespace
		String[] elements = line.split("\\s+");
		// the line should contain exactly 3 elements: the
		// source label, the transition symbol, and the
		// destination label
		if (elements.length != 3) {
			throw new DfaException("transition at line "
					+ lineNumber
					+ " does not contain three elements");
		}
		String source = elements[0];
		String symbol = elements[1];
		String dest = elements[2];

		if (symbol.length() != 1) {
			throw new DfaException(
					"transition at line "
							+ lineNumber
							+ " contains a symbol that is not exactly 1 character.");
		}

		// add the vertices to the dfa
		addVertex(source);
		addVertex(dest);

		// add the transition to the source vertex
		addTransition(source, symbol, dest);
	}

	// add a new vertex with the given label if it is not
	// already present
	private void addVertex(String label) {
		if (!vertices.containsKey(label)) {
			DfaVertex v = new DfaVertex(label);
			vertices.put(label, v);
		}
	}

	// add a new transition with the given source label,
	// transition symbol, and destination label
	private void addTransition(String source,
			String symbol, String dest) throws DfaException {
		DfaVertex v = vertices.get(source);
		if (v == null) {
			throw new DfaException(
					"source of transition at line "
							+ lineNumber
							+ " does not exist.");
		}
		v.addTransition(symbol, dest);
	}

	// read the list of final states from the dfa file and
	// store them in this Dfa object. When this method is
	// called, the scanner has already read the line
	// "finalStates", so it need only read the single line
	// containing the final state labels themselves.
	private void readFinalStates(Scanner scanner)
			throws DfaException {
		// read the next line
		checkForLine(scanner);
		lineNumber++;
		String line = scanner.nextLine();

		// split on whitespace
		String[] elements = line.split("\\s+");

		// add each label to the set of final states
		for (String label : elements) {
			if (!vertices.containsKey(label)) {
				throw new DfaException("final state "
						+ label + " is not a valid vertex");
			}
			finalStates.add(label);
		}
	}

	// check that another line is available to be read
	private void checkForLine(Scanner scanner)
			throws DfaException {
		if (!scanner.hasNextLine()) {
			throw new DfaException(
					"Unexpected end of file at line "
							+ lineNumber);
		}

	}

	/**
	 * Return true if this dfa accepts the given string, and
	 * false otherwise.
	 */
	public boolean accepts(String string) {
        // FIX THIS
        return true;
	}

	public static void main(String[] args) {
		Dfa dfa = new Dfa();
		try {
			dfa.readFromFile("testdfa.txt");
			System.out.println(dfa.accepts("a"));
			System.out.println(dfa.accepts("aa"));
			System.out.println(dfa.accepts("aab"));
			System.out.println(dfa.accepts("aabb"));
			System.out.println(dfa.accepts("aabba"));
			System.out.println(dfa.accepts("aabbab"));
		} catch (FileNotFoundException e) {
			System.err.println(e);
		} catch (DfaException e) {
			System.err.println(e);
		}
	}

}