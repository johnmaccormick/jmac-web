

/**
 * The test class StockDataTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class StockDataTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class StockDataTest
     */
    public StockDataTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

    public void testConstructor()
    {
        StockData stockDat1 = new StockData(2006, 1, 5, 25.50, 27.30, 22.80, 26.60, 123456);
        assertEquals(2006, stockDat1.getYear());
        assertEquals(1, stockDat1.getMonth());
        assertEquals(5, stockDat1.getDay());
        assertEquals(25.50, stockDat1.getOpeningPrice(), 0.1);
        assertEquals(27.30, stockDat1.getHighPrice(), 0.1);
        assertEquals(22.80, stockDat1.getLowPrice(), 0.1);
		assertEquals(26.60, stockDat1.getClosingPrice(), 0.1);
		assertEquals(123456, stockDat1.getVolume());
    }
}

