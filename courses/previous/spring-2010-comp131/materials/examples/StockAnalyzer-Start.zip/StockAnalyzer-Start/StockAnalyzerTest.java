

/**
 * The test class StockAnalyzerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class StockAnalyzerTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class StockAnalyzerTest
     */
    public StockAnalyzerTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

    public void testConstructor()
    {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("GOOG", 10);
            assertEquals("GOOG", stockAna1.getTickerSymbol());
            assertEquals(10, stockAna1.getDays());
        }
        catch (NullPointerException e) {
            fail("hint: Your constructor may not have created the array.");
        }
        catch (Exception e) {
            fail("hint: Your constructor generated an exception.");
        }
    }

    public void testSetGetPrice()
    {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("GOOG", 10);
            stockAna1.setPrice(0, 12.34);
            assertEquals(12.34, stockAna1.getPrice(0), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "getPrice and setPrice methods.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getPrice and setPrice methods.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getPrice and setPrice methods.");
        }                

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("GOOG", 10);
            stockAna1.setPrice(9, 12.34);
            assertEquals(12.34, stockAna1.getPrice(9), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getPrice and setPrice methods.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getPrice and setPrice methods.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getPrice and setPrice methods.");
        }   

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("GOOG", 10);
            stockAna1.setPrice(-1, 12.34);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "setPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "setPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "setPrice method.");
        }   

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("GOOG", 10);
            stockAna1.setPrice(10, 12.34);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "setPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "setPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "setPrice method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("GOOG", 10);
            assertEquals(-1, stockAna1.getPrice(-1), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getPrice method.");
        }  
 
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("GOOG", 10);
            assertEquals(-1, stockAna1.getPrice(10), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getPrice method.");
        } 
    } 

    public void testFetchClosingPrices()
    {
        try {
            StockAnalyzer stockAna2 = new StockAnalyzer("GOOG", 10);
            stockAna2.fetchClosingPrices(2006, 1, 1);
            assertEquals(435.23, stockAna2.getPrice(0), 0.1);
            assertEquals(467.11, stockAna2.getPrice(9), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "fetchClosingPrices method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "fetchClosingPrices method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "fetchClosingPrices method.");
        }        
    }
    
    public void testGetNetChangeInValue()
    {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            assertEquals(4, stockAna1.getNetChangeInValue(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getNetChangeInValue method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getNetChangeInValue method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getNetChangeInValue method.");
        } 
    }
    
    public void testGetAveragePrice()
    {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("GOOG", 5);
            stockAna1.setPrice(0, 2);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 5);
            stockAna1.setPrice(4, 5);
            assertEquals(3.4, stockAna1.getAveragePrice(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getAveragePrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getAveragePrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getAveragePrice method.");
        }  
    }   
    
    public void testGetMaxPrice() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 5);
            stockAna1.setPrice(1, 4);
            stockAna1.setPrice(2, 2);
            stockAna1.setPrice(3, 3);
            stockAna1.setPrice(4, 1);
            assertEquals("hint: The maximum price was first in this data.",
            5, stockAna1.getMaxPrice(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getMaxPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getMaxPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getMaxPrice method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 1);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            assertEquals("hint: The maximum price was last in this data.",
            5, stockAna1.getMaxPrice(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getMaxPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getMaxPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getMaxPrice method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 3);
            stockAna1.setPrice(4, 4);
            assertEquals("hint: The maximum price was in the middle of this data.",
            5, stockAna1.getMaxPrice(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getMaxPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getMaxPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getMaxPrice method.");
        }
    }
    
    public void testGetMinPrice() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 2);
            stockAna1.setPrice(4, 5);
            assertEquals("hint: The minimum price was first in this data.",
            1, stockAna1.getMinPrice(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getMinPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getMinPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getMinPrice method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 5);
            stockAna1.setPrice(1, 4);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 5);
            stockAna1.setPrice(4, 1);
            assertEquals("hint: The minimum price was last in this data.",
            1, stockAna1.getMinPrice(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getMinPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getMinPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getMinPrice method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 4);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 1);
            stockAna1.setPrice(3, 5);
            stockAna1.setPrice(4, 3);
            assertEquals("hint: The minimum price was in the middle of this data.",
            1, stockAna1.getMinPrice(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getMinPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getMinPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getMinPrice method.");
        }
    }
    
    public void testGetDayOfMaxPrice() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 5);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 4);
            stockAna1.setPrice(3, 1);
            stockAna1.setPrice(4, 3);
            assertEquals("hint: The maximum price was first in this data.",
            0, stockAna1.getDayOfMaxPrice());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 3);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            assertEquals("hint: The maximum price was last in this data.",
            4, stockAna1.getDayOfMaxPrice());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 3);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 1);
            stockAna1.setPrice(4, 4);
            assertEquals("hint: The maximum price was in the middle of this data.",
            2, stockAna1.getDayOfMaxPrice());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }
 
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 2);
            stockAna1.setPrice(1, 5);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 3);
            stockAna1.setPrice(4, 5);
            assertEquals("hint: There was a tie for the day with the maximum price.",
            4, stockAna1.getDayOfMaxPrice());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getDayOfMaxPrice method.");
        }
    }
    
    public void testGetDayOfMinPrice() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 2);
            stockAna1.setPrice(1, 3);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            assertEquals("hint: The minimum price was first in this data.",
            0, stockAna1.getDayOfMinPrice());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getDayOfMinPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getDayOfMinPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getDayOfMinPrice method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 3);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 4);
            stockAna1.setPrice(3, 3);
            stockAna1.setPrice(4, 1);
            assertEquals("hint: The minimum price was last in this data.",
            4, stockAna1.getDayOfMinPrice());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getDayOfMinPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getDayOfMinPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getDayOfMinPrice method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 3);
            stockAna1.setPrice(1, 4);
            stockAna1.setPrice(2, 1);
            stockAna1.setPrice(3, 2);
            stockAna1.setPrice(4, 4);
            assertEquals("hint: The minimum price was in the middle of this data.",
            2, stockAna1.getDayOfMinPrice());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getDayOfMinPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getDayOfMinPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getDayOfMinPrice method.");
        }
 
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 4);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 4);
            stockAna1.setPrice(3, 2);
            stockAna1.setPrice(4, 5);
            assertEquals("hint: There was a tie for the day with the minimum price.",
            3, stockAna1.getDayOfMinPrice());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getDayOfMinPrice method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getDayOfMinPrice method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getDayOfMinPrice method.");
        }
    }
    
    public void testGetLargestPriceDifference() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 5);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 1);
            stockAna1.setPrice(4, 4);
            assertEquals("hint: The minimum comes after the maximum in this data. So the " +
            "largest price difference should be negative.",
            -4, stockAna1.getLargestPriceDifference(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getLargestPriceDifference method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getLargestPriceDifference method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getLargestPriceDifference method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 2);
            stockAna1.setPrice(1, 3);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 5);
            stockAna1.setPrice(4, 4);
            assertEquals("hint: The maximum comes after the minimum in this data. So the " +
            "largest price difference should be positive.",
            3, stockAna1.getLargestPriceDifference(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "getLargestPriceDifference method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "getLargestPriceDifference method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "getLargestPriceDifference method.");
        }
    }
       
    public void testIsVolatilePeriod() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 5);
            stockAna1.setPrice(1, 4);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 1);
            stockAna1.setPrice(4, 3);
            assertFalse("hint: The max and min are not close enough to be considered volatile " + 
            "in the data used for this test.",
            stockAna1.isVolatilePeriod(2));
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "isVolatilePeriod method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "isVolatilePeriod method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "isVolatilePeriod method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 2);
            stockAna1.setPrice(1, 1);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 5);
            stockAna1.setPrice(4, 3);
            assertTrue("hint: The max and min are close enough to be considered volatile " + 
            "in the data used for this test.",
            stockAna1.isVolatilePeriod(2));
         }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occurred when testing your " + 
                "isVolatilePeriod method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occurred when testing your " + 
                "isVolatilePeriod method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occurred when testing your " + 
                "isVolatilePeriod method.");
        }
    }
       
    public void testHasBreakEvenDays() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            assertFalse("hint: Your hasBreakEvenDays method failed with the data: 1 2 3 4 5.",
            stockAna1.hasBreakEvenDays());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "hasBreakEvenDays method.");
        }          
    
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 2);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            assertTrue("hint: Your hasBreakEvenDays method failed with the data: 2 2 3 4 5.",
            stockAna1.hasBreakEvenDays());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "hasBreakEvenDays method.");
        } 
 
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 5);
            stockAna1.setPrice(4, 5);
            assertTrue("hint: Your hasBreakEvenDays method failed with the data: 1 2 3 5 5.",
            stockAna1.hasBreakEvenDays());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "hasBreakEvenDays method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 3);
            stockAna1.setPrice(4, 5);
            assertTrue("hint: Your hasBreakEvenDays method failed with the data: 1 2 3 3 5.",
            stockAna1.hasBreakEvenDays());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "hasBreakEvenDays method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 1);
            assertTrue("hint: Your hasBreakEvenDays method failed with the data: 1 2 3 4 1.",
            stockAna1.hasBreakEvenDays());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "hasBreakEvenDays method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 1);
            stockAna1.setPrice(4, 5);
            assertTrue("hint: Your hasBreakEvenDays method failed with the data: 1 2 3 1 5.",
            stockAna1.hasBreakEvenDays());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "hasBreakEvenDays method.");
        } 
  
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5);
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 3);
            assertTrue("hint: Your hasBreakEvenDays method failed with the data: 1 2 3 4 3.",
            stockAna1.hasBreakEvenDays());
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "hasBreakEvenDays method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "hasBreakEvenDays method.");
        } 
    } 
    
    public void testMaxProfitPerShare() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5); 
            stockAna1.setPrice(0, 5);
            stockAna1.setPrice(1, 4);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 2);
            stockAna1.setPrice(4, 1);
            assertEquals("hint: Your maxProfitPerShare method failed with the data: 5 4 3 2 1.",
            0, stockAna1.maxProfitPerShare(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "maxProfitPerShare method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            assertEquals("hint: Your maxProfitPerShare method failed with the data: 1 2 3 4 5.",
            4, stockAna1.maxProfitPerShare(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "maxProfitPerShare method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 3);
            assertEquals("hint: Your maxProfitPerShare method failed with the data: 1 2 5 4 3.",
            4, stockAna1.maxProfitPerShare(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "maxProfitPerShare method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5); 
            stockAna1.setPrice(0, 3);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 1);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            assertEquals("hint: Your maxProfitPerShare method failed with the data: 3 2 1 4 5.",
            4, stockAna1.maxProfitPerShare(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "maxProfitPerShare method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5); 
            stockAna1.setPrice(0, 3);
            stockAna1.setPrice(1, 1);
            stockAna1.setPrice(2, 4);
            stockAna1.setPrice(3, 5);
            stockAna1.setPrice(4, 3);
            assertEquals("hint: Your maxProfitPerShare method failed with the data: 3 1 4 5 3.",
            4, stockAna1.maxProfitPerShare(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "maxProfitPerShare method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 5); 
            stockAna1.setPrice(0, 3);
            stockAna1.setPrice(1, 1);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 2);
            stockAna1.setPrice(4, 3);
            assertEquals("hint: Your maxProfitPerShare method failed with the data: 3 1 5 2 3.",
            4, stockAna1.maxProfitPerShare(), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "maxProfitPerShare method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "maxProfitPerShare method.");
        } 
    }
    
    public void testSillyTrader() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            stockAna1.setPrice(5, 6);
            assertEquals("hint: Your sillyTrader method failed with the data" +
                ": 1 2 3 4 5 6 and a buy of 5 shares.",
                15, stockAna1.sillyTrader(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "sillyTrader method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "sillyTrader method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "sillyTrader method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 6);
            stockAna1.setPrice(1, 5);
            stockAna1.setPrice(2, 4);
            stockAna1.setPrice(3, 3);
            stockAna1.setPrice(4, 2);
            stockAna1.setPrice(5, 1);
            assertEquals("hint: Your sillyTrader method failed with the data" +
                ": 6 5 4 3 2 1 and a buy of 5 shares.",
                -15, stockAna1.sillyTrader(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "sillyTrader method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "sillyTrader method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "sillyTrader method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 3);
            stockAna1.setPrice(2, 2);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 6);
            stockAna1.setPrice(5, 3);
            assertEquals("hint: Your sillyTrader method failed with the data" +
                ": 1 3 2 4 6 3 and a buy of 5 shares.",
                5, stockAna1.sillyTrader(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "sillyTrader method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "sillyTrader method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "sillyTrader method.");
        } 
    }
    
    public void testBuyOnFirstInc() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 6);
            stockAna1.setPrice(1, 5);
            stockAna1.setPrice(2, 4);
            stockAna1.setPrice(3, 3);
            stockAna1.setPrice(4, 2);
            stockAna1.setPrice(5, 1);
            assertEquals("hint: Your buyOnFirstIncrease method failed with the data" +
                ": 6 5 4 3 2 1 and a buy of 5 shares.",
                0, stockAna1.buyOnFirstIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnFirstIncrease method.");
        } 

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            stockAna1.setPrice(5, 6);
            assertEquals("hint: Your buyOnFirstIncrease method failed with the data" +
                ": 1 2 3 4 5 6 and a buy of 5 shares.",
                20, stockAna1.buyOnFirstIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnFirstIncrease method.");
        }

        try {
        StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
        stockAna1.setPrice(0, 3);
        stockAna1.setPrice(1, 2);
        stockAna1.setPrice(2, 1);
        stockAna1.setPrice(3, 4);
        stockAna1.setPrice(4, 5);
        stockAna1.setPrice(5, 6);
        assertEquals("hint: Your buyOnFirstIncrease method failed with the data" +
                ": 3 2 1 4 5 6 and a buy of 5 shares.",
                10, stockAna1.buyOnFirstIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnFirstIncrease method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 5);
            stockAna1.setPrice(1, 4);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 2);
            stockAna1.setPrice(4, 1);
            stockAna1.setPrice(5, 2);
            assertEquals("hint: Your buyOnFirstIncrease method failed with the data" +
                ": 5 4 3 2 1 2 and a buy of 5 shares.",
                0, stockAna1.buyOnFirstIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnFirstIncrease method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 5);
            stockAna1.setPrice(1, 5);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 5);
            stockAna1.setPrice(4, 5);
            stockAna1.setPrice(5, 5);
            assertEquals("hint: Your buyOnFirstIncrease method failed with the data" +
                ": 5 5 5 5 5 5 and a buy of 5 shares.",
                0, stockAna1.buyOnFirstIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnFirstIncrease method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 5);
            stockAna1.setPrice(1, 5);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 5);
            stockAna1.setPrice(4, 5);
            stockAna1.setPrice(5, 5);
            assertEquals("hint: Your buyOnFirstIncrease method failed with the data" +
                ": 5 5 3 5 5 5 and a buy of 5 shares.",
            0, stockAna1.buyOnFirstIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnFirstIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnFirstIncrease method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 6);
            stockAna1.setPrice(1, 5);
            stockAna1.setPrice(2, 4);
            stockAna1.setPrice(3, 3);
            stockAna1.setPrice(4, 2);
            stockAna1.setPrice(5, 1);
            assertEquals("hint: Your buyOnEveryIncrease method failed with the data" +
                ": 6 5 4 3 2 1 and a buy of 5 shares.",
            0, stockAna1.buyOnEveryIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
    }
    
    public void testBuyOnEveryInc() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 5);
            stockAna1.setPrice(1, 6);
            stockAna1.setPrice(2, 4);
            stockAna1.setPrice(3, 3);
            stockAna1.setPrice(4, 2);
            stockAna1.setPrice(5, 1);
            assertEquals("hint: Your buyOnEveryIncrease method failed with the data" +
                ": 5 6 4 3 2 1 and a buy of 5 shares.",
            -25, stockAna1.buyOnEveryIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnEveryIncrease method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 6);
            stockAna1.setPrice(1, 5);
            stockAna1.setPrice(2, 4);
            stockAna1.setPrice(3, 8);
            stockAna1.setPrice(4, 7);
            stockAna1.setPrice(5, 6);
            assertEquals("hint: Your buyOnEveryIncrease method failed with the data" +
                ": 6 5 4 8 7 6. and a buy of 5 shares.",
            -10, stockAna1.buyOnEveryIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnEveryIncrease method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 3);
            stockAna1.setPrice(2, 2);
            stockAna1.setPrice(3, 2);
            stockAna1.setPrice(4, 5);
            stockAna1.setPrice(5, 5);
            assertEquals("hint: Your buyOnEveryIncrease method failed with the data" +
                ": 1 3 2 2 5 5 and a buy of 5 shares.",
            10, stockAna1.buyOnEveryIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnEveryIncrease method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            stockAna1.setPrice(5, 6);
            assertEquals("hint: Your buyOnEveryIncrease method failed with the data" +
                ": 1 2 3 4 5 6 and a buy of 5 shares.",
            50, stockAna1.buyOnEveryIncrease(5), 0.1);
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "buyOnEveryIncrease method.");
        }
    }
    
    public void testDogDetector() {
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            stockAna1.setPrice(5, 6);
            assertFalse("hint: Your dogDetector method failed with the data" +
                ": 1 2 3 4 5 6. The number of days was 1.",
            stockAna1.dogDetector(1));
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "dogDetector method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "dogDetector method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "dogDetector method.");
        }
   
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 3);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 5);
            stockAna1.setPrice(5, 5);
            assertFalse("hint: Your dogDetector method failed with the data" +
                ": 1 2 3 4 5 5. The number of days was 1.",
            stockAna1.dogDetector(1));
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "dogDetector method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "dogDetector method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "dogDetector method.");
        }
 
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 5);
            stockAna1.setPrice(4, 5);
            stockAna1.setPrice(5, 5);
            assertFalse("hint: Your dogDetector method failed with the data" +
                ": 1 2 5 5 5 5. The number of days was 3.",
            stockAna1.dogDetector(3));
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "dogDetector method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "dogDetector method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "dogDetector method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 3);
            stockAna1.setPrice(5, 2);
            assertTrue("hint: Your dogDetector method failed with the data" +
                ": 1 2 5 4 3 2. The number of days was 3.",
            stockAna1.dogDetector(3));
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "dogDetector method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "dogDetector method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "dogDetector method.");
        }
 
        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 3);
            stockAna1.setPrice(5, 2);
            assertFalse("hint: Your dogDetector method failed with the data" +
                ": 1 2 5 4 3 2. The number of days was 4.",
            stockAna1.dogDetector(4));
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "dogDetector method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "dogDetector method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "dogDetector method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 3);
            stockAna1.setPrice(5, 3);
            assertFalse("hint: Your dogDetector method failed with the data" +
                ": 1 2 5 4 3 3. The number of days was 3.",
            stockAna1.dogDetector(3));
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "dogDetector method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "dogDetector method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "dogDetector method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 6);
            stockAna1.setPrice(1, 5);
            stockAna1.setPrice(2, 4);
            stockAna1.setPrice(3, 3);
            stockAna1.setPrice(4, 2);
            stockAna1.setPrice(5, 1);
            assertTrue("hint: Your dogDetector method failed with the data" +
                ": 5 4 3 2 1. The number of days was 5.",
            stockAna1.dogDetector(5));
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "dogDetector method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "dogDetector method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "dogDetector method.");
        }

        try {
            StockAnalyzer stockAna1 = new StockAnalyzer("TEST", 6); 
            stockAna1.setPrice(0, 1);
            stockAna1.setPrice(1, 2);
            stockAna1.setPrice(2, 5);
            stockAna1.setPrice(3, 4);
            stockAna1.setPrice(4, 3);
            stockAna1.setPrice(5, 3);
            assertFalse("hint: Your dogDetector method failed with the data" +
                ": 1 2 5 4 3 3. The number of days was 6.",
            stockAna1.dogDetector(6));
        }
        catch (NullPointerException e) {
            fail("hint: A NullPointerException occured when testing your " + 
                "dogDetector method.");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            fail("hint: An ArrayIndexOutOfBoundsException occured when testing your " + 
                "dogDetector method.");
        }
        catch (Exception e) {
            fail("hint: An Exception occured when testing your " + 
                "dogDetector method.");
        }
    }
}



