
/**
 * First examples of using a for loop.  This class doesn't
 * do any meaningful computation, it simply serves as a 
 * demonstration of the execution of a for loop.
 * 
 * @author Grant Braught
 * @version October 2005
 */
public class FirstForLoop
{
    /**
     * Demonstrate the operation of a for loop!
     */
    public void forLoopDemo() {
        for (int num = 0; num < 5; num++) {
            System.out.println(2*num - 1);
        }
    }
    
    /**
     * Another demonstration of a for loop!
     */
    public void forLoopDemoTwo() {
        for (int num = 10; num >= 0; num--) {
            System.out.println(num / 2 + 1);
        }
    }
    
    /**
     * Yet another demonstration of a for loop!
     */
    public void forLoopDemoThree() {
        for (int num = 1; num <= 64; num = num * 2) {
            System.out.println(num * num);
        }
    }
}
