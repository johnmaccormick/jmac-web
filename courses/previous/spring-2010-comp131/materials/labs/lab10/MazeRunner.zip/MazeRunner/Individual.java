
/**
 * The Individual class represents a individual organism in
 * the evolving Population.  It contains an array of integer
 * values that represent the organism's DNA. Each entry in the
 * array represents a single gene in the DNA.  Each gene indicates
 * a movement in the maze as follows:
 * <pre>
 * 0    Move North
 * 1    Move East
 * 2    Move South
 * 3    Move West
 * </pre>
 * 
 * @author Grant Braught
 *
 * @author (YOUR NAME HERE)
 * @version (PUT DATE HERE)
 */
public class Individual
{
    // Define your fields here.
       
    /**
     * Construct a new Individual.  Each individual has an array of
     * integers with its length indicated by genes.  Each individual 
     * also has a fitness value (i.e. you will need to define a field for 
     * the fitness of the individual.) The default fitness value for each
     * individual is 0.
     * 
     * @param genes the number of genes in this Individual's DNA.
     */
    public Individual(int genes) {
        // Add your code here.
    }
    
    /**
     * Get the number of genes in this individual's DNA.
     * 
     * @return the number of genes.
     */
    public int getNumGenes() {
        // Replace this with your code.
        return 0;
    }
    
    /**
     * Get the fitness of this Individual.
     * 
     * @return this individual's fitness.
     */
    public int getFitness() {
        // Replace this with your code.
        return 0;
    }
    
    /**
     * Set the fitness of this Individual.  Note that this method does not 
     * calculate the fitness of the individual. The fitness is calculated by 
     * code provided in the GeneticAlgorithm class. Code in that class then 
     * calls this method to assign the calculated fitness to the Individual.
     * 
     * @param newFitness the fitness of this individual.
     */
    public void setFitness(int newFitness) {
        // Add your code here.
    }
    
    /**
     * Set the value of a specified gene in this Individual's DNA.  If the
     * index of the gene is not valid or the value specified for the gene
     * is not valid then an error message is printed and the Individual's 
     * DNA is not changed.
     * 
     * @param index the index of the gene to set.
     * @param value the new value for the gene.
     */
    public void setGene(int index, int value) {
        // Add your code here.
    }
    
    /**
     * Get the value of the gene at the specified index in this Individual's 
     * DNA.  If the specified index is invalid, this method prints and error 
     * message and returns -1.  If the specified index is valid, this method
     * returns the value of the specified gene.
     * 
     * @param index the index of the gene to get.
     * @return the value of the gene at the index.
     */
    public int getGene(int index) {
        // Replace this with your code.
        return 0;
    }
    
    /**
     * Print out all of this Individual's genes.  The genes should
     * be printed on a single line.
     */
    public void printGenes() {
        // Add your code here.
    }
    
    /**
     * Perform an asexual reproduction (i.e. a cloning) of the calling Individual. 
     * This method creates a new Individual, copies all of the genes from
     * the calling Individual into the new Individual.  The fitness of the 
     * new individual must be 0.  This method then then returns the new Individual.
     * 
     * @return a new Individual that is a clone of the calling Individual.
     */
    public Individual asexualReproduction() {
        // Replace this with your code.
        return null;
    }    
    
    /**
     * Perform a sexual reproduction of the calling individual with 
     * the specified otherParent.  This method creates a new 
     * Individual with the same number of genes as the calling Individual (note:
     * the otherParent will also always have the same number of genes as the
     * calling Individual.) The new Individual then inherits some of its genes 
     * from the calling Individual and the rest of its genes from the otherParent. 
     * Specifically, the genes from index 0 up to but not including the gene
     * at the crossoverIndex are copied from the calling Individual into the
     * new Individual.  Then the genes from the crossoverIndex to the end of 
     * the DNA are copied from the otherParent into the new Individual. The 
     * fitness of the new Individual is to be 0. However, if the specified 
     * crossoverIndex is not valid, this method prints an error message 
     * and returns null.
     * 
     * @param otherParent the second parent.
     * @param crossoverIndex the index at which to perform crossover.
     */
    public Individual sexualReproduction(Individual otherParent, int crossoverIndex) {
        // Replace this with your code.
        return null;
    }
    
   /**
     * Mutate the gene at the specified index in this Individual's
     * DNA.  A gene is mutated adding the muAmmount to the current
     * value of the gene at muIndex and then finding the remainder
     * when that result is divided by 4. If the specified index is 
     * invalid this method prints an error message and does not 
     * mutate any gene.
     * 
     * @param muIndex the index of the gene to be mutated.
     * @param muAmount the size of the mutation.
     */
    public void mutate(int muIndex, int muAmount) {
        // Add your code here.
    }
}
