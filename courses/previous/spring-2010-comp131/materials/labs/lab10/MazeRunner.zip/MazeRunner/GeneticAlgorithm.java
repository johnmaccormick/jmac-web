import java.util.Random;
import java.util.ArrayList;
/**
 * Write a description of class GeneticAlgorithm here.
 * 
 * @author Grant Braught
 * @version November 2005
 */
public class GeneticAlgorithm
{
    /**
     * Maximum achievable fitness.
     */
    public static final int MAX_FITNESS = 1000;
    
    private static final int PCT_ELITES = 1;
    //private static final int NUM_COLLISIONS = 10;
    
    private Population pop;
    private int popSize;
    private int gen;
    private int genes;
    private boolean sexual;
    private double muRate;
    private int tourneySize;
    private Random rnd;
    private Maze theMaze;
    private MazeDisplayPanel mazePanel;
    private int collisions; // hack used to pass information between methods.
    
    public GeneticAlgorithm(int popSize, boolean sexual, double muRate, 
        int tourneySize, int genes, Maze maze, MazeDisplayPanel mazePanel) {
        gen = 0;
        this.popSize = popSize;
        this.genes = genes;
        this.sexual = sexual;
        rnd = new Random();
        this.tourneySize = tourneySize;
        pop = new Population();
        
        theMaze = maze;
        this.mazePanel = mazePanel;
        this.muRate = muRate;

        fillPopulation();
    }
    
    public Population getPopulation() {
        return pop;
    }
    
    public int getGeneration() {
        return gen;
    }
    
    private void fillPopulation() {   
        for (int i=0; i<popSize; i++) {
            Individual indiv = new Individual(genes);
            for (int g=0; g<genes; g++) {
                indiv.setGene(g, rnd.nextInt(4));
            }
            pop.addIndividual(indiv);
        }
        setFitness();
    }
    
    public void nextGeneration() {
        gen++;
        
        if (sexual) {
            pop = sexualReproduction();
        }
        else {
            pop = asexualReproduction();
        }
        
        
        int elites = 0;
        if (PCT_ELITES != 0) {
            elites = pop.getSize() / (100 / PCT_ELITES);
        }
        
        for (int i=0; i<elites; i++) {
            Individual fittest = pop.getFittestIndividual();
            pop.addIndividual(fittest.asexualReproduction());
        }
        
        //System.out.println(pop.getSize());
        
        setFitness();
    }
    
    private void setFitness() {
        int size = pop.getSize();
        for (int i=0; i<size; i++) {
            // Build the maze path encoded by the individual's genotype
            Individual indiv = pop.getIndividual(i);
            MazeSolution myPath = getIndividualPath(indiv);
        
            // Find the length of the solution to the maze from the end
            // of the solution encoded by the individual's genotype and use
            // that to set the fitness of the solution.
            int endx = myPath.getLastXPosition();
            int endy = myPath.getLastYPosition();
         
            DFMazeSolver solver = new DFMazeSolver();
            MazeSolution soln = solver.solveMaze(theMaze, mazePanel, endx, endy);
            //mazePanel.setCurrentSolution(soln);
            
            indiv.setFitness(MAX_FITNESS - 25*soln.getLength() - 10*collisions);
            
            /*
             System.out.println("indiv: " + i + " (" + endx + "," + endy +
             ") fitness: " + indiv.getFitness() + " soln: " + soln.getLength());
             */
        }
    }
    
    public MazeSolution getIndividualPath(Individual indiv) {
        int xpos = 0;
        int ypos = 0;
        collisions = 0;
        
        MazeSolution mazeSolution = 
        MazeSolutionFactory.createMazeSolution(theMaze.getWidth(), theMaze.getHeight(), 
        0, 0, theMaze.getEndXPosition(), theMaze.getEndYPosition());
        
        int numGenes = indiv.getNumGenes();
        for (int i=0; i<numGenes; i++) {
            int gene = indiv.getGene(i);
            if (gene == 0) {
                if (theMaze.canMoveNorthFrom(xpos,ypos)) {
                    ypos--;
                    mazeSolution.moveNorth();
                    //System.out.print("N");
                }
                else {
                    collisions++;
                    //break;
                }
            }
            else if (gene == 1) {
                if (theMaze.canMoveEastFrom(xpos, ypos)) {
                    xpos++;
                    mazeSolution.moveEast();
                    //System.out.print("E");
                }
                else {
                    collisions++;
                    //break;
                }
            }
            else if (gene == 2) {
                if (theMaze.canMoveSouthFrom(xpos, ypos)) {
                    ypos++;
                    mazeSolution.moveSouth();
                    //System.out.print("S");
                }
                else {
                    collisions++;
                    //break;
                }
            }
            else if (gene == 3) {
                if (theMaze.canMoveWestFrom(xpos, ypos)) {
                    xpos--;
                    mazeSolution.moveWest();
                    //System.out.print("W");
                }
                else {
                    collisions++;
                    //break;
                }
            }
            
            if (mazeSolution.solutionComplete()) {
                break;
            }
            
            //if (collisions > NUM_COLLISIONS) {
            //    break;
            //}
        }
        
        //System.out.println();
        
        return mazeSolution;
    }
    
    private Population sexualReproduction() {
        Population newPop = new Population();
        int size = pop.getSize();
        
        int elites = 0;
        if (PCT_ELITES != 0) {
            elites = pop.getSize() / (100 / PCT_ELITES);
        }
        
        for (int i=0; i<size-elites; i++) {
            Individual mom = pop.pickParent(tourneySize);
            Individual dad = pop.pickParent(tourneySize);
            int crLoc = rnd.nextInt(mom.getNumGenes());
            Individual child = mom.sexualReproduction(dad, crLoc);
            mutateIndividual(child);
            newPop.addIndividual(child);
        }
        
        return newPop;
    }
    
    private Population asexualReproduction() {
        Population newPop = new Population();
        int size = pop.getSize();

        int elites = 0;
        if (PCT_ELITES != 0) {
            elites = pop.getSize() / (100 / PCT_ELITES);
        }
        
        for (int i=0; i<size-elites; i++) {
            Individual child = pop.pickParent(tourneySize).asexualReproduction();
            mutateIndividual(child);
            newPop.addIndividual(child);
        }
        return newPop;
    }
    
    private void mutateIndividual(Individual indiv) {
        int genes = indiv.getNumGenes();
        for (int g=0; g<genes; g++) {
            if (rnd.nextDouble() < muRate) { // * (1.5 * (1/(genes-g)) + 0.5)) {
                int muLoc = rnd.nextInt(genes);
                int muVal = rnd.nextInt(3) + 1;
                indiv.mutate(muLoc, muVal);
            }
        }
    }
}
