import javax.swing.*;
import java.awt.*;
import java.text.*;

/**
 * Write a description of class DataTable here.
 * 
 * @author Grant Braught 
 * @version September 2005
 */
public class DataTable extends JFrame
{
    private JTextArea table;
    
    /**
     * Create a new data table.
     */
    public DataTable(String title) {
        setTitle(title);
        Container c = getContentPane();
        table = new JTextArea();
        table.setText("     \t    \tMaximum\tAverage\n");
        table.append ("trial\tGens\tFitness\tFitness\n");
        table.setFont(new Font("Monospaced", Font.PLAIN, 12));
        table.setEditable(false);
        
        JScrollPane scroller = new JScrollPane(table);
        scroller.setPreferredSize(new Dimension(260,250));
        c.add(scroller);
        
        setResizable(false);
        //setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        pack();   
    }
    
    /**
     * Append a data line to this DataTable. 
     * 
     * @param t the trial number.
     * @param g the number of generations to find a solution.
     * @param m the maximum fitness.
     * @param a the average fitness.
     */
    public void append(int t, int g, int m, int a) {
        table.append(t + "\t" + g + "\t" + m + "\t" + a + "\n");
    }
    
    /**
     * Append a summary data line to this DataTable. 
     * 
     * @param type the type of summary information (e.g. Mean, Standard Deviation)
     * @param g summary for the number of generations to find a solution.
     * @param m summary for the maximum fitness.
     * @param a summary for the average fitness.
     */    
    public void appendSummary(String type, double g, double m, double a) {
        DecimalFormat df = new DecimalFormat("0.00");
        table.append("\n" + type + "\n");
        table.append("\t" + df.format(g) + "\t" + df.format(m) + 
        "\t" + df.format(a) + "\n");
    }
    
    /**
     * Clear this DataTable.
     */
    public void clear() {
        table.setText("     \t    \tMaximum\tAverage\n");
        table.append ("trial\tGens\tFitness\tFitness\n");
    }
}
