import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Write a description of class Test here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MazeRunnerGUI extends JFrame implements ActionListener
{
    private MazeDisplayPanel mazePanel;
    private Maze curMaze;
    private JButton runExp;
    private JButton stop;
    private JButton haltTrial;
    private JTextField popSize;
    private JTextField muRate;
    private JTextField tourneySize;
    private JTextField trials;
    private JComboBox reproduce;
    private JComboBox mazeSizeBox;
    private JLabel maxFitness;
    private JLabel aveFitness;
    private JLabel generation;
    private JLabel trial;
    
    private int mazeSize;
    
    private DataTable dataTable;
    
    private GAExpRunner expRunner;
    private javax.swing.Timer expTimer;   
     
    public MazeRunnerGUI() {
        
        setTitle("Maze Runner");
        dataTable = new DataTable("Maze Runner Data");
        
        Container contentPane = getContentPane();
        
        Box fullWindow = Box.createHorizontalBox();
        
        Box controls = Box.createVerticalBox();
        controls.add(Box.createVerticalStrut(5));
        Box expContHead = Box.createHorizontalBox();
        expContHead.add(Box.createHorizontalGlue());
        expContHead.add(new JLabel("Experiment Controls"));
        expContHead.add(Box.createHorizontalGlue());
        controls.add(expContHead);
        controls.add(Box.createVerticalStrut(5));
        
        Box reprodBox = Box.createHorizontalBox();
        reprodBox.add(Box.createHorizontalGlue());
        reprodBox.add(new JLabel("Reproduce: "));
        reproduce = new JComboBox(new String[] {"Asexually",
            "Sexually"} );
        reproduce.addActionListener(this);
        reproduce.setMaximumSize(reproduce.getMinimumSize());
        reprodBox.add(reproduce);
        reprodBox.add(Box.createHorizontalGlue());
        controls.add(reprodBox);
        controls.add(Box.createVerticalStrut(5));
        
        Box popSizeBox = Box.createHorizontalBox();
        popSizeBox.add(Box.createHorizontalGlue());
        popSizeBox.add(new JLabel("Population Size: "));
        popSize = new JTextField("100", 4);
        popSize.setMaximumSize(popSize.getPreferredSize());
        popSizeBox.add(popSize);
        popSizeBox.add(Box.createHorizontalGlue());
        popSizeBox.setMaximumSize(popSizeBox.getPreferredSize());
        controls.add(popSizeBox);
        controls.add(Box.createVerticalStrut(5));
        
        Box muRateBox = Box.createHorizontalBox();
        muRateBox.add(Box.createHorizontalGlue());
        muRateBox.add(new JLabel("Mutation Rate: "));
        muRate = new JTextField("0.08", 6);
        muRate.setMaximumSize(muRate.getPreferredSize());
        muRateBox.add(muRate);
        muRateBox.add(Box.createHorizontalGlue());
        muRateBox.setMaximumSize(muRateBox.getPreferredSize());
        controls.add(muRateBox);
        controls.add(Box.createVerticalStrut(5));
        
        Box tourneySizeBox = Box.createHorizontalBox();
        tourneySizeBox.add(Box.createHorizontalGlue());
        tourneySizeBox.add(new JLabel("Tournament Size: "));
        tourneySize = new JTextField("10", 4);
        tourneySize.setMaximumSize(tourneySize.getPreferredSize());
        tourneySizeBox.add(tourneySize);
        tourneySizeBox.add(Box.createHorizontalGlue());
        tourneySizeBox.setMaximumSize(tourneySizeBox.getPreferredSize());
        controls.add(tourneySizeBox);
        controls.add(Box.createVerticalStrut(5));        
        
        Box mazeBox = Box.createHorizontalBox();
        mazeBox.add(Box.createHorizontalGlue());
        mazeBox.add(new JLabel("Maze Size: "));
        mazeSizeBox = new JComboBox(new String[] {"Small", "Medium", "Large"} );
        mazeSizeBox.setSelectedIndex(0);
        mazeSizeBox.setActionCommand("NewMazeSize");
        mazeSize = 7;
        mazeSizeBox.addActionListener(this);
        mazeSizeBox.setMaximumSize(mazeSizeBox.getPreferredSize());
        mazeBox.add(mazeSizeBox);
        mazeBox.add(Box.createHorizontalGlue());
        mazeBox.setMaximumSize(mazeBox.getPreferredSize());
        controls.add(mazeBox);
        controls.add(Box.createVerticalStrut(5));   
       
        Box trialsBox = Box.createHorizontalBox();
        trialsBox.add(Box.createHorizontalGlue());
        trialsBox.add(new JLabel("Trials: "));
        trials = new JTextField("1", 4);
        trials.setMaximumSize(trials.getPreferredSize());
        trialsBox.add(trials);
        trialsBox.add(Box.createHorizontalGlue());
        trialsBox.setMaximumSize(trialsBox.getPreferredSize());
        controls.add(trialsBox);
        controls.add(Box.createVerticalStrut(5));        
        
        Box runBox = Box.createHorizontalBox();
        runBox.add(Box.createHorizontalGlue());
        runExp = new JButton("Run Experiment");
        runExp.addActionListener(this);
        runBox.add(runExp);
        runBox.add(Box.createHorizontalGlue());
        //runBox.setMaximumSize(runBox.getMinimumSize());
        controls.add(runBox);
        controls.add(Box.createVerticalStrut(5)); 
        
        Box stopBox = Box.createHorizontalBox();
        stopBox.add(Box.createHorizontalGlue());
        stop = new JButton("Stop Experiment");
        stop.setEnabled(false);
        stop.addActionListener(this);
        stopBox.add(stop);
        stopBox.add(Box.createHorizontalStrut(10));
        haltTrial = new JButton("Halt Trial");
        haltTrial.setEnabled(false);
        haltTrial.addActionListener(this);
        stopBox.add(haltTrial);
        stopBox.add(Box.createHorizontalGlue());
        //runBox.setMaximumSize(runBox.getMinimumSize());
        controls.add(stopBox);
        
        controls.add(Box.createVerticalStrut(5));
        JSeparator js = new JSeparator();
        js.setMaximumSize(new Dimension(1000,5));
        controls.add(js);
        controls.add(Box.createVerticalStrut(5));
        
        Box expStatusHead = Box.createHorizontalBox();
        expStatusHead.add(Box.createHorizontalGlue());
        expStatusHead.add(new JLabel("Experiment Status"));
        expStatusHead.add(Box.createHorizontalGlue());
        
        controls.add(expStatusHead);
        controls.add(Box.createVerticalStrut(5));
        
        Box dataBox = Box.createHorizontalBox();
        
        Box dataLabelsBox = Box.createVerticalBox();
        dataLabelsBox.setAlignmentX(1);
        
        Box trialBox = Box.createHorizontalBox();
        trialBox.add(Box.createHorizontalGlue());
        trialBox.add(new JLabel("Trial: "));
        dataLabelsBox.add(trialBox);
        
        Box genBox = Box.createHorizontalBox();
        genBox.add(Box.createHorizontalGlue());
        genBox.add(new JLabel("Generation: "));
        dataLabelsBox.add(genBox);
        
        Box aveFitBox = Box.createHorizontalBox();
        aveFitBox.add(Box.createHorizontalGlue());
        aveFitBox.add(new JLabel("Average Fitness: "));
        dataLabelsBox.add(aveFitBox);
        
        Box maxFitBox = Box.createHorizontalBox();
        maxFitBox.add(Box.createHorizontalGlue());
        maxFitBox.add(Box.createHorizontalStrut(10));
        maxFitBox.add(new JLabel("Maximum Fitness: "));
        dataLabelsBox.add(maxFitBox);
        
        dataLabelsBox.setMaximumSize(dataLabelsBox.getMinimumSize());
        dataBox.add(dataLabelsBox);
        
        Box dataFieldBox = Box.createVerticalBox();    
        dataFieldBox.setAlignmentX(0);
        trial = new JLabel("0");
        trial.setMinimumSize(trial.getPreferredSize());
        dataFieldBox.add(trial);
        generation = new JLabel("0");
        dataFieldBox.add(generation);
        aveFitness = new JLabel("0");
        dataFieldBox.add(aveFitness);
        maxFitness = new JLabel("0");
        dataFieldBox.add(maxFitness);
        dataBox.add(dataFieldBox);

        dataBox.add(Box.createHorizontalGlue());
        
        Box mazePanelBox = Box.createHorizontalBox();
        mazePanel = new MazeDisplayPanel();
        curMaze = getNewMaze();
        mazePanel.setCurrentMaze(curMaze);
        mazePanelBox.add(mazePanel);
        mazePanelBox.setMinimumSize(new Dimension(350,350));
        mazePanelBox.setPreferredSize(new Dimension(350,350));
        mazePanelBox.setMaximumSize(new Dimension(350,350));
        fullWindow.add(mazePanelBox);
        
        controls.add(dataBox);
        
        controls.add(Box.createVerticalStrut(5));
        js = new JSeparator();
        js.setMaximumSize(new Dimension(1000,5));
        controls.add(js);
        
        controls.add(Box.createVerticalGlue());
        fullWindow.add(controls);
        contentPane.add(fullWindow);        
        
        this.pack();
        this.setResizable(false);
    }
    
    private Maze getNewMaze() {
        UFMazeGenerator mgen = new UFMazeGenerator(); 
        Maze newMaze = mgen.generateMaze(mazeSize,mazeSize,mazePanel);
        int solLen = 0;
        int solLen10 = 0;
        int solLen01 = 0;
        do {
            do {
                newMaze = mgen.generateMaze(mazeSize,mazeSize,mazePanel);
                DFMazeSolver solver = new DFMazeSolver();
                MazeSolution soln = solver.solveMaze(newMaze, mazePanel, 0, 0);
                solLen = soln.getLength();            
            } while (solLen < 2.75*mazeSize || solLen > 3*mazeSize);
            
            // Hack because sometimes the solvers seems to think that the 
            // start of the maze is the end if it starts from somewhere other 
            // than 0,0.  It was just easier to do this than to try to figure
            // out why.
            DFMazeSolver solver = new DFMazeSolver();
            MazeSolution soln = solver.solveMaze(newMaze, mazePanel, 1, 0);
            solLen10 = soln.getLength();  
            //System.out.println(solLen10);
            soln = solver.solveMaze(newMaze, mazePanel, 0, 1);
            solLen01 = soln.getLength();
            //System.out.println(solLen01);
        } while (solLen01 == 1 || solLen10 == 1);
           
        return newMaze;
    }
     
    public void showGUI() {
        this.setVisible(true);
    }
    
    public void hideGUI() {
        this.setVisible(false);
    }
    
    public void showDataTable() {
        dataTable.setVisible(true);
    }
    
    public void hideDataTable() {
        dataTable.setVisible(false);
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Run Experiment")) {
            popSize.setEnabled(false);
            runExp.setEnabled(false);
            trials.setEnabled(false);
            reproduce.setEnabled(false);
            muRate.setEnabled(false);
            tourneySize.setEnabled(false);
            mazeSizeBox.setEnabled(false);
            haltTrial.setEnabled(true);
            stop.setEnabled(true);
            
            trial.setText("1");
            generation.setText("1");
            aveFitness.setText("0");
            maxFitness.setText("0");
            
            expRunner = new GAExpRunner();
            expTimer = new javax.swing.Timer(1,expRunner);
            expTimer.start();
        }
        else if (e.getActionCommand().equals("Stop Experiment")) {
            
            if (expTimer != null) {
                expTimer.stop();
            }   
            stop.setEnabled(false);
            haltTrial.setEnabled(false);
            popSize.setEnabled(true);
            runExp.setEnabled(true);
            trials.setEnabled(true);
            reproduce.setEnabled(true);
            tourneySize.setEnabled(true);
            mazeSizeBox.setEnabled(true);
            muRate.setEnabled(true);
        }
        else if (e.getActionCommand().equals("NewMazeSize")) {
            mazeSize = 5 * (mazeSizeBox.getSelectedIndex() + 1) + 2;            
            curMaze = getNewMaze();
            mazePanel.setCurrentMaze(curMaze);
            mazePanel.setCurrentSolution(null);
        }
        else if (e.getActionCommand().equals("Halt Trial")) {
            expRunner.haltCurrentTrial();
        }
    }
    
    class GAExpRunner implements ActionListener {
        
        private int totTrials;
        private int trialNum;
        private int populationSize;
        private boolean sexualReprod;
        private int numGenes;
        private double mutationRate;
        private int tSize;
        private GeneticAlgorithm ga;
        private double[] genData;
        private double[] maxFitData;
        private double[] aveFitData;
        
        public GAExpRunner() {
            totTrials = Integer.parseInt(trials.getText()); 
            genData = new double[totTrials];
            maxFitData = new double[totTrials];
            aveFitData = new double[totTrials];
            trialNum = 1;
            populationSize = Integer.parseInt(popSize.getText());
            sexualReprod = ((String)reproduce.getSelectedItem()).equals("Sexually");
            mutationRate = Double.parseDouble(muRate.getText());
            tSize = Integer.parseInt(tourneySize.getText());
            
            // set number of genes to be % over actual solution length.
            DFMazeSolver solver = new DFMazeSolver();
            MazeSolution soln = solver.solveMaze(curMaze, mazePanel, 0, 0);
            int solLen = soln.getLength();
            numGenes = (int) (solLen * 2);
            
            dataTable.clear();
        }
        
        public synchronized void haltCurrentTrial() {
             int maxFit = ga.getPopulation().getFittestIndividual().getFitness();
             int aveFit = ga.getPopulation().getAverageFitness();
             int genNum = ga.getGeneration();
                    
             dataTable.append(trialNum, genNum, maxFit, aveFit);
             genData[trialNum-1] = genNum;
             maxFitData[trialNum-1] = maxFit;
             aveFitData[trialNum-1] = aveFit;
                    
             // setup to start a new trial on next timer tick.
             ga = null;
             trialNum++;
        }
        
        public synchronized void actionPerformed(ActionEvent e) {
            if (trialNum > totTrials) {
                expTimer.stop();
                stop.setEnabled(false);
                haltTrial.setEnabled(false);
                popSize.setEnabled(true);
                runExp.setEnabled(true);
                trials.setEnabled(true);
                reproduce.setEnabled(true);
                tourneySize.setEnabled(true);
                muRate.setEnabled(true);
                mazeSizeBox.setEnabled(true);
                
                dataTable.appendSummary("Mean Values:", BasicStatistics.getMean(genData),
                BasicStatistics.getMean(maxFitData), BasicStatistics.getMean(aveFitData));
                
                if (totTrials > 1) {
                    dataTable.appendSummary("Standard Deviation:", BasicStatistics.getStdDev(genData),
                    BasicStatistics.getStdDev(maxFitData), BasicStatistics.getStdDev(aveFitData));
                 } 
            }
            else if (ga == null) {
                // start a trial 
                mazePanel.setCurrentSolution(null);
                ga = new GeneticAlgorithm(populationSize, sexualReprod, mutationRate,
                    tSize, numGenes, curMaze, mazePanel);
                trial.setText("" + trialNum);
            }
            else {
                int maxFit = ga.getPopulation().getFittestIndividual().getFitness();
                int aveFit = ga.getPopulation().getAverageFitness();
                int genNum = ga.getGeneration();
                
                MazeSolution fittestPath = mazePanel.getCurrentSolution();
                if (fittestPath != null && fittestPath.solutionComplete()) {   
                    dataTable.append(trialNum, genNum, maxFit, aveFit);
                    genData[trialNum-1] = genNum;
                    maxFitData[trialNum-1] = maxFit;
                    aveFitData[trialNum-1] = aveFit;
                    
                    // setup to start a new trial on next timer tick.
                    ga = null;
                    trialNum++;
                }
                else {
                    // run a generation of the current trial
                    ga.nextGeneration();
                    generation.setText("" + ga.getGeneration());
                    Individual fittest = ga.getPopulation().getFittestIndividual();
                    maxFit = fittest.getFitness();
                    maxFitness.setText("" + maxFit);
                    aveFit = ga.getPopulation().getAverageFitness();
                    aveFitness.setText("" + aveFit);  
                    
                    // display the best individual.
                    fittestPath = ga.getIndividualPath(fittest);
                    mazePanel.setCurrentSolution(fittestPath);
                }
            }
        }       
    }
}   
