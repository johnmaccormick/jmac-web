import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import javax.swing.event.*;
import java.io.File;

public class AddSongDialog extends JDialog {

    JTextField songNameField;
    JTextField albumNameField;
    JTextField artistNameField;
    JTextField trackNumField;
    JTextField fileNameField;
    JButton fileChooserButton;
    JFileChooser fileChooser;
    JButton addButton;
    JButton cancelButton;
    ActionListener fileChooserListener;
    
    boolean validAdd;
    boolean opCancelled;
    
    int trackNum;
    String fullPath;
    boolean pathSet;
    
    /**
     * Construct a new dialog with no parent frame.
     */
    public AddSongDialog() {
        this(null, true);
        pathSet = false;
    }
    
    /**
     * Construct a new dialog with given parent frame.
     */
    public AddSongDialog(Frame parent, boolean modal) {
    
        super(parent, modal);
        
        setTitle("Enter Data For Song to Add to the Library");
        
        JLabel dummyLabel;

        JPanel textFieldPanel = new JPanel();
        {            
            textFieldPanel.setLayout(new GridLayout(5, 3, 0, 5));

            JLabel songNameLabel = new JLabel("Enter song name:");
            textFieldPanel.add(songNameLabel);

            songNameField = new JTextField(30);
            textFieldPanel.add(songNameField);
            
            dummyLabel = new JLabel("    ");
            textFieldPanel.add(dummyLabel);

        
            JLabel artistNameLabel = new JLabel("Enter artist name:");
            textFieldPanel.add(artistNameLabel);

            artistNameField = new JTextField(30);
            textFieldPanel.add(artistNameField);

            dummyLabel = new JLabel("   ");
            textFieldPanel.add(dummyLabel);

            JLabel albumNameLabel = new JLabel("Enter album name:");
            textFieldPanel.add(albumNameLabel);

            albumNameField = new JTextField(30);
            textFieldPanel.add(albumNameField);

            dummyLabel = new JLabel("   ");
            textFieldPanel.add(dummyLabel);          
            
            JLabel fileNameLabel = new JLabel("Browse for song file:");
            textFieldPanel.add(fileNameLabel);

            fileNameField = new JTextField(30);
            textFieldPanel.add(fileNameField);
            fileNameField.setEditable(false);

            fileChooserButton = new JButton("Browse");
            textFieldPanel.add(fileChooserButton, BorderLayout.SOUTH);
            
        }
        
        JPanel browseButtonPanel = new JPanel();
        
        // initialize buttons
        addButton = new JButton("Add");
        cancelButton = new JButton("Cancel");
        // group buttons
        JPanel buttonPanel = new JPanel();
        {
            buttonPanel.setLayout(new BorderLayout(10, 0));
            buttonPanel.add(addButton, BorderLayout.WEST);
            buttonPanel.add(cancelButton, BorderLayout.EAST);
        }
        
        getContentPane().add(textFieldPanel, BorderLayout.NORTH);
        JPanel spacer = new JPanel();
        dummyLabel = new JLabel("   ");
        spacer.add(dummyLabel);
        getContentPane().add(spacer, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        
        Dimension d = getSize();
        
        setSize(600, (int)d.getHeight());
        
        d = getSize();
        
        fileChooserButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                    openChooserAndProcessResponse();
                }
        });
        
        addButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                    if(setAndCheckValues() == true) {
                        validAdd = true;

                        setVisible(false);
                    } else {
                        validAdd = false;
                    }
                    opCancelled = false;
                }
        });

        cancelButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                    opCancelled = true;
                    setVisible(false);
                }
        });
        
    
    }
    
    // Clear fields in add song dialog.
    private void clearAllFields() {
    
        songNameField.setText("");
        artistNameField.setText("");
        albumNameField.setText("");
        trackNumField.setText("");
        fileNameField.setText("");
        pathSet = false; // for next use
    
    }
    
    private class MP3Filter extends FileFilter {
        public boolean accept(File f) {
            return f.getName().endsWith(".mp3") ||
                   f.getName().endsWith(".MP3") ||
                   f.getName().endsWith(".Mp3") ||
                   f.isDirectory();
        }
        
        public String getDescription() {
            return "MP3 files";
        }
    }
    
    /**
     * Opens a file chooser and processes the response.
     */
    public void openChooserAndProcessResponse() {
    
        // Get the current working directory.
        String startingPath = System.getProperty("user.dir");
        fileChooser = new JFileChooser(startingPath + "/music");
        fileChooser.setFileFilter(new MP3Filter());
                
        int returnValue = fileChooser.showOpenDialog(this);
        if(returnValue == JFileChooser.APPROVE_OPTION) {
                    
            fileNameField.setEditable(false);
            
            File selectedFile = fileChooser.getSelectedFile();
                        
            if(selectedFile.canRead()) {
            
                String fileName = selectedFile.getName();
  
                fullPath = selectedFile.getAbsolutePath();
                
                String currentDirName = System.getProperty("user.dir");
                
                if (fullPath.contains(currentDirName)) {
                    fileNameField.setText(fileName);
                    String pathWithoutPrefix = fullPath.replaceFirst(currentDirName, "");
                    fullPath = pathWithoutPrefix.replaceFirst("/", "");
                    pathSet = true;
                }
                else {
                    JOptionPane.showMessageDialog(null, "Music files must be located within the DPod project.");
                    //fileNameField.setEditable(true);
                }
                            
            } else {
                String message = "File selected is not readable; try again.";
                JOptionPane.showMessageDialog(null, message, "add Song Dialog Message", 
                                              JOptionPane.WARNING_MESSAGE);
                //fileNameField.setEditable(true);
            }
        }           
    }
    
    private boolean fieldIsEmpty(String fieldName, String fieldContents) {
    
        if(fieldContents.equals("")) { // if textfield is empty, reprompt user
        
            String message = fieldName + " text box is empty; try again.";
            JOptionPane.showMessageDialog(null, message, "add Song Dialog Message", 
                                        JOptionPane.WARNING_MESSAGE);
            return true;
        
        } else {
            return false;
        }
        
    }
    
    
    // Check whether values entered are valid.
    private boolean setAndCheckValues() {
    
        if(fieldIsEmpty("Song name", songNameField.getText())) {
            return false; // user entered nothing in the textfield
        }
        
        if(fieldIsEmpty("Artist name", artistNameField.getText())) {
            return false; // user entered nothing in the textfield
        }

        if(fieldIsEmpty("Album name", albumNameField.getText())) {
            return false; // user entered nothing in the textfield
        }

        if(fieldIsEmpty("File name", fileNameField.getText())) {
            return false; // user entered nothing in the textfield
        }
        
    
        if(pathSet == false) { // fullPath not set via JFileChooser
        
            if(fieldIsEmpty("File name", fileNameField.getText())) {
                return false; // user entered nothing in the textfield
            }
            
            fullPath = fileNameField.getText();
            File testHandle = new File(fullPath);
        
            if( ! testHandle.canRead() )  {
                String message = "File selected is not readable; try again.";
                JOptionPane.showMessageDialog(null, message, "add Song Dialog Message", 
                                              JOptionPane.WARNING_MESSAGE);
                fullPath = null;
                return false;
            }
            pathSet = true;
        }
        
        
        return true;
    
    }
    
 
    /**
     * Returns true if add was valid.
     */
    public boolean addIsValid() {
        return validAdd;
    }
   
    /**
     * Returns true if add was cancelled.
     */
    public boolean addWasCancelled() {
        return opCancelled;
    }
   
    /**
     * Returns the song name entered via the dialog.
     */
    public String getSongName() {
        return songNameField.getText();
    }
    
    /**
     * Returns the artist name entered via the dialog.
     */
    public String getArtistName() {
        return artistNameField.getText();
    }
    
    /**
     * Returns the album name entered via the dialog.
     */
    public String getAlbumName() {
        return albumNameField.getText();
    }

    /**
     * Returns the file name entered via the dialog.
     */
    public String getFileName() {
        return fullPath;
    }

}