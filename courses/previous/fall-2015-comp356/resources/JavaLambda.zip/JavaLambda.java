
public class JavaLambda {

	public static void printSomeNumbers(CheckNumber checker) {
		for (int i = 0; i < 20; i++) {
			if (checker.test(i)) {
				System.out.println(i);
			}
		}
	}

	public static void main(String[] args) {
		System.out.println("Numbers less than five: ");
		printSomeNumbers( (int n) -> n<5 );

		System.out.println("Even numbers: ");
		printSomeNumbers( (int n) -> n%2==0 );

		System.out.println("Even numbers less than five: ");
		printSomeNumbers( (int n) -> n%2==0 && n<5);
	}
}
