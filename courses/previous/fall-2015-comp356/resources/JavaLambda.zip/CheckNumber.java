
public interface CheckNumber {
	boolean test(int n);
}
