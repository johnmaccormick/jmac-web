/** handcrafted token values for use with LexTest.java
 */
class sym
{
    public static final int EOF = 0;
    public static final int ADDOP = 1;
    public static final int LPAR = 2;
    public static final int MULOP = 3;
    public static final int NUM = 4;
    public static final int RPAR = 5;
    public static final int SEMI = 6;
    public static final int FACTORIAL = 7;
    public static final int HEX = 8;
}
