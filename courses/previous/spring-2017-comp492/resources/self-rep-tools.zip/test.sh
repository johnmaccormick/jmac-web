gcc thompson-program.c -o 1.exe
./1.exe > 2.c
gcc 2.c -o 2.exe
./2.exe > 3.txt
diff 2.c 3.txt 
