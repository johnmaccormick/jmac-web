#include <stdio.h>
#include <stdlib.h>
int main(int argn, char** argv) {
  if (argn != 2) {
    printf("Please provide exactly one string argument.\n");
    exit(0);
  }
  char* str = argv[1];
  char c = str[0];
  int i = 0;
  while (c!=0) {
    printf("'%c',\n", c);
    i++;
    c = str[i];
  } 
}
