#include <iostream>

using namespace std;

extern int NUM_STUDENTS;

void print_num_students()
{
  int a,b,c;
  cout << "The value of NUM_STUDENTS is " << NUM_STUDENTS << endl;
}

