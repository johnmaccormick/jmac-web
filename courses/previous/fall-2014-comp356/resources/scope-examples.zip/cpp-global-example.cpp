#include <iostream>
#include "cpp-global-example2.h"

using namespace std;

int NUM_STUDENTS = 9;



int main(int argc, char** argv)
{
  int NUM_STUDENTS = 53;

  cout << "The value of NUM_STUDENTS is " << NUM_STUDENTS << endl;
  cout << "The value of ::NUM_STUDENTS is " << ::NUM_STUDENTS << endl;

  print_num_students();


}
