import java.util.ArrayList;
import java.util.List;

/**
 * A NestedLoopPairSum object solves instances of the pair-sum problem
 * using a nested loop.
 * 
 * @author jmac
 *
 */
public class NestedLoopPairSum extends PairSum {

	public NestedLoopPairSum(List<Integer> valsList) {
		super(valsList);
	}

	@Override
	Pair searchForPairSum(int targetSum) {
		for (int i = 0; i < availableIntegers.size(); i++) {
			int val1 = availableIntegers.get(i);
			for (int j = 0; j < availableIntegers.size(); j++) {
				int val2 = availableIntegers.get(j);
				if (val1 + val2 == targetSum) {
					return new Pair(val1, val2);
				}
			}
		}
		// Didn't find any pair summing to the target value.
		return null;
	}

}
