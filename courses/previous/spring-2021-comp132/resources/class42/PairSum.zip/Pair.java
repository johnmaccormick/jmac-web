/**
 * Represents a solution to the pair-sum problem: a pair of integers that
 * sum to the desired target value.
 */
public class Pair {
	private int val1;
	private int val2;

	/**
	 * Create a new pair representing a solution to the pair-sum problem.
	 * 
	 * @param val1 The first value of the pair
	 * @param val2 The second value of the pair
	 */
	public Pair(int val1, int val2) {
		this.val1 = val1;
		this.val2 = val2;
	}

	/**
	 * @return the val1
	 */
	public int getVal1() {
		return val1;
	}

	/**
	 * @return the val2
	 */
	public int getVal2() {
		return val2;
	}

	@Override
	public String toString() {
		return "[val1=" + val1 + ", val2=" + val2 + "]";
	}
}
