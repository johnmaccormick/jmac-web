import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A SortedPairSum object solves instances of the pair-sum problem
 * by first sorting the list and then employing binary search.
 * 
 * @author jmac
 *
 */
public class SortedPairSum extends PairSum {
	public SortedPairSum(List<Integer> valsList) {
		super(valsList);
		Collections.sort(valsList);
	}

	@Override
	Pair searchForPairSum(int targetSum) {
		for (int i = 0; i < availableIntegers.size(); i++) {
			int currentVal = availableIntegers.get(i);
			int neededVal = targetSum - currentVal;
			int location = Collections.binarySearch(availableIntegers, neededVal);
			if (location >= 0) {
				return new Pair(currentVal, neededVal);
			}
		}
		// Didn't find any pair summing to the target value.
		return null;
	}

}
