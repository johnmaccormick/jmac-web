import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Demonstration of the effect of different algorithms on efficiency of
 * solving a simple problem: given a list of integers and a target value,
 * can we express that target value as the sum of two of the integers?
 * 
 * @author jmac
 *
 */
public abstract class PairSum {
	// List of integers in which we will search to find a pair that sum to
	// a given target value.
	protected ArrayList<Integer> availableIntegers;

	/**
	 * Search for a pair of integers in this object's list that sum to a
	 * given target value.
	 * 
	 * Note that it is permitted to use the same value twice in making the
	 * target sum.
	 * 
	 * @param targetSum The target value T: we are searching for list
	 *                  elements e1, e2 such that e1+e2=T
	 * @return If there exists any pair of integers in the list that sum to
	 *         the target value, return one of these pairs. Otherwise
	 *         return null.
	 */
	abstract Pair searchForPairSum(int targetSum);

	/**
	 * Create a new object that can solve the pair-sum problem for a given
	 * list of integers.
	 * 
	 * @param availableIntegers The integers that can be combined in pairs to produce
	 *                a target value and thus solve the pair-sum problem
	 */
	public PairSum(List<Integer> availableIntegers) {
		this.availableIntegers = new ArrayList<>(availableIntegers);
	}


	/**
	 * Run a number of timed trials of the pair-sum problem.
	 * 
	 * @param p The PairSum object to be used in the trials.
	 * @param numTrials The number of trials to run.
	 * @return The number of nanoseconds required for all trials.
	 */
	private static long timedTrials(PairSum p, int numTrials) {
		long startNanos, endNanos;
		long totalNanos = 0;
		int target = -1;
		for (int t = 0; t < numTrials; t++) {
			startNanos = System.nanoTime();
			p.searchForPairSum(target);
			endNanos = System.nanoTime();
			totalNanos += (endNanos - startNanos);
		}
		return totalNanos;
	}

	public static void main(String[] args) {
		int[] numIntsArr = new int[] { 100, 1000, 5000, 8000, 10000, 13000,
				17000, 20000 };
		int numTrials = 10;
		System.out.println("n\tloop\tsorted\thashSet");
		for (int numInts : numIntsArr) {
			ArrayList<Integer> vals = ArrayListTools
					.getRandomIntArrayList(0, numInts, numInts);
			NestedLoopPairSum loop = new NestedLoopPairSum(vals);
			SortedPairSum sorted = new SortedPairSum(vals);
			HashSetPairSum hashSet = new HashSetPairSum(vals);
			long loopNanos = timedTrials(loop, numTrials);
			long sortedNanos = timedTrials(sorted, numTrials);
			long hashSetNanos = timedTrials(hashSet, numTrials);

			DecimalFormat df = new DecimalFormat("0.00000");
			System.out.print(numInts + "\t");
			for (long nanos : new long[] { loopNanos, sortedNanos,
					hashSetNanos }) {
				System.out.print(
						df.format(nanos / 1.0e9 / numTrials) + "\t");
				System.out.flush();
			}
			System.out.println();
		}
	}
}
