import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * A HashSetPairSum object solves instances of the pair-sum problem by
 * storing the list of available integers as a hash set, whose membership
 * can therefore be checked in constant time.
 * 
 * @author jmac
 *
 */
public class HashSetPairSum extends PairSum {
	private HashSet<Integer> availableIntegersSet;

	public HashSetPairSum(List<Integer> valsList) {
		super(valsList);
		availableIntegersSet = new HashSet<>(valsList);
	}

	@Override
	Pair searchForPairSum(int targetSum) {
		for (int i = 0; i < availableIntegers.size(); i++) {
			int currentVal = availableIntegers.get(i);
			int neededVal = targetSum - currentVal;
			if (availableIntegersSet.contains(neededVal)) {
				return new Pair(currentVal, neededVal);
			}
		}
		// Didn't find any pair summing to the target value.
		return null;
	}

}
