import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A SortedPairSum object solves instances of the pair-sum problem by first
 * sorting the list and then employing binary search.
 * 
 * @author jmac
 *
 */
public class SortedPairSumUnfinished extends PairSum {
	public SortedPairSumUnfinished(List<Integer> valsList) {
		super(valsList);
		Collections.sort(valsList);
	}

	@Override
	Pair searchForPairSum(int targetSum) {
		for (int i = 0; i < availableIntegers.size(); i++) {
			int currentVal = availableIntegers.get(i);
			int neededVal = targetSum - currentVal;
			// TODO: Determine if neededVal is available (via binary
			// search) and return an appropriate Pair if so.
		}
		// Didn't find any pair summing to the target value.
		return null;
	}

}
