package singleton;

public class Banana extends Fruit {

}
