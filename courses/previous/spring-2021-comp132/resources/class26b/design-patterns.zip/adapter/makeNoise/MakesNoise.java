package adapter.makeNoise;

public interface MakesNoise {
   int getVolume();
}
