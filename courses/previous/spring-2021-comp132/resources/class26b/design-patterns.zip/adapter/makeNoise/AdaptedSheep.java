package adapter.makeNoise;

import adapter.makeSounds.Sheep;

/**
 * AdaptedSheep is a wrapper class that demonstrates the use of the Adapter
 * pattern.
 * 
 * @author jmac
 *
 */
public class AdaptedSheep implements MakesNoise {
	private Sheep sheep;

	public AdaptedSheep(Sheep sheep) {
		this.sheep = sheep;
	}

	@Override
	public int getVolume() {
		return sheep.howLoud();
	}
}
