package adapter.makeNoise;

public class Horse implements MakesNoise {

	@Override
	public int getVolume() {
		return 9;
	}

}
