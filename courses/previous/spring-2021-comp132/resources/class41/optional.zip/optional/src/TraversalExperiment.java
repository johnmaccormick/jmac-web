import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.stream.Stream;

public class TraversalExperiment {
	ListADT words;

	public static final String WORD_FILENAME = "data/words_alpha.txt";
//	public static final String WORD_FILENAME = "data/words_alpha_temp.txt";
	public static final String SEARCH_STRING = "x";
	public static final int NUM_TRIALS = 10;
//	public static final int[] TRAVERSAL_SIZES = new int[] { 500000, 100000, 200000, 300000, 400000 };
	public static final int[] TRAVERSAL_SIZES = new int[] { 1000, 2000,
			3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000 };

	public TraversalExperiment(ListADT words) {
		this.words = words;
		addWords();
	}

	private int traverseWithFor(int n) {
		int count = 0;
		for (int i = 0; i < n; i++) {
			String s = (String) words.get(i);
			if (s.contains(SEARCH_STRING)) {
				count++;
			}
		}
		return count;
	}

	private int traverseWithForEach(int n) {
		int count = 0;
		int iterations = 0;
		for (Object word : words) {
			String s = (String) word;
			if (s.contains(SEARCH_STRING)) {
				count++;
			}
			iterations++;
			if (iterations > n) {
				break;
			}
		}
		return count;
	}

	public void doExperiment() {
		for (int numToTraverse : TRAVERSAL_SIZES) {
			System.out.print(numToTraverse + "\t");
			System.out.flush();
			long totalForNanos = 0;
			long totalForEachNanos = 0;
			long startNanos, endNanos;
			for (int t = 0; t < NUM_TRIALS; t++) {
				startNanos = System.nanoTime();
				traverseWithFor(numToTraverse);
				endNanos = System.nanoTime();
				totalForNanos = totalForNanos + (endNanos - startNanos);
				startNanos = System.nanoTime();
				traverseWithForEach(numToTraverse);
				endNanos = System.nanoTime();
				totalForEachNanos = totalForEachNanos
						+ (endNanos - startNanos);
			}
			DecimalFormat df = new DecimalFormat("0.00000");
			System.out.print(
					df.format(totalForNanos / 1.0e9 / NUM_TRIALS) + "\t");
			System.out.flush();
			System.out.println(
					df.format(totalForEachNanos / 1.0e9 / NUM_TRIALS));
			System.out.flush();

		}
	}

	public void print() {
//		for (int i = 0; i < words.size(); i++) {
//			System.out.println(words.get(i));
//		}

		for (Object object : words) {
			System.out.println(object);
		}
	}

	private boolean addWords() {
		try (Stream<String> lines = Files
				.lines(Paths.get(WORD_FILENAME))) {
			lines.forEach(words::add);
		} catch (IOException e) {
			System.err.println("Error: Couldn't read words from file "
					+ WORD_FILENAME);
			return false;
		}
		return words.size() > 0;
	}

	public static void main(String[] args) {
		TraversalExperiment traversalExperiment = new TraversalExperiment(
				new LinkedList132());
		traversalExperiment.doExperiment();
	}

}
