import java.util.Iterator;

public class LinkedList132Iterator implements Iterator<Object> {
	private LinkedNode current;

	public LinkedList132Iterator(LinkedList132 theList) {
		current = theList.getHead();
	}

	@Override
	public boolean hasNext() {
		return current != null;
	}

	@Override
	public Object next() {
		Object val = current.getElement();
		current = current.getNext();
		return val;
	}

}
