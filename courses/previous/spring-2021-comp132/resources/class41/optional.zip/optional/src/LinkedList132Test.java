import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LinkedList132Test {
	LinkedList132 empty;
	LinkedList132 oneNode;
	LinkedList132 twoNodes;
	LinkedList132 fiveNodes;

	private void checkList(LinkedList132 list, String[] vals) {
		assertEquals(vals.length, list.size());
		for (int i = 0; i < vals.length; i++) {
			assertEquals(vals[i], list.get(i));
		}
		if (list.size()==0) {
			assertNull(list.getHead());
			assertNull(list.getTail());
		} else {
			assertEquals(vals[0], list.getHead().getElement());
			assertEquals(vals[vals.length-1], list.getTail().getElement());
		}
	}

	@BeforeEach
	void setUp() throws Exception {
		empty = new LinkedList132();

		oneNode = new LinkedList132();
		oneNode.add("a");

		twoNodes = new LinkedList132();
		twoNodes.add("a");
		twoNodes.add("b");

		fiveNodes = new LinkedList132();
		fiveNodes.add("a");
		fiveNodes.add("b");
		fiveNodes.add("c");
		fiveNodes.add("d");
		fiveNodes.add("e");
	}

	@Test
	void testLinkedList132() {
		checkList(empty, new String[] {});
		checkList(oneNode, new String[] { "a" });
		checkList(twoNodes, new String[] { "a", "b" });
		checkList(fiveNodes, new String[] { "a", "b", "c", "d", "e" });
	}

	@Test
	void testGet() {
		assertEquals("a", oneNode.get(0));
		assertEquals("a", twoNodes.get(0));
		assertEquals("b", twoNodes.get(1));
		assertEquals("a", fiveNodes.get(0));
		assertEquals("b", fiveNodes.get(1));
		assertEquals("c", fiveNodes.get(2));
		assertEquals("d", fiveNodes.get(3));
		assertEquals("e", fiveNodes.get(4));
	}
	
	@Test
	void testGetInvalid() {
		assertThrows(IndexOutOfBoundsException.class, () -> {
			empty.get(-1);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			empty.get(-5);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			empty.get(0);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			oneNode.get(1);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			oneNode.get(2);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			oneNode.get(3);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.get(5);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.get(10);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.get(-4);
		});

	}

	@Test
	void testSet() {
		oneNode.set(0, "z");
		checkList(oneNode, new String[] { "z" });
		twoNodes.set(0, "x");
		checkList(twoNodes, new String[] { "x", "b" });
		twoNodes.set(1, "y");
		checkList(twoNodes, new String[] { "x", "y" });
		fiveNodes.set(4, "z");
		checkList(fiveNodes, new String[] { "a", "b", "c", "d", "z" });
		fiveNodes.set(2, "y");
		checkList(fiveNodes, new String[] { "a", "b", "y", "d", "z" });
		fiveNodes.set(0, "x");
		checkList(fiveNodes, new String[] { "x", "b", "y", "d", "z" });
		fiveNodes.set(1, "w");
		checkList(fiveNodes, new String[] { "x", "w", "y", "d", "z" });

	}

	@Test
	void testSetInvalid() {
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.set(-1, "z");
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.set(5, "z");
		});
	}

	@Test
	void testInsert() {
		oneNode.insert(0, "q");
		checkList(oneNode, new String[] { "q", "a" });
		oneNode.insert(0, "r");
		checkList(oneNode, new String[] { "r", "q" , "a" });
		oneNode.insert(0, "s");
		checkList(oneNode, new String[] { "s", "r", "q" , "a" });
		oneNode.insert(1, "t");
		checkList(oneNode, new String[] { "s", "t", "r", "q" , "a" });
		oneNode.insert(3, "u");
		checkList(oneNode, new String[] { "s", "t", "r", "u", "q" , "a" });
	}

	@Test
	void testInsertInvalid() {
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.insert(-1, "z");
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.insert(5, "z");
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.insert(6, "z");
		});
	}

	@Test
	void testRemove() {
		String s;

		s = (String) oneNode.remove(0);
		assertEquals("a", s);
		checkList(oneNode, new String[] {});

		s = (String) twoNodes.remove(0);
		assertEquals("a", s);
		checkList(twoNodes, new String[] { "b" });

		s = (String) fiveNodes.remove(3);
		assertEquals("d", s);
		checkList(fiveNodes, new String[] { "a", "b", "c", "e" });

		fiveNodes.insert(3, "d");
		checkList(fiveNodes, new String[] { "a", "b", "c", "d", "e" });

		s = (String) fiveNodes.remove(4);
		assertEquals("e", s);
		checkList(fiveNodes, new String[] { "a", "b", "c", "d" });

//		System.out.println(fiveNodes);
		fiveNodes.add("e");
//		System.out.println(fiveNodes);
		checkList(fiveNodes, new String[] { "a", "b", "c", "d", "e" });
		
		s = (String) fiveNodes.remove(3);
		assertEquals("d", s);
		checkList(fiveNodes, new String[] { "a", "b", "c", "e" });

		s = (String) fiveNodes.remove(3);
		assertEquals("e", s);
		checkList(fiveNodes, new String[] { "a", "b", "c" });

		s = (String) fiveNodes.remove(1);
		assertEquals("b", s);
		checkList(fiveNodes, new String[] { "a", "c" });

		s = (String) fiveNodes.remove(0);
		assertEquals("a", s);
		checkList(fiveNodes, new String[] { "c" });

		s = (String) fiveNodes.remove(0);
		assertEquals("c", s);
		checkList(fiveNodes, new String[] {});
		
		fiveNodes.add("z");
		checkList(fiveNodes, new String[] {"z"});

		fiveNodes.insert(0, "y");
		checkList(fiveNodes, new String[] {"y", "z"});
	}

	@Test
	void testRemoveInvalid() {
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.remove(-1);
		});		
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.remove(5);
		});		
	}
	
	@Test
	void testToString() {
		assertEquals("", empty.toString());
		assertEquals("a", oneNode.toString());
		assertEquals("a, b", twoNodes.toString());
		assertEquals("a, b, c, d, e", fiveNodes.toString());
	}
}
