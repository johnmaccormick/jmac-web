package Bank;

/**
 * Representation of a BankCustomer that has a name, address, phone number and
 * two accounts (checking and savings).
 * 
 * @author Tim Wahls
 * 
 */
public class BankCustomer {

	private String name;
	private String address;
	private String phoneNumber;
	private Account checking;
	private Account savings;

	/**
	 * Constructor for objects of class BankCustomer
	 * 
	 * @param initName     the name of the customer
	 * @param initAddress  the address of the customer
	 * @param initPhoneNum the telephone number of the customer
	 * @param initChecking the customer's checking account
	 * @param initSavings  the customer's savings account
	 */
	public BankCustomer(String initName, String initAddress, String initPhoneNum, Account initChecking,
			Account initSavings) {
		name = initName;
		address = initAddress;
		phoneNumber = initPhoneNum;
		checking = initChecking;
		savings = initSavings;

	}

	/**
	 * return the customer's name
	 * 
	 * @return the customer's name
	 */
	public String getName() {
		return name;
	}

	/**
	 * return the customer's address
	 * 
	 * @return the customer's address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * return the customer's telephone number
	 * 
	 * @return the customer's telephone number
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * print all customer info
	 */
	public void print() {
		System.out.println("Name: " + name + " || Address:  " + address + " || Phone Number:  " + phoneNumber + " "
				+ " || Checking account number : " + checking.getAccountNumber() + " || savings account number: "
				+ savings.getAccountNumber());

	}

	/**
	 * deposit into checking account
	 * 
	 * @param depCheckAmount the amount to deposit
	 */
	public void depositChecking(int depCheckAmount) {

		checking.deposit(depCheckAmount);
	}

	/**
	 * deposit into savings account
	 * 
	 * @param depSaveAmount the amount to deposit
	 */
	public void depositSavings(int depSaveAmount) {
		savings.deposit(depSaveAmount);
	}

	/**
	 * withdraw from checking account
	 * 
	 * @param withCheckAmount the amount to withdraw
	 */
	public void withdrawChecking(int withCheckAmount) {
		checking.withdraw(withCheckAmount);
	}

	/**
	 * withdraw from savings account
	 * 
	 * @param withSaveAmount the amount to withdraw
	 */
	public void withdrawSavings(int withSaveAmount) {
		savings.withdraw(withSaveAmount);
	}

	/**
	 * get the total balance (both checking and savings accounts)
	 * 
	 * @return the total balance of the customer's checking and savings accounts
	 */
	public int getTotalBalance() {

		return checking.getBalance() + savings.getBalance();
	}

	/**
	 * transfer from savings to checking (for this customer)
	 * 
	 * @param transSCAmount the amount to transfer
	 */
	public void savingsToChecking(int transSCAmount) {

		savings.withdraw(transSCAmount);
		checking.deposit(transSCAmount);

	}

	public static void main(String[] args) {

		Account b1Checking = new Account(135);
		Account b1Savings = new Account(567);
		BankCustomer b1 = new BankCustomer("Mary", "51 Terravista Dr.", "123-456", b1Checking, b1Savings);
		b1.print();
	}

}
