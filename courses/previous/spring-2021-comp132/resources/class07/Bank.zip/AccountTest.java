package Bank;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AccountTest {
    private Account savingsAccount;

	@Before
	public void setUp() throws Exception {
        savingsAccount = new Account(23, 3);
	}

	@Test
    public void testOneParamConstructor()
    {
    	Account someAccount = new Account(242);
        assertEquals(242, someAccount.getAccountNumber());
        assertEquals(0, someAccount.getBalance());
        assertEquals(2, someAccount.getInterestRate());
    }

	@Test
    public void testNoParamConstructor()
    {
        Account someAccount = new Account();
        assertEquals(0, someAccount.getAccountNumber());
        assertEquals(0, someAccount.getBalance());
        assertEquals(2, someAccount.getInterestRate());
    }

	@Test
    public void testTwoParamConstructor()
    {
        Account someAccount = new Account(1234, 5);
        assertEquals(1234, someAccount.getAccountNumber());
        assertEquals(0, someAccount.getBalance());
        assertEquals(5, someAccount.getInterestRate());
    }

	@Test
    public void testWithdrawValid()
    {
        savingsAccount.deposit(112);
        savingsAccount.withdraw(23);
        assertEquals(89, savingsAccount.getBalance());
    }

	@Test
    public void testWithdrawOverdraft() {
        savingsAccount.deposit(85);
        savingsAccount.withdraw(111);
        assertEquals(85, savingsAccount.getBalance());
    }

	@Test
    public void testDepositValid()
    {
        savingsAccount.deposit(100);
        savingsAccount.deposit(200);
        assertEquals(300, savingsAccount.getBalance());
    }
    
	@Test
    public void testDepositNegative()
    {
        savingsAccount.deposit(-100);
        assertEquals(0, savingsAccount.getBalance());
    }



}
