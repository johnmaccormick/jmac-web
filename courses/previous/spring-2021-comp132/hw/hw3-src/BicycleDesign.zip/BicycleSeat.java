package BicycleDesign;


/**
 * A class to represent bicycle seats.
 * 
 * @author (Tim Wahls)
 * @author (YOUR NAME HERE) 
 * @version (PUT DATE HERE)
 */
public class BicycleSeat
{
    // add your fields here
    
    /**
     * Initialize a BicycleSeat as specified by the parameters
     * @param initSize the size of the seat
     * @param initColor the color of the seat
     */
    public BicycleSeat(int initSize, String initColor)
    {
        // add your code here

    }

    /**
     * get the seat size
     * @return the seat size
     */
    public int getSize()
    {
        // modify this code to return the seat size
        return 0;
    }

    /**
     * get the seat color
     * @return the seat color
     */
    public String getColor()
    {
        // modify this code to return the color
        return "green";
    }
}
