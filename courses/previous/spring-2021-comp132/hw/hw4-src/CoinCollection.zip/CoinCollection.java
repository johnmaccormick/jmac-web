package CoinCollection;

import java.util.ArrayList;

/**
 * A class that maintains information about an arbitrarily large coin collection.  
 * Individual coins may be accessed based on the order that they are inserted.  
 * 
 * @author Grant Braught, Tim Wahls, Louis Ziantz
 * @author (YOUR NAME HERE)
 * @version (PUT DATE HERE)
 */
public class CoinCollection {

    // The name of the collection
    private String collectionName;
    // The list of coins in the collection
    private ArrayList<Coin> coinList;
    
    /**
     * Create a new coin collection.
     * 
     * @param initCollName the name of the collection.
     */
    public CoinCollection(String initCollName) {
        // Add code here.
    }

    /**
     * Return the name of the CoinCollection
     * 
     * @return the name of the collection.
     */
    public String getCollectionName() { 
        // Replace with your code.
        return null;
    }
    
    /**
     * Add a coin to the collection.
     * 
     * @param coin The coin to be added to the collection.
     */
    public void addCoin(Coin coin) {  
        // Add code here
    }
    
    /**
     * Remove the Coin at the indicated index in the collection.
     * If the specified index is not valid then an error message
     * is printed.
     * 
     * @param index The index of the Coin to be removed.
     */
    public void removeCoin(int index) {
        // Add code here.
    }
    
    /**
     * Return the size of the CoinCollection
     * 
     * @return the size of the collection.
     */
    public int sizeOfCollection() { 
        // Replace with your code.
        return 0;
    }    
    
    /**
     * Print a full description of the Coin at the specified index 
     * in the collection. If the specified index is not valid then 
     * an error message is printed.  
     * 
     * @param index The index of the Coin to be printed.
     */
    public void printCoin(int index) {
        // Add code here.
        // Hint: You can call the toString method in the Coin class to get 
        // a String describing the Coin, then print that String.
    }
}
