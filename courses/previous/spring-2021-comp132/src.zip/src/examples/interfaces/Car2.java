package examples.interfaces;

/**
 * The Car2 class implements the MakesSound interface but not the Swims
 * interface.
 * 
 * @author Grant Braught, revisions by Farhan Siddiqui
 * @author Dickinson College
 * @version Aug 10, 2019
 */
public class Car2 implements MakesSound {

    private String make;
    private int volume;
    
    public Car2(String make, int volume) {
        this.make = make;
        this.volume = volume;
    }

    public String getMake() {
        return make;
    }

    // === Implementation of the MakesSound interface (two methods below)===

    public void makeSound() {
        System.out.println("Vroom, Vroom");
    }

    public int howLoud() {
        return volume;
    }
}
