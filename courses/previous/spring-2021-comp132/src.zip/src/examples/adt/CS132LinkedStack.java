package examples.adt;

/**
 * A Linked-List based implementation of the Stack ADT.
 * 
 * @author Grant Braught, revisions by Farhan Siddiqui
 * @author Dickinson College
 * @version Aug 10, 2019
 */
public class CS132LinkedStack implements CS132Stack {

	private CS132List elements;

	/**
	 * Create a new stack using a Linked-List.
	 */
	public CS132LinkedStack() {
		elements = new CS132SinglyLinkedList(); 
	}

	/**
	 * {@inheritDoc}
	 */
	public Object peek() {
		if (elements.size() > 0) {
			return elements.get(0);
		} else {
			return null;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public Object pop() {
		if (elements.size() > 0) {
			return elements.remove(0);
		} else {
			return null;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void push(Object obj) {
		elements.insert(0, obj);
	}

	/**
	 * {@inheritDoc}
	 */
	public int size() {
		return elements.size();
	}
}
