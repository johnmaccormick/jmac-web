
public class Employee {

	private String name;
	private String address;
	private double salary;

	public Employee() {
	}

	public Employee(String name, String address, double salary) {
		this.name = name;
		this.address = address;
		this.salary = salary;
	}

	public void greet() {
		System.out.println("hi");
	}

	public static void main(String[] args) {
		
	}



}
