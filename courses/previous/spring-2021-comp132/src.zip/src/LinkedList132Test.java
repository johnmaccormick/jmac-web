import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LinkedList132Test {
	LinkedList132 empty;
	LinkedList132 oneNode;
	LinkedList132 twoNodes;
	LinkedList132 fiveNodes;

	private void checkList(LinkedList132 list, String[] vals) {
		assertEquals(vals.length, list.size());
		for (int i = 0; i < vals.length; i++) {
			assertEquals(vals[i], list.get(i));
		}
	}

	@BeforeEach
	void setUp() throws Exception {
		empty = new LinkedList132();

		oneNode = new LinkedList132();
		oneNode.add("a");

		twoNodes = new LinkedList132();
		twoNodes.add("a");
		twoNodes.add("b");

		fiveNodes = new LinkedList132();
		fiveNodes.add("a");
		fiveNodes.add("b");
		fiveNodes.add("c");
		fiveNodes.add("d");
		fiveNodes.add("e");
	}

	@Test
	void testLinkedList132() {
		checkList(empty, new String[] {});
		checkList(oneNode, new String[] { "a" });
		checkList(twoNodes, new String[] { "a", "b" });
		checkList(fiveNodes, new String[] { "a", "b", "c", "d", "e" });
	}

	@Test
	void testGet() {
		assertThrows(IndexOutOfBoundsException.class, () -> {
			empty.get(-1);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			empty.get(-5);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			empty.get(0);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			oneNode.get(1);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			oneNode.get(2);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			oneNode.get(3);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.get(5);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.get(10);
		});
		assertThrows(IndexOutOfBoundsException.class, () -> {
			fiveNodes.get(-4);
		});

	}

//	@Test
//	void testSet() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testInsert() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testRemove() {
//		fail("Not yet implemented");
//	}

}
