import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * A NGramGenerator object computes all the n-grams in a given text file
 * 
 * @author jmac
 * @version September 2010
 */
public class NGramGenerator {
	// the name of the file from which n-grams will be computed
	private String filename;
	// the value of n i.e. the length of the n-grams
	private int phrase_length;
	// a list of all the n-grams computed
	private ArrayList<String> ngrams;

	/**
	 * Create a new NGramGenerator, and compute the n-grams of the given length
	 * from the given file, storing them for later use.
	 * 
	 * @param filename
	 *            the name of the file from which n-grams will be computed
	 * @param phrase_length
	 *            the value of n i.e. the length of the n-grams
	 * @throws IOException
	 */
	public NGramGenerator(String filename, int phrase_length)
			throws IOException {

		ngrams = new ArrayList<String>();
		this.filename = filename;
		this.phrase_length = phrase_length;
		buildNGrams();
	}

	/**
	 * @return the name of the file from which n-grams were computed
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @return the final component of the name of the file from which n-grams
	 *         were computed (i.e. the part of the name after the last directory
	 *         separator)
	 */
	public String getFilenameFinalComponent() {
		File file = new File(filename);
		return file.getName();
	}

	/**
	 * @return a list of the computed n-grams
	 */
	public ArrayList<String> getPhrases() {
		return ngrams;
	}

	// perform the computation of the n-grams
	private void buildNGrams() throws FileNotFoundException, IOException {
		// Step 1. read the entire file into a Java string
		BufferedReader input = new BufferedReader(new FileReader(filename));
		StringBuilder builder = new StringBuilder();
		String line = null;
		while ((line = input.readLine()) != null) {
			builder.append(line);
			builder.append(" ");
		}
		String whole_file = builder.toString();

		// Step 2. perform pre-processing to transform the data into canonical
		// form, and split it into individual words

		// 2a. multiple whitespace characters are replaced by a single space
		whole_file = whole_file.replaceAll("\\s+", " ");
		// 2b. any non-alphabetic characters are removed (except the space
		// character)
		whole_file = whole_file.replaceAll("[^ a-zA-Z]", "");
		// 2c. uppercase characters are transformed to lowercase
		whole_file = whole_file.toLowerCase();
		// 2d. split the file into separate words
		String[] words = whole_file.split(" ");

		// Step 3. step through the array of words, creating and storing the
		// n-gram that starts at each word
		for (int i = 0; i <= words.length - phrase_length; i++) {
			StringBuilder ngram_builder = new StringBuilder();
			for (int j = 0; j < phrase_length; j++) {
				ngram_builder.append(words[i + j] + " ");
			}
			ngrams.add(ngram_builder.toString());
		}
	}

	/**
	 * Print out the list of n-grams computed.
	 */
	public void print() {
		for (int i = 0; i < ngrams.size(); i++) {
			System.out.println(ngrams.get(i));
		}
	}

}
