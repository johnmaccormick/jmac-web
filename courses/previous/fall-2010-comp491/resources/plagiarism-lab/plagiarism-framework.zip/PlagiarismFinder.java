import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * A PlagiarismFinder prints out a list of suspiciously similar documents in a
 * given corpus of documents
 * 
 * @author jmac
 * @version September 2010
 */
public class PlagiarismFinder {

	// the file names of all documents to be analyzed should end with this
	// suffix
	public static final String DOCUMENT_SUFFIX = ".txt";

	// an array containing the text files to be analyzed for plagiarism
	ArrayList<File> documents;
	// the length of the n-grams to be used in detecting plagiarism
	private int phrase_length;
	// the number of n-grams in common defining the threshold for plagiarism
	private int threshold;

	/**
	 * @param directory
	 *            the directory containing text files to be analyzed for
	 *            plagiarism
	 * @param phrase_length
	 *            the length of the n-grams to be used in detecting plagiarism
	 * @param threshold
	 *            the number of n-grams in common defining the threshold for
	 *            plagiarism
	 * @throws IOException
	 */
	public PlagiarismFinder(String directory, int phrase_length, int threshold)
			throws IOException {
		// get a list of all files in the desired directory
		File dir_file = new File(directory);
		if (!dir_file.isDirectory()) {
			throw new IOException(directory + " is not a directory");
		}
		File[] all_files = dir_file.listFiles();

		// transfer only files with the correct suffix into the document list
		this.documents = new ArrayList<File>();
		for (File file : all_files) {
			if (file.getAbsolutePath().endsWith(DOCUMENT_SUFFIX)) {
				documents.add(file);
			}
		}

		this.phrase_length = phrase_length;
		this.threshold = threshold;
	}

	// the rest is up to you!
	// ADD CODE HERE

	private static void usage() {
		System.out.println("Usage: java PlagiarismFinder dirname phrase_length threshold");
		System.exit(0);
	}

	/**
	 * Print a list of pairs of suspiciously similar files in a given directory.
	 * 
	 * @param args
	 *            The three command-line arguments are: dirname, phrase_length,
	 *            threshold
	 */
	public static void main(String[] args) {
		if (args.length != 3) {
			usage();
		}

		String directory = args[0];
		int phrase_length = -1;
		int threshold = -1;

		try {
			phrase_length = Integer.parseInt(args[1]);
			threshold = Integer.parseInt(args[2]);
		} catch (NumberFormatException e) {
			usage();
		}

		PlagiarismFinder finder = null;
		try {
			finder = new PlagiarismFinder(directory, phrase_length, threshold);
		} catch (IOException e) {
			System.out.println("Exception in PlagiarismFinder constructor: "
					+ e);
			System.exit(0);
		}

		// ADD CODE HERE

	
	}

}
