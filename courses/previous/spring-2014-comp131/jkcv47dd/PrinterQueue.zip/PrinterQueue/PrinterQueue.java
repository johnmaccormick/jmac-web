/**
 * This class stores the size (i.e. number of pages) of print jobs in
 * a printer queue.  Print jobs can have any positive number of pages,
 * including 0 pages.  The number of jobs in the queue does not
 * change.
 * 
 * Each print job is represented simply by the number of pages it
 * contains.  The jobs are stored in the order in which they will be
 * printed, with the first job stored at position 0.  For instance,
 * the following queue stores a job with 11 pages, a job with 23
 * pages, and a job with 1 page, in that order:
 * 
 * position:              0    1     2
 * number of pages:       11   23    1
 * 
 * @author Nathan Vaillette (slightly edited by John MacCormick)
 * @author (put your name here)
 * @version (put the date here)
 *
 */
public class PrinterQueue
{

    // insert your fields here
    
    /**
     * Construct a PrinterQueue object to hold the given number of
     * print jobs.  If numJobs is less than 1, print an error message.
     * 
     * @param numJobs the number of print jobs to be stored
     */
    public PrinterQueue(int numJobs)
    {
        // insert your code here
    }

    /**
     * Get the number of jobs stored
     * @return the number of print jobs stored in the queue
     */
    public int getNumJobs() {
        // replace with your own code
        return 0;
    }
    
    /**
     * Return the number of pages of the job stored at the given
     * position.  This method prints an error message and returns -1
     * if the position is invalid.
     * 
     * @param position the position of the print job 
     * @return the number of pages of the job in that position
     */
    public int getJobSize(int position) {
        // replace with your own code
        return 0;
    }
    
    /**
     * Set the number of pages of the print job in the given position.
     * This method prints an error message if the position is invalid.
     * If the numPages is a negative number, it prints a different
     * error message and does not change the number of pages (note
     * however that numPages is allowed to be 0).
     * 
     * @param position the position of the print job
     * @param numPages the number of pages of the print job
     */
    public void setJobSize(int position, int numPages) {
        // insert your code here
    }
    
    /**
     * Get the total number of pages of all the print jobs on the
     * queue.
     * 
     * @return the total number of pages of all the print jobs on the
     *         queue
     */
    public int totalPages() {
        // replace with your own code
        return 0;
    }
    
    /**
     * Find the print job with the greatest number of pages and return
     * the position at which it is stored.  If multiple jobs are tied
     * for longest, this method returns the position of the first tied
     * job.
     * 
     * @return the position of the longest job in the queue (or of the
     *         first job which is tied for longest)
     */
    public int positionOfLongestJob() {
        // replace with your own code
        return 0;     
    }
      
    /**
     * Get the number of print jobs whose size does not exceed the
     * given number.
     * 
     * @param maxPages the number of pages
     * @return the number of print jobs whose size is not greater than
     *         maxPages
     */
    public int jobsUpToSize(int maxPages) {
        // replace with your own code
        return 0;       
    }
    
    /**
     * Compute the total cost (in dollars) that will be charged for
     * all the jobs on the printer queue together, based on the given
     * price per page (in dollars).
     * 
     * @param pricePerPage the price per page (in dollars)
     * @return the total cost (in dollars) of all the jobs in the
     *         printer queue together
     */
    public double totalCost(double pricePerPage) {
        // replace with your own code
        return 0.0;
    }
    
    /**
     * Change the jobs in the printer queue to represent the result of
     * printing all the jobs N-up, i.e. with N pages printed on one
     * physical sheet of paper.  For instance, if a job with 12 pages
     * is to be printed 4-up, the number of pages should be reduced to
     * 12/4 = 3.  However, if a job with 13 pages is printed 4-up, the
     * number of pages will have to be reduced to 4 (3 sheets for the
     * first 12 pages, and 1 final sheet for the single remaining
     * page).
     * 
     * If pagesPerSheet is less than 1, this method should print an
     * error message and not change any of the print jobs.
     *
     * @param pagesPerSheet the number of pages on each sheet of paper
     */
    public void nUp(int pagesPerSheet) {
        // insert your code here
    }
    
    /**
     * ***************************************************************
     *
     * ******************* BONUS METHOD ******************************
     * 
     * ***************************************************************
     *
     * This method will not be tested by webcat, and is worth only a
     * small amount of extra credit (3 points).  Do not attempt this
     * method until you have implemented, tested, and submitted to
     * webcat fully functional versions of all the previous methods.
     * For full bonus credit, uncomment the method signature below,
     * implement the method, and implement a test that produces
     * statement coverage.
     * 
     * This method can be used if it is desired to disallow jobs with
     * more than a certain number of pages.  It returns a new
     * PrinterQueue just like the current queue but with all jobs over
     * a certain size removed.
     * 
     * @param maxSize the maximum number of pages of the jobs in the new PrinterQueue
     * @return a new PrinterQueue just like this one but without the
     *         jobs of size greater than maxSize.
     */
    
//     public PrinterQueue reducedQueue(int maxSize) {
//         // replace with your own code
//         return null;
//     }    

        

}
