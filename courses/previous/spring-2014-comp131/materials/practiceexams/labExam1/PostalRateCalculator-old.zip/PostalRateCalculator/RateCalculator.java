
/**
 * This class defines an object that is useful for calculating the postal
 * rate for sending a particular package.  Each package has a weight and is to 
 * be shipped via a specified postage class.  The cost of shipping a package
 * depends on both the weight of the package and the postage class used for
 * shipping.  The constructor and methods for this class are described in detail
 * below.
 * 
 * @author Tim Wahls
 * @author (YOUR NAME HERE) 
 * @version (PUT DATE HERE)
 */
public class RateCalculator
{
	// declare your fields here
	
	/**
	 * set the postal rate class and the package weight
	 * @param initWeight the weight of the package in ounces
	 * @param initRateClass either first or second class (1 or 2)
	 */
	public RateCalculator(int initWeight, int initRateClass)
	{
		// add your code here
  	 }

	/**
	 * return the weight of the package
	 */
	public int getWeight()
	{
	    // replace this code with your own
		return 0;
	}
	
	/**
	 * return the rate class of the package
	 */
	public int getRateClass()
	{
	    // replace this code with your own
		return 0;
	}
	
	/**
	 * return whether or not the package is to be sent first class
	 */
	public boolean isFirstClass() {
	    // replace this code with your own
	    return false;
	}
	
	/**
	 * increase the weight of the package
	 * @param increaseBy the number of ounces to increase the weight by
	 */
	public void increaseWeight(int increaseBy) {
	    // add your code here
	}
	
	/**
	 * return the amount of the package's weight that will be charged at the
	 * highest rate (for postage).  For packages under 16 ounces, the full
	 * weight of the package is charged at the highest rate.  For packages
	 * 16 ounces or heavier, only 16 ounces are charged at the highest rate.
	 */
    public int getWeightChargedAtHighestRate() {
	    // replace this code with your own
        return 0;
    }
    
    /** 
     * return the total cost of sending the package (in dollars).<br>
     * For first class packages, the rate is 34 cents per ounce for the first
     * 16 ounces, plus 15 cents per ounce for each ounce over 16 ounces.<br>
     * For second class packages, the rate is 20 cents per ounce for the first
     * 16 ounces, plus 15 cents per ounce for each ounce over 16 ounces.<br>
     * The total cost is always just in dollars - any fractions of a dollar
     * resulting from the above calculation are discarded.
    */
    public int getPostageBill() {
	    // replace this code with your own
        return 0;
    }
            
}
