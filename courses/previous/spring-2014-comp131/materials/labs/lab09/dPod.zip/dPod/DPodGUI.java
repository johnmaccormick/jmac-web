import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * Constructs and controls the GUI for the DPod
 * 
 * @author Grant Braught
 * @version October 2006
 */
public class DPodGUI extends JFrame
{
    private DPod dPod;
    
    private JList masterPlayList;
    private JList playListList;
    private JList playListContents;
    
    private JButton playButton;
    private JButton pauseButton;
    private JButton stopButton;
    private JButton nextButton;
    private JButton prevButton;
    private JLabel currentlyPlaying;
    
    private JMenu dPodMenu;
    private JMenu playListMenu;
    private JMenu songMenu;
    private JMenu controlsMenu;
    
    /**
     * Constructor for objects of class DpodGUI
     */
    public DPodGUI(DPod theDPod)
    {
        dPod = theDPod;
        
        setTitle("The dPod");
        makeGUI();
        
        updateMPL(dPod.getMPL());
        updatePlayListList();
       
        pauseButton.setEnabled(false);
        stopButton.setEnabled(false);
        nextButton.setEnabled(false);
        prevButton.setEnabled(false);
        
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void showGUI() {
        setVisible(true);
    }
    
    /*
     * GUI Creation code
     */
    
    private void makeGUI() {
        Container c = getContentPane();
        Box fullWindow = Box.createVerticalBox();

        fullWindow.add(getPlayLists());
        fullWindow.add(Box.createVerticalStrut(10));
        fullWindow.add(getControls());
        fullWindow.add(Box.createVerticalStrut(10));
        fullWindow.add(getPlayingLine());
        fullWindow.add(Box.createVerticalStrut(10));
        
        setJMenuBar(getDPodMenuBar());
        
        c.add(fullWindow);
    }
    
    private JMenuBar getDPodMenuBar() {
        JMenuBar menu = new JMenuBar();
        menu.add(getDPodMenu());
        menu.add(getSongMenu());
        menu.add(getPlayListMenu());
        //menu.add(getControlsMenu());
        return menu;
    }
    
    private JMenu getDPodMenu() {
        dPodMenu = new JMenu("dPod");
        ActionListener al = new DPodMenuHandler();
         
        JMenuItem save = new JMenuItem("Save");
        save.addActionListener(al);
        dPodMenu.add(save);
        
        dPodMenu.addSeparator();
        
        JMenuItem add = new JMenuItem("Add Song to Master PlayList");
        add.addActionListener(al);
        dPodMenu.add(add);
        
        /*
        JMenuItem del = new JMenuItem("Delete Song from Master PlayList");
        del.addActionListener(al);
        dPodMenu.add(del);
       
        dPodMenu.addSeparator();
        
        JMenuItem sbn = new JMenuItem("Sort Master PlayList by Name");
        sbn.addActionListener(al);
        dPodMenu.add(sbn);

        JMenuItem sbr = new JMenuItem("Sort Master PlayList by Rating");
        sbr.addActionListener(al);
        dPodMenu.add(sbr);
       
        dPodMenu.addSeparator();
        
        JMenuItem splbn = new JMenuItem("Sort PlayLists by Name");
        splbn.addActionListener(al);
        dPodMenu.add(splbn);

        JMenuItem splbr = new JMenuItem("Sort PlayLists by Average Rating");
        splbr.addActionListener(al);
        dPodMenu.add(splbr);
        */
       
        dPodMenu.addSeparator();
        
        JMenuItem printTitles = new JMenuItem("Print All Song Names");
        printTitles.addActionListener(al);
        dPodMenu.add(printTitles);
  
        JMenuItem printAll = new JMenuItem("Print All Songs");
        printAll.addActionListener(al);
        dPodMenu.add(printAll);
        
        dPodMenu.addSeparator();     
        
        JMenuItem exit = new JMenuItem("Exit");
        exit.addActionListener(al);
        dPodMenu.add(exit);
        
        return dPodMenu;
    }
    
    private JMenu getPlayListMenu() {
        playListMenu = new JMenu("PlayList");
        ActionListener al = new PlayListMenuHandler();
        
        JMenuItem newPL = new JMenuItem("New Empty PlayList");
        newPL.addActionListener(al);
        playListMenu.add(newPL);
        
        JMenuItem newPLByArtist = new JMenuItem("New PlayList by Artist");
        newPLByArtist.addActionListener(al);
        playListMenu.add(newPLByArtist);

        JMenuItem newPLByRating = new JMenuItem("New PlayList by Rating");
        newPLByRating.addActionListener(al);
        playListMenu.add(newPLByRating);
        
        playListMenu.addSeparator();
        
        JMenuItem delPL = new JMenuItem("Delete PlayList");
        delPL.addActionListener(al);
        playListMenu.add(delPL);
        
        JMenuItem renPL = new JMenuItem("Rename PlayList");
        renPL.addActionListener(al);
        playListMenu.add(renPL); 
        
        playListMenu.addSeparator();
        
        JMenuItem addSong = new JMenuItem("Add Song to PlayList");
        addSong.addActionListener(al);
        playListMenu.add(addSong);
        
        JMenuItem remSong = new JMenuItem("Remove Song from PlayList");
        remSong.addActionListener(al);
        playListMenu.add(remSong);
        
        playListMenu.addSeparator();
       
        /*
        JMenuItem sbn = new JMenuItem("Sort Songs by Name");
        sbn.addActionListener(al);
        playListMenu.add(sbn);
        
        JMenuItem sbr = new JMenuItem("Sort Songs by Rating");
        sbr.addActionListener(al);
        playListMenu.add(sbr);
        */
       
        JMenuItem shuf = new JMenuItem("Shuffle");
        shuf.addActionListener(al);
        playListMenu.add(shuf);
        
        playListMenu.addSeparator();
       
        JMenuItem printTitles = new JMenuItem("Print Song Names");
        printTitles.addActionListener(al);
        playListMenu.add(printTitles);
  
        JMenuItem printAll = new JMenuItem("Print Songs");
        printAll.addActionListener(al);
        playListMenu.add(printAll);
        
        return playListMenu;
    }
    
    private JMenu getSongMenu() {
        songMenu = new JMenu("Song");
       
        ActionListener al = new SongMenuHandler();
        
        JMenuItem setRating = new JMenuItem("Set Song Rating");
        setRating.addActionListener(al);
        songMenu.add(setRating);
        
        JMenuItem print = new JMenuItem("Print Song Information");
        print.addActionListener(al);
        songMenu.add(print);
        
        return songMenu;
    }
    
    private JMenu getControlsMenu() {
        controlsMenu = new JMenu("Controls");
        
        ActionListener al = new ControlsMenuAndButtonsHandler();
        
        JMenuItem play = new JMenuItem("Play");
        play.addActionListener(al);
        controlsMenu.add(play);
        
        JMenuItem pause = new JMenuItem("Pause/Resume");
        pause.addActionListener(al);
        controlsMenu.add(pause);
        
        JMenuItem next = new JMenuItem("Next");
        next.addActionListener(al);
        controlsMenu.add(next);
        
        JMenuItem prev = new JMenuItem("Previous");
        prev.addActionListener(al);
        controlsMenu.add(prev);
        
        JMenuItem stop = new JMenuItem("Stop");
        stop.addActionListener(al);
        controlsMenu.add(stop);
        
        return controlsMenu;
    }
    
    private Component getPlayingLine() {
        Box playLine = Box.createHorizontalBox();
        playLine.add(Box.createGlue());
        
        playLine.add(new JLabel("Currently Playing: "));
        currentlyPlaying = new JLabel("none");
        playLine.add(currentlyPlaying);
        
        playLine.add(Box.createGlue());
        
        playLine.setMaximumSize(new Dimension(10000, (int)playLine.getMinimumSize().getHeight()));
        return playLine;
    }
        
    
    private Component getControls() {
        Box controls = Box.createHorizontalBox();
        controls.add(Box.createGlue());
        
        ActionListener al = new ControlsMenuAndButtonsHandler();
        
        // Create the button objects here.
        playButton = new JButton("Play");
        playButton.addActionListener(al);
        controls.add(playButton);
        controls.add(Box.createHorizontalStrut(10));
        
        pauseButton = new JButton("Pause/Resume");
        pauseButton.addActionListener(al);
        controls.add(pauseButton);
        controls.add(Box.createHorizontalStrut(10));
        
        stopButton = new JButton("Stop");
        stopButton.addActionListener(al);
        controls.add(stopButton);
        
        nextButton = new JButton("Next");
        nextButton.addActionListener(al);
        controls.add(nextButton);
        
        prevButton = new JButton("Prev");
        prevButton.addActionListener(al);
        controls.add(prevButton);
        
        controls.add(Box.createGlue());
        
        controls.setMaximumSize(new Dimension(10000, (int)controls.getMinimumSize().getHeight()));
        return controls;
    }
    
    private Component getPlayLists() {
        Box playLists = Box.createHorizontalBox();
          
        playLists.add(Box.createHorizontalStrut(10));
        playLists.add(getMasterPlayList());
        playLists.add(Box.createHorizontalStrut(10));
        playLists.add(getPlayListList());
        playLists.add(Box.createHorizontalStrut(10));
        playLists.add(getPlayListContents());   
        playLists.add(Box.createHorizontalStrut(10));
        
        return playLists;
    }
    
    private Component getMasterPlayList() {
        Box mpl = Box.createVerticalBox();

        Box title = Box.createHorizontalBox();
        JLabel tlabel = new JLabel("Master PlayList:");
        tlabel.setMaximumSize(tlabel.getMinimumSize());
        title.add(tlabel);
        title.add(Box.createGlue());
        title.setMaximumSize(new Dimension(10000, (int)(tlabel.getMinimumSize().getHeight())));
        mpl.add(title);
        
        // Create the masterPlayList object here.
        masterPlayList = new JList();
        masterPlayList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        masterPlayList.setLayoutOrientation(JList.VERTICAL);
        
        JScrollPane mplScroller = new JScrollPane(masterPlayList);
        mplScroller.setMinimumSize(new Dimension(200,400));
        mplScroller.setPreferredSize(new Dimension(200,400));
        mpl.add(mplScroller);
        
        return mpl;
    }
    
    private Component getPlayListList() {
        Box pll = Box.createVerticalBox();
        
        Box title = Box.createHorizontalBox();
        JLabel tlabel = new JLabel("PlayLists:");
        tlabel.setMaximumSize(tlabel.getMinimumSize());
        title.add(tlabel);
        title.add(Box.createGlue());
        title.setMaximumSize(new Dimension(10000, (int)(tlabel.getMinimumSize().getHeight())));
        pll.add(title);
        
        // Create the playListList object here.
        playListList= new JList();
        playListList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        playListList.setLayoutOrientation(JList.VERTICAL);
        playListList.addListSelectionListener(new PlayListListSelectionHandler());
        
        JScrollPane pllScroller = new JScrollPane(playListList);
        pllScroller.setMinimumSize(new Dimension(200,400));
        pllScroller.setPreferredSize(new Dimension(200,400));
        pll.add(pllScroller);
        
        return pll;
    }
    
    private Component getPlayListContents() {
        Box plc = Box.createVerticalBox();
        
        Box title = Box.createHorizontalBox();
        JLabel tlabel = new JLabel("PlayList Contents:");
        tlabel.setMaximumSize(tlabel.getMinimumSize());
        title.add(tlabel);
        title.add(Box.createGlue());
        title.setMaximumSize(new Dimension(10000, (int)(tlabel.getMinimumSize().getHeight())));
        plc.add(title);
        
        // Create the playListContents object here.
        playListContents = new JList();
        playListContents.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        playListContents.setLayoutOrientation(JList.VERTICAL);
        
        JScrollPane plcScroller = new JScrollPane(playListContents);
        plcScroller.setMinimumSize(new Dimension(200,400));
        plcScroller.setPreferredSize(new Dimension(200,400));
        plc.add(plcScroller);
        
        return plc;        
    }
    
    
    /*
     * GUI Update code here.
     */
    private void updateMPL(PlayList mpl) {
        String [] titles = new String[mpl.getNumSongs()];
        
        // put stuff from mpl into the masterPlayList JList.
        for (int i=0; i<mpl.getNumSongs(); i++) {
            titles[i] = mpl.getSongAtPosition(i).getSongName();
        }
        
        masterPlayList.setListData(titles);            
    }
    
    private void updatePlayListList() {
        ArrayList<PlayList> playLists = dPod.getPlayLists();
        String[] names = new String[playLists.size()];
        
        for (int i=0; i<playLists.size(); i++) {
            names[i] = playLists.get(i).getPlayListName();
        }
        
        playListList.setListData(names);
    }
    
    private void updatePlayListContents() {
        int index = playListList.getMaxSelectionIndex();
        if (index != -1) {
            PlayList pl = dPod.getPlayLists().get(index);
            String[] names = new String[pl.getNumSongs()];
        
            for (int i=0; i<pl.getNumSongs(); i++) {
                names[i] = pl.getSongAtPosition(i).getSongName();
            }
        
            playListContents.setListData(names);
        }
        else {
            playListContents.setListData(new String[0]);
        }
    }
    
    /**
     * Returns the index of the newly selected song or the max
     * index if we are already at the end of the list.
     */
    public int selectNextSongInMPL() {
        int size = masterPlayList.getModel().getSize();
        int curr = masterPlayList.getMaxSelectionIndex();
        if (curr < size - 1) {
            masterPlayList.setSelectedIndex(curr+1);
            return curr+1;
        }
        else {
            return curr;
        }
    }
    
    /**
     * Returns the index of the newly selected song or 0 if we are
     * already at the start of the list.
     */
    public int selectPrevSongInMPL() {
        int curr = masterPlayList.getMaxSelectionIndex();
        if (curr > 0) {
            masterPlayList.setSelectedIndex(curr-1);
            return curr-1;
        }
        else {
            return 0;
        }
    }
    
    /**
     * Returns the index of the newly selected song or the max
     * index if we are already at the end of the list.
     */
    public int selectNextSongInActivePL() {
        int size = playListContents.getModel().getSize();
        int curr = playListContents.getMaxSelectionIndex();
        if (curr < size - 1) {
            playListContents.setSelectedIndex(curr+1);
            return curr+1;
        }
        else {
            return curr;
        }
    }
    
    /**
     * Returns the index of the newly selected song or 0 if we are
     * already at the start of the list.
     */
    public int selectPrevSongInActivePL() {
        int curr = playListContents.getMaxSelectionIndex();
        if (curr > 0) {
            playListContents.setSelectedIndex(curr-1);
            return curr-1;
        }
        else {
            return 0;
        }
    }
    
    /*
     * Select the first song in the active playlist and return 
     * true, or if the active playlist is empty, return false.
     */
    public boolean selectFirstSongInActivePL() {
        int size = playListContents.getModel().getSize();
        if (size > 0) {
            playListContents.setSelectedIndex(0);
            return true;
        }
        else {
            return false;
        }
    }
    
    public int getPlayListListIndex() {
        return playListList.getMaxSelectionIndex();
    }
    
    public int getSelectedIndexInPL() {
        return playListContents.getMaxSelectionIndex();
    }
    
    public int getSelectedIndexInMPL() {
        return masterPlayList.getMaxSelectionIndex();
    }
    
    public void setPlayingLine(String newLine) {
        currentlyPlaying.setText(newLine);
    }
    
    public void setGUINotPlaying() {
        playButton.setEnabled(true);
        pauseButton.setEnabled(false);
        stopButton.setEnabled(false);
        nextButton.setEnabled(false);
        prevButton.setEnabled(false);
        masterPlayList.setEnabled(true);
        playListList.setEnabled(true);
        playListContents.setEnabled(true);  
        
        dPodMenu.setEnabled(true);
        playListMenu.setEnabled(true);
        songMenu.setEnabled(true);
    }
    
    public void setGUIPlaying() {
        playButton.setEnabled(false);
        pauseButton.setEnabled(true);
        stopButton.setEnabled(true);
        nextButton.setEnabled(true);
        prevButton.setEnabled(true);
        masterPlayList.setEnabled(false);
        playListList.setEnabled(false);
        playListContents.setEnabled(false);
        
        dPodMenu.setEnabled(false);
        playListMenu.setEnabled(false);
        songMenu.setEnabled(false);
    }
    
    /*
     * Event handlers below here.
     */
    
    private class DPodMenuHandler implements ActionListener {
        
        public void actionPerformed(ActionEvent e) {
            String cmd = e.getActionCommand();
            
            if (cmd.equals("Exit")) {
                System.exit(0);
            }
            else if (cmd.equals("Save")) {
                dPod.saveAllFiles();
            }
            else if (cmd.startsWith("Add Song")) {
                dPod.addSongToMPL();
                updateMPL(dPod.getMPL());
            }
            else if (cmd.startsWith("Delete Song")) {
                // Not yet implemented due to ripple effect thorugh all of the 
                // playlists.
                dPod.deleteSongFromMPL(0);
            }
            /*
            else if (cmd.startsWith("Sort Master PlayList by Name")) {
                // Not implemented... This is currently the default and only
                // way that the master playlist is sorted.
                dPod.sortMPLByName();
                updateMPL(dPod.getMPL());
            }
            else if (cmd.startsWith("Sort Master PlayList by Rating")) {
                // Not implemented... see previous option.
                dPod.sortMPLByRating();
                updateMPL(dPod.getMPL());
            }
            else if (cmd.equals("Sort PlayLists by Name")) {
                dPod.sortPlayListsByName();
            }
            else if (cmd.equals("Sort PlayLists by Average Rating")) {
                dPod.sortPlayListsByRating();   
            }
            */
            else if (cmd.equals("Print All Song Names")) {
                dPod.printMPLNames();   
            }
            else if (cmd.equals("Print All Songs")) {
                dPod.printMPL();   
            }
        }
    }
    
    private class PlayListMenuHandler implements ActionListener {
        
        public void actionPerformed(ActionEvent e) {
            String cmd = e.getActionCommand();
            
            if (cmd.equals("New Empty PlayList")) {
                String name = JOptionPane.showInputDialog(playListMenu, "Enter the name of your new PlayList");
                if (name != null) {
                    if (dPod.newEmptyPlayList(name)) {
                        updatePlayListList();
                    }
                    else {
                        JOptionPane.showMessageDialog(playListMenu, "A PlayList with the name " +
                            name + " already exists.");
                    }
                }
            }
            else if (cmd.equals("New PlayList by Artist")) {
                String artistName = JOptionPane.showInputDialog(playListMenu, "Enter the name of the artist " +
                    "for the new playlist.");
                if (artistName != null) {
                    if (dPod.newPlayListByArtist(artistName)) {
                        updatePlayListList();
                    }
                    else {
                        JOptionPane.showMessageDialog(playListMenu, "A PlayList for " + artistName +
                            " already exists.");
                    }
                }
            }
            else if (cmd.equals("New PlayList by Rating")) {
                String ratingStr = JOptionPane.showInputDialog(playListMenu, "Enter the rating for " +
                    "the new playlist.");
                if (ratingStr != null) {
                    try {
                        int rating = Integer.parseInt(ratingStr);
                    
                        if (rating >= 0 && rating <= 5) {
                            if (dPod.newPlayListByRating(rating)) {
                                updatePlayListList();
                            }
                            else {
                                JOptionPane.showMessageDialog(playListMenu, "A PlayList for rating " +
                                    rating + " already exists.");
                            }
                        }
                        else {
                            JOptionPane.showMessageDialog(playListMenu, rating + " is not a valid rating.");
                        }
                    }
                    catch (NumberFormatException e2) {
                        JOptionPane.showMessageDialog(playListMenu, ratingStr + " is not a valid rating.");
                    }
                }
            }
            else if (cmd.equals("Delete PlayList")) {
                int index = playListList.getMaxSelectionIndex();
                if (index != -1) {
                    dPod.deletePlayList(index);
                    updatePlayListList();
                }
                else {
                    JOptionPane.showMessageDialog(playListMenu, "No PlayList selected.\nA PlayList must " +
                        "be selected in order to be deleted.");
                }
            }
            else if (cmd.equals("Rename PlayList")) {
                int index = playListList.getMaxSelectionIndex();
                if (index != -1) {
                    String name = JOptionPane.showInputDialog(playListMenu, "Enter the new name for the PlayList");
                    if (name != null) {
                        if (dPod.renamePlayList(index, name)) {
                            updatePlayListList();
                        }
                        else {
                            JOptionPane.showMessageDialog(playListMenu, "A PlayList with the name " +
                                name + " already exists.");
                        }
                    }
                }
                else {
                    JOptionPane.showMessageDialog(playListMenu, "No PlayList selected.\nA PlayList must " +
                        "be selected in order to be renamed.");
                }
            }
            else if (cmd.equals("Add Song to PlayList")) {
                int playListIndex = playListList.getMaxSelectionIndex();
                int songIndex = masterPlayList.getMaxSelectionIndex();
                
                if (playListIndex == -1 || songIndex == -1) {
                    JOptionPane.showMessageDialog(playListMenu, "You must select the PlayList to add to " + 
                        " and the song to be added.");
                }
                else {
                    if (dPod.addSongToPlayList(songIndex, playListIndex)) {
                        updatePlayListContents();
                    }
                    else {
                        JOptionPane.showMessageDialog(playListMenu, "The selected song is already " +
                            "contained in the selected PlayList.");
                    }
                }
            }
            else if (cmd.equals("Remove Song from PlayList")) {
                int playListIndex = playListList.getMaxSelectionIndex();
                int songIndex = playListContents.getMaxSelectionIndex();
                
                if (playListIndex == -1 || songIndex == -1) {
                    JOptionPane.showMessageDialog(playListMenu, "You must select the PlayList to remove from " + 
                        " and the song to be removed.");
                }
                else {
                    dPod.removeSongFromPlayList(songIndex, playListIndex);
                    updatePlayListContents();
                }
            }
            else if (cmd.equals("Sort Songs by Name")) {
                // Need to change check next to menu items...
                // Need to get the index of the selected playlist.
                dPod.sortSongsInPlayListByName(0);
            }
            else if (cmd.equals("Sort Songs by Rating")) {
                // Need to change the check next to menu items...
                // need to get the index of the selected playlist.
                dPod.sortSongsInPlayListByRating(0);
            }
            else if (cmd.equals("Shuffle")) {
                int index = playListList.getMaxSelectionIndex();
                if (index != -1) {
                    dPod.shufflePlayList(index);
                    updatePlayListContents();
                }
                else {
                    JOptionPane.showMessageDialog(playListMenu, "No PlayList selected.\nA PlayList must " +
                        "be selected in order to shuffle it.");
                }
            }
            else if (cmd.equals("Print Song Names")) {
                int index = playListList.getMaxSelectionIndex();
                if (index != -1) {
                    dPod.printSongNames(index);
                }
                else {
                    JOptionPane.showMessageDialog(playListMenu, "No PlayList selected.\nA PlayList must " +
                        "be selected in order to print the song names.");
                }
            }
            else if (cmd.equals("Print Songs")) {
                int index = playListList.getMaxSelectionIndex();
                if (index != -1) {
                    dPod.printSongs(index);
                }
                else {
                    JOptionPane.showMessageDialog(playListMenu, "No PlayList selected.\nA PlayList must " +
                        "be selected in order to print the songs.");
                }
            }
        }
    }
    
    private class SongMenuHandler implements ActionListener {
        
        public void actionPerformed(ActionEvent e) {
            String cmd = e.getActionCommand();
            
            if (cmd.equals("Set Song Rating")) {
                int songIndex = masterPlayList.getMaxSelectionIndex();
                if (songIndex != -1) {
                    PlayList mpl = dPod.getMPL();
                    String songName = mpl.getSongAtPosition(songIndex).getSongName();
                    
                    String ratingStr = JOptionPane.showInputDialog(playListMenu, "Enter the new rating for " +
                        songName + ".");
                        
                    if (ratingStr != null) {
                        try {
                            int rating = Integer.parseInt(ratingStr);
                    
                            if (rating >= 0 && rating <= 5) {
                                dPod.setSongRating(songIndex, rating);
                            }
                            else {
                                JOptionPane.showMessageDialog(playListMenu, rating + " is not a valid rating.");
                            }
                        }
                        catch (NumberFormatException e2) {
                            JOptionPane.showMessageDialog(playListMenu, ratingStr + " is not a valid rating.");
                        }
                    }
                }
                else {
                    JOptionPane.showMessageDialog(playListMenu, "You must select a song in " +
                        "the Master PlayList in order to set its rating.");
                }
            }
            else if (cmd.equals("Print Song Information")) {
                int index = masterPlayList.getMaxSelectionIndex();
                if (index != -1) {
                    dPod.printSongInformation(index);
                }
                else {
                    JOptionPane.showMessageDialog(playListMenu, "You must select a song in " +
                        "the Master PlayList in order to print its information.");
                }
            }
        }
    }
    
    private class ControlsMenuAndButtonsHandler implements ActionListener {
        
        public void actionPerformed(ActionEvent e) {
            String cmd = e.getActionCommand();
            
            if (cmd.equals("Play")) {
                setGUIPlaying();
                
                int plcIndex = playListContents.getMaxSelectionIndex();
                int plIndex = playListList.getMaxSelectionIndex();
                int mplIndex = masterPlayList.getMaxSelectionIndex();
                
                if (plcIndex != -1) {
                    dPod.playSongInPL(plcIndex, plIndex);
                }
                else if (plIndex != -1) {
                    dPod.playPlayList(plIndex);
                }
                else if (mplIndex != -1) {
                    dPod.playSongInMPL(mplIndex);
                }
                else {
                    JOptionPane.showMessageDialog(playListMenu, "You must select a song in the " +
                        "PlayList Contents,\nor a PlayList or a song in the Master PlayList.");
                    setGUINotPlaying();                  
                }
                    
            }
            else if (cmd.equals("Pause/Resume")) {
                dPod.pauseResumePlayback();
            }
            else if (cmd.equals("Next")) {
                dPod.skipToNext();
            }
            else if (cmd.equals("Prev")) {
                dPod.skipToPrev();
            }
            else if (cmd.equals("Stop")) {
                dPod.stopPlayback();
                setGUINotPlaying();
                currentlyPlaying.setText("none");
            }
        }
    }
    
    private class PlayListListSelectionHandler implements ListSelectionListener {
        public void valueChanged(ListSelectionEvent e) {
            if (! e.getValueIsAdjusting()) {
                updatePlayListContents();
            }
        }
    }
    
}
