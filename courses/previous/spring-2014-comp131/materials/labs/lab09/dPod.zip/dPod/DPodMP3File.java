import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;

import javax.sound.sampled.*;

/**
 * The DPodMP3File class provides a play/pause/stop interface
 * to an MP3 file.
 * 
 * @author Grant Braught
 * @version October 2006
 */
public class DPodMP3File extends Thread
{
    private String filename;
    private boolean paused;
    private boolean stopped;
    private boolean playing;
    private boolean playedToEnd;
    
    private DPod dPod;
    
    /**
     * Create a new DPodMP3File using the specified file.
     * @param filename the filename of a MP3 file.
     */
    public DPodMP3File(String filename, DPod callback) {
        this.filename = filename;
        paused = false;
        stopped = false;
        playing = false;
        playedToEnd = false;
        dPod = callback;
    }
    
    /**
     * Determine if this song played all the way through.
     * 
     * @return true if this song played all the way through and
     * false otherwise.
     */
    public boolean playedToEnd() {
        return playedToEnd;
    }
    
    /**
     * Start the playback of the song.
     */
    public void playSong() {
        if (stopped) {
            System.out.println("Error: A new DPodMP3 File must be created in " +
                "order to play the song again.");
            System.exit(-1);
        }
        
        if (!playing) {
            playing = true;
            paused = false;
            stopped = false;
            this.start();
        }
    }
    
    /**
     * Cause the playback to pause if it is currently playing
     * or restart the playback if it is currently paused.
     */
    public void pauseSong() {
        paused = !paused;
    }
    
    /**
     * Stop the playback of the song. If the song is to be played
     * again a new DPodMP3File needs to be created.
     */
    public void stopSong() {
        stopped = true;
        playing = false;
        paused = false;
    }
    
    /*
     * This method was adapted from:
     * http://www.javalobby.org/java/forums/t18465.html
     */
    public void run() {   
        
        AudioInputStream din = null;
        try {
            File file = new File(filename);
            AudioInputStream in = AudioSystem.getAudioInputStream(file);
            AudioFormat baseFormat = in.getFormat();
            AudioFormat decodedFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    baseFormat.getSampleRate(), 16, baseFormat.getChannels(),
                    baseFormat.getChannels() * 2, baseFormat.getSampleRate(),
                    false);
            din = AudioSystem.getAudioInputStream(decodedFormat, in);
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, decodedFormat);
            SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
            
            if(line != null) {
                line.open(decodedFormat);
                byte[] data = new byte[512];
                // Start
                //line.start();
                
                int nBytesRead;
                while (!stopped && (nBytesRead = din.read(data, 0, data.length)) != -1) { 
                    line.start();
                    line.write(data, 0, nBytesRead);
                    
                    // Busy waiting... could be fixed w/ wait/notify.
                    while (!stopped && paused) {
                        line.stop();
                    }
                }
                
                // Stop
                if (!stopped) {
                    line.drain();
                }
                
                line.stop();
                line.close();
                din.close();
                
                if (!stopped) {
                    playedToEnd = true;
                    dPod.playFinished();
                }
            }
            
        }
        catch(Exception e) {
            System.out.println(e);
        }
        finally {
            playing = false;
            stopped = true;
            paused = false;
        
            if(din != null) {
                try { 
                    din.close(); 
                } catch(IOException e) { 
                    System.out.println(e);
                }
            }
        }
        

    }
}
