/**
 * A simple model of a bank account to demonstrate the
 * concept of factoring out repeated code. This class
 * contains some repeated code, and is therefore difficult
 * to maintain.
 * 
 * @author jmac
 */
public class Account {
	// The annual interest rate in percentage points.
	// There are actually two interest rates:
	// a "low" rate for when the balance is below a given
	// threshold, and a "high" rate for when the balance is
	// at or above the threshold.
	private double lowInterestRate;
	private double highInterestRate;

	// the value at which the account transitions from the
	// low interest rate to the high interest rate
	private double threshold;

	// account balance in dollars
	private double balance;

	/**
	 * Create a new Account with the given interest rates
	 * and balance.
	 */
	public Account(double lowInterestRate,
			double highInterestRate, double balance) {
		this.lowInterestRate = lowInterestRate;
		this.highInterestRate = highInterestRate;
		this.balance = balance;
		this.threshold = 1000.00;
	}

	/**
	 * @return the lowInterestRate
	 */
	public double getLowInterestRate() {
		return lowInterestRate;
	}

	/**
	 * @return the highInterestRate
	 */
	public double getHighInterestRate() {
		return highInterestRate;
	}

	/**
	 * @return the threshold
	 */
	public double getThreshold() {
		return threshold;
	}

	/**
	 * @return the balance
	 */
	public double getBalance() {
		return balance;
	}

	/**
	 * Print the balance this account would have after the
	 * given number of years
	 */
	public void printFutureBalance(int years) {
		double newBalance = balance;
		for (int i = 0; i < years; i++) {
			double interestRate = 0;
			if (newBalance < threshold) {
				interestRate = lowInterestRate;
			} else {
				interestRate = highInterestRate;
			}
			newBalance = newBalance
					* (1 + interestRate / 100);
		}

		System.out.println("balance after " + years
				+ " year(s) would be " + newBalance);
	}

	/**
	 * Add the amount of interest for the given number of
	 * years to the current balance.
	 */
	public void addAnnualInterest(int years) {
		double newBalance = balance;
		for (int i = 0; i < years; i++) {
			double interestRate = 0;
			if (newBalance < threshold) {
				interestRate = lowInterestRate;
			} else {
				interestRate = highInterestRate;
			}
			newBalance = newBalance
					* (1 + interestRate / 100);
		}

		balance = newBalance;
	}

}
