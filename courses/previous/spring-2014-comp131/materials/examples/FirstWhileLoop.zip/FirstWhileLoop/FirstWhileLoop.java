
/**
 * This class is used to demonstrate the execution
 * of our first while loop example.
 * 
 * @author Grant Braught
 * @version October 2005
 */
public class FirstWhileLoop
{
    public void whileLoopDemo() {
        int x=0;
        while (x < 5) {
            System.out.println(x);
            x = x + 1;
        }
    }
}
