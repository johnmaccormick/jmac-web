
/**
 * The GradeBook class models the way an instructor might keep
 * grades for a student. A GradeBook will contain 2 arrays, one to 
 * hold the student's homework scores and one to hold the student's
 * quiz scores. Homework scores and quiz scores are represented 
 * using integer values.
 * 
 * @author (YOUR NAME HERE)
 * @version (PUT DATE HERE)
 */
public class GradeBook
{
    /**
     * Construct a new GradeBook for the specified student. You may assume
     * that the values provided for numHomeworks and numQuizzes are positive.
     * @param studentName the name of the student.
     * @param numHomeworks the number of homeworks.
     * @param numQuizzes the number of quizzes.
     */
    public GradeBook(String studentName, int numHomeworks, int numQuizzes) {
    }
}
