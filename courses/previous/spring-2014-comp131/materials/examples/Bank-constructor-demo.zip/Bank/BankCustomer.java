
/**
 * Representation of a BankCustomer that has a name,
 * address, phone number and two accounts (checking 
 * and savings).
 * 
 * @author Tim Wahls
 * @version 2/21/2006
 */
public class BankCustomer
{
    private String name; // customer name
    private String address; // customer address
    private String phoneNum;
    private Account checking;  // checking account
    private Account savings;   // savings account
    
    /**
     * Constructor for objects of class BankCustomer
     * @param initName the name of the customer
     * @param initAddress the address of the customer
     * @param initPhoneNum the telephone number of the customer
     * @param initChecking the customer's checking account
     * @param initSavings the customer's savings account
     */
    public BankCustomer(String initName, String initAddress, String initPhoneNum,
                        Account initChecking, Account initSavings)
    {
        name = initName;
        address = initAddress;
        phoneNum = initPhoneNum;
        checking = initChecking;
        savings = initSavings;
    }

    /**
     * Constructor for objects of class BankCustomer;  
     * creates a customer with a checking account but no savings account.
     * @param initName the name of the customer
     * @param initAddress the address of the customer
     * @param initPhoneNum the telephone number of the customer
     * @param initChecking the customer's checking account
     */
    public BankCustomer(String initName, String initAddress, String initPhoneNum,
                        Account initChecking)
    {
        name = initName;
        address = initAddress;
        phoneNum = initPhoneNum;
        checking = initChecking;
        savings = null;
    }  
    
    /**
     * Create a new savings account for this customer.
     */
    public void createSavingsAccount()
    {
        // add code here   
    }
    
    /**
     * return the customer's name
     * @return the customer's name
     */
    public String getName() {
        return name;
    }
    
    /**
     * return the customer's address
     * @return the customer's address
     */
    public String getAddress() {
        return address;
    }
     
    /** 
     * return the customer's telephone number
     * @return the customer's telephone number
     */
    public String getPhoneNumber() {
        return phoneNum;
    }
   
    /**
     * print all customer info
     */
    public void print()
    {
        System.out.println("Account information for customer: " + name);
        System.out.println("Address: " + address);
        System.out.println("Telephone number: " + phoneNum);
        System.out.println("Checking account:");
        checking.print();
        System.out.println("Savings account:");
        savings.print();
    }
    
    /**
     * deposit into checking account 
     * @param depCheckAmount the amount to deposit
     */
    public void depositChecking(int depCheckAmount) {
        checking.deposit(depCheckAmount);
    }
    
    /**
     * deposit into savings account 
     * @param depSaveAmount the amount to deposit
     */
    public void depositSavings(int depSaveAmount) {
        savings.deposit(depSaveAmount);
    }
     
    /** 
     * withdraw from checking account 
     * @param withCheckAmount the amount to withdraw
     */
    public void withdrawChecking(int withCheckAmount) {
        checking.withdraw(withCheckAmount);
    }
    
    /**
     * withdraw from savings account 
     * @param withSaveAmount the amount to withdraw
     */
    public void withdrawSavings(int withSaveAmount) {
        savings.withdraw(withSaveAmount);
    }
    
    /**
     * get the total balance (both checking and savings accounts)
     * @return the total balance of the customer's checking and savings accounts
     */
    public int getTotalBalance() {
        int saveBal = savings.getBalance();
        int checkBal = checking.getBalance();
        return saveBal + checkBal;
    }
    
    /** 
     * transfer from savings to checking (for this customer)
     * @param transSCAmount the amount to transfer
     */
    public void savingsToChecking(int transSCAmount) {
        if (savings.getBalance() >= transSCAmount) {
            this.withdrawSavings(transSCAmount);
            this.depositChecking(transSCAmount);
         } else {
            System.out.println("Error: insufficient funds for transfer!");
        }
    }

}
