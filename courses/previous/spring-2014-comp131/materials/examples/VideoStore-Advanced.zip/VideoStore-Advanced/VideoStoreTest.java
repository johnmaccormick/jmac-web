

/**
 * The test class VideoStoreTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class VideoStoreTest extends junit.framework.TestCase
{
	private DVD dVD1;
	private DVD dVD2;
	private DVD dVD3;
	private VideoStore videoSto1;
	private VideoStore videoSto2;

    
    
    
    

    /**
     * Default constructor for test class VideoStoreTest
     */
    public VideoStoreTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
		dVD1 = new DVD("Holy Grail", "R", 3);
        dVD2 = new DVD("Weird Science", "PG", 5);
        dVD3 = new DVD("Blues Brothers", "R", 3);
        videoSto1 = new VideoStore("My Store");
		videoSto1.getNumDVDs();
		videoSto1.addDVD(dVD1);
		videoSto1.addDVD(dVD2);
		videoSto2 = new VideoStore("vid store for testing");
		videoSto2.addDVD(dVD1);
		videoSto2.addDVD(dVD2);
		videoSto2.addDVD(dVD3);
	}

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }
    
   public void testCountOverdueDVDs() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        
        dVD3.addRentalNight();
        dVD3.addRentalNight();  
        dVD3.addRentalNight();
        dVD3.addRentalNight();
        
        assertEquals(2, videoSto1.countOverdueDVDs());    
    }
    
    public void testCountLostDVDs() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        
        dVD3.addRentalNight();
        dVD3.addRentalNight();  
        dVD3.addRentalNight();
        dVD3.addRentalNight();
        dVD3.addRentalNight();
        dVD3.addRentalNight();  
        dVD3.addRentalNight();
        dVD3.addRentalNight();

        assertEquals(2, videoSto1.countLostDVDs(2));
    }
    
    public void testGetMostOverdueDVD() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        
        dVD3.addRentalNight();
        dVD3.addRentalNight();  
        dVD3.addRentalNight();
        dVD3.addRentalNight();
        
        DVD dVD4 = videoSto1.getMostOverdueDVD();
        assertEquals("Weird Science", dVD4.getTitle());
    }
    
    public void testGetMostOverdueDVDNone() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        dVD1.addRentalNight();
        dVD1.addRentalNight();     
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD3.addRentalNight();
        dVD3.addRentalNight();  

        DVD dVD4 = videoSto1.getMostOverdueDVD();
        assertNull(dVD4);
    }
 
    public void testGetMostOverdueDVDEmptyStore() {
        DVD dVD4 = videoSto1.getMostOverdueDVD();
        assertNull(dVD4);
    }
    
    public void testGetFirstDVDWithRating() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        
        DVD dVD4 = videoSto1.getFirstDVDWithRating("R");
        assertEquals("Holy Grail", dVD4.getTitle());
        
        dVD4 = videoSto1.getFirstDVDWithRating("PG");
        assertEquals("Weird Science", dVD4.getTitle());
    }
    
    public void testGetFirstDVDWithRatingNone() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        
        DVD dVD4 = videoSto1.getFirstDVDWithRating("Z");
        assertNull(dVD4);
    }
    
    public void testGetFirstDVDWithRatingEmpty() {
        DVD dVD4 = videoSto1.getFirstDVDWithRating("R");
        assertNull(dVD4);
    }
    
    public void testGetLastDVDInStock() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        dVD3.addRentalNight();
        
        DVD dVD4 = videoSto1.getLastDVDInStock();
        assertEquals("Weird Science", dVD4.getTitle());
        
        dVD2.addRentalNight();     
        dVD4 = videoSto1.getLastDVDInStock();
        assertEquals("Holy Grail", dVD4.getTitle());
    }
    
    public void testGetLastDVDInStockNone() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        dVD1.addRentalNight();
        dVD2.addRentalNight();
        dVD3.addRentalNight();
        
        DVD dVD4 = videoSto1.getLastDVDInStock();
        assertNull(dVD4);
    }
    
    public void testGetLastDVDInStockEmpty() {
        DVD dVD4 = videoSto1.getLastDVDInStock();
        assertNull(dVD4);
    }
    
    public void testGetOverdueDVDs() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        
        dVD3.addRentalNight();
        dVD3.addRentalNight();  
        dVD3.addRentalNight();
        dVD3.addRentalNight();
    
        VideoStore videoSto2 = videoSto1.getAllOverdueDVDs();
        assertEquals("Overdue DVDs", videoSto2.getStoreName());

        assertEquals(2, videoSto2.getNumDVDs());
        
        DVD dVD4 = videoSto2.getDVD(0);
        assertEquals("Holy Grail", dVD4.getTitle());
        
        DVD dVD5 = videoSto2.getDVD(1);
        assertEquals("Blues Brothers", dVD5.getTitle());
    }
    
    public void testGetOverdueDVDsNone() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        VideoStore videoSto2 = videoSto1.getAllOverdueDVDs();
        assertEquals("Overdue DVDs", videoSto2.getStoreName());
        assertEquals(0, videoSto2.getNumDVDs());
    }

    public void testGetOverdueDVDsEmptyStore() {
        VideoStore videoSto2 = videoSto1.getAllOverdueDVDs();
        assertEquals("Overdue DVDs", videoSto2.getStoreName());
        assertEquals(0, videoSto2.getNumDVDs());
    }
    
    public void testGetMoreOverdueThan() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        dVD1.addRentalNight();
        
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        dVD2.addRentalNight();
        
        dVD3.addRentalNight();
        dVD3.addRentalNight();  
        dVD3.addRentalNight();
        dVD3.addRentalNight();
        dVD3.addRentalNight();
        dVD3.addRentalNight(); 
        
        VideoStore videoSto2 = videoSto1.getMoreOverdueThan(2);
        assertEquals("Overdue DVDs", videoSto2.getStoreName());

        assertEquals(2, videoSto2.getNumDVDs());
        
        DVD dVD4 = videoSto2.getDVD(0);
        assertEquals("Holy Grail", dVD4.getTitle());
        
        DVD dVD5 = videoSto2.getDVD(1);
        assertEquals("Blues Brothers", dVD5.getTitle());
    }

    public void testGetMoreOverdueThanNone() {
        videoSto1.addDVD(dVD1);
        videoSto1.addDVD(dVD2);
        videoSto1.addDVD(dVD3);
        VideoStore videoSto2 = videoSto1.getMoreOverdueThan(2);
        assertEquals("Overdue DVDs", videoSto2.getStoreName());
        assertEquals(0, videoSto2.getNumDVDs());
    }

    public void testGetMoreOverdueThanEmptyStore() {
        VideoStore videoSto2 = videoSto1.getMoreOverdueThan(2);
        assertEquals("Overdue DVDs", videoSto2.getStoreName());
        assertEquals(0, videoSto2.getNumDVDs());
    }
}
