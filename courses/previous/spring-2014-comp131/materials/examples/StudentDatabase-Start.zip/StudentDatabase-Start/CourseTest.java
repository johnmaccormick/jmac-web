

/**
 * The test class CourseTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class CourseTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class CourseTest
     */
    public CourseTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	public void testConstructor()
	{
		Course cs131 = new Course("COSCI", 131, "Spring", 2006, "MWF 10:30 a.m", "Tome 118", "Tim Wahls");
		assertEquals("COSCI", cs131.getDepartment());
		assertEquals(131, cs131.getNumber());
		assertEquals("Spring", cs131.getSemester());
		assertEquals(2006, cs131.getYear());
		assertEquals("MWF 10:30 a.m", cs131.getMeetingTime());
		assertEquals("Tome 118", cs131.getMeetingPlace());
		assertEquals("Tim Wahls", cs131.getInstructor());
	}

	public void testToString()
	{
		Course course1 = new Course("COSCI", 1312, "Spring", 2006, "MWF 11:30 a.m.", "Tome 120", "Grant Braught");
		assertEquals("COSCI 1312, Spring 2006, MWF 11:30 a.m. Tome 120, Grant Braught", course1.toString());
	}

	public void testSetInstructor()
	{
		Course course1 = new Course("COSCI", 1311, "Spring", 2006, "MWF 10:30 a.m.", "Tome 118", "Tim Wahls");
		course1.setInstructor("Grant Braught");
		assertEquals("Grant Braught", course1.getInstructor());
	}
}



