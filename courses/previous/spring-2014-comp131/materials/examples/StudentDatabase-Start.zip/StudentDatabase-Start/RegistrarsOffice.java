import java.util.ArrayList;

/**
 * A class to keep track of a database of student information.
 * 
 * @author Tim Wahls 
 * @version 4/8/2006
 */
public class RegistrarsOffice
{
    private String collegeName;
    private String collegeAddr;
    private ArrayList<Student> students;

    /**
     * Create a new RegistrarsOffice with the specified name and address, and
     * no students
     * 
     * @param initName name of the college
     * @param initAddr address of the college
     */
    public RegistrarsOffice(String initName, String initAddr)
    {
        collegeName = initName;
        collegeAddr = initAddr;
        students = new ArrayList<Student>();
    }

    /**
     * get the name of the college
     * 
     * @return the name of the college
     */
    public String getCollegeName()
    {
        return collegeName;
    }

    /**
     * get the address of the college
     * 
     * @return the address of the college
     */
    public String getCollegeAddress()
    {
        return collegeAddr;
    }
    
    /**
     * get the number of students enrolled at the college
     * 
     * @return the number of students enrolled at the college
     */
    public int getEnrollment() {
        return students.size();
    }
    
    /**
     * enroll a new student at the college
     * 
     * @param newStudent the new student
     */
    public void addStudent(Student newStudent) {
        students.add(newStudent);
    }
    /**
     * display information about all enrolled students
     */
    public void print() {
        System.out.println(collegeName);
        System.out.println(collegeAddr);
        for (int s=0; s<students.size(); s++) {
            Student nextStudent = students.get(s);
            System.out.println(nextStudent);
        }
    }
    
    /**
     * get a student by student ID
     * 
     * @param stuID the student ID
     * @return the student with the specified student ID, or null if no student
     * has that student ID
     */
    public Student getStudent(String stuID) {
        return null;
    }
    
    /**
     * enroll the student in the specified course, and display an error message
     * if the student ID is invalid
     * 
     * @param stuID the student ID
     * @param newCourse the course to add
     */
    public void enrollCourse(String stuID, Course newCourse) {
        Student current = getStudent(stuID);
        if (current == null) {
            System.out.println("Error: no student with ID " + stuID);
        } else {
            current.addCourse(newCourse);
        }
    }
    
    /**
     * drop the student from the specified course, and display an error message
     * if the student ID or course information is invalid
     * 
     * @param stuID the student ID
     * @param department the department of the course to drop
     * @param number the number of the course to drop
     */
    public void dropCourse(String stuID, String department, int number) {

    }
    
    /**
     * print the number of students of each standing
     * @param year the current year
     */
    public void printStandingStats(int year) {
        int seniors = 0;
        int juniors = 0;
        int sophs = 0;
        int fstyrs = 0;
        int alums = 0;
        for (int s=0; s < students.size(); s++) {
            Student current = students.get(s);
            String standing = current.getStanding(year);
            
            if (standing.equals("senior")) {
                seniors++;
            } else if (standing.equals("junior")) {
                juniors++;
            } else if (standing.equals("sophomore")) {
                sophs++;
            } else if (standing.equals("first year")) {
                fstyrs++;            
            } else {
                alums++;            
            }
        }
        
        System.out.println("Number of students by standing: ");
        System.out.println("Seniors: " + seniors);
        System.out.println("Juniors: " + juniors);
        System.out.println("Sophomores: " + sophs);
        System.out.println("First Years: " + fstyrs);
        System.out.println("Alumni: " + alums);
    }
}
