
/**
 * This class contains a field and a constructor
 * that give a small demonstration of the use of
 * arrays. This code is not intended to acomplish
 * any useful computation, it is simply a demonstration.
 * 
 * @author Grant Braught
 * @version October 2005
 */
public class FirstArrayExample
{
    private double[] prices;
    
    public FirstArrayExample() {
                      
        prices = new double[5];   
        
        prices[3] = 23.50;
        prices[1] = 99.39;
        
        double pr3 = prices[3];
        double pr2 = prices[2];
        
        prices[0] = 2*prices[1] + prices[3];
        
        int len = prices.length;
    }
}
