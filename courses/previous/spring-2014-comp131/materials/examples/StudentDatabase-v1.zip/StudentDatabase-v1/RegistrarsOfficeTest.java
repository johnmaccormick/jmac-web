

/**
 * The test class RegistrarsOfficeTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class RegistrarsOfficeTest extends junit.framework.TestCase
{
	private Student michael;
	private Course cs1311;
	private Course cs1312;
	private Course cs132;
	private Course math161;
	private Course math162;
	private RegistrarsOffice dickinson;
	private Student elvis;
	private Student patsy;
	private Student jlo;

	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	

    /**
     * Default constructor for test class RegistrarsOfficeTest
     */
    public RegistrarsOfficeTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
		michael = new Student("Michael Jackson", "123", 2008, 3.68);
		cs1311 = new Course("COSCI", 1311, "Spring", 2006, "MWF 10:30 a.m.", "Tome 118", "Tim Wahls");
		cs1312 = new Course("COSCI", 1312, "Spring", 2006, "MWF 11:30 a.m.", "Tome 120", "Grant Braught");
		cs132 = new Course("COSCI", 132, "Spring", 2006, "MWF 11:30 a.m.", "Tome 118", "A.C. Chapin");
		math161 = new Course("MATH", 161, "Spring", 2006, "MWF 12:30 a.m.", "Tome 117", "Barry Tesman");
		math162 = new Course("MATH", 162, "Spring", 2006, "MWF 9:30 a.m.", "Tome 117", "Dave Richeson");
		dickinson = new RegistrarsOffice("Dickinson College", "Carlisle, PA 17013");
		elvis = new Student("Elvis Presley", "134", 2006, 2.35);
		patsy = new Student("Patsy Kline", "245", 2009, 3.78);
		jlo = new Student("Jennifer Lopez", "567", 2010, 3.65);
		michael.addCourse(math161);
		michael.addCourse(cs1311);
		elvis.addCourse(cs132);
		elvis.addCourse(math162);
		patsy.addCourse(cs1312);
		patsy.addCourse(cs132);
		patsy.addCourse(math162);
		jlo.addCourse(math161);
		jlo.addCourse(cs1311);
		dickinson.addStudent(elvis);
		dickinson.addStudent(patsy);
		dickinson.addStudent(jlo);
		dickinson.addStudent(michael);
	}

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	public void testConstructor()
	{
		RegistrarsOffice isu = new RegistrarsOffice("Iowa State University", "Ames, IA");
		assertEquals("Iowa State University", isu.getCollegeName());
		assertEquals("Ames, IA", isu.getCollegeAddress());
		assertEquals(0, isu.getEnrollment());
	}

	public void testPrint()
	{
		dickinson.print();
	}

	public void testGetStudentEmpty()
	{
		RegistrarsOffice registra1 = new RegistrarsOffice("Iowa State University", "Ames, IA");
		assertEquals(null, registra1.getStudent("123"));
	}

	public void testAddAndGetStudent()
	{
		assertEquals(4, dickinson.getEnrollment());
		Student student1 = dickinson.getStudent("134");
		assertEquals("Elvis Presley", student1.getName());
		Student student2 = dickinson.getStudent("123");
		assertEquals("Michael Jackson", student2.getName());
	}

	public void testGetStudentBadID()
	{
		assertEquals(null, dickinson.getStudent("876"));
	}

	public void testEnrollCourseInvalid()
	{
		dickinson.enrollCourse("876", math162);
	}

	public void testEnrollCourseValid()
	{
		dickinson.enrollCourse("134", math161);
		assertEquals(true, elvis.isTaking("MATH", 161));
	}

	public void testDropCourseInvalidStudent()
	{
		dickinson.dropCourse("876", "MATH", 161);
	}

	public void testDropCourseInvalidCourse()
	{
		dickinson.dropCourse("123", "MATH", 162);
	}

	public void testDropCourseValid()
	{
		dickinson.dropCourse("123", "MATH", 161);
		assertEquals(false, michael.isTaking("MATH", 161));
	}

	public void testPrintStandingStats()
	{
		dickinson.printStandingStats(2006);
	}
}











