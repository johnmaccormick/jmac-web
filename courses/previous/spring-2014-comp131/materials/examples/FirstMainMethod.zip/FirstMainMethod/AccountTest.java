

/**
 * The test class AccountTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class AccountTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class AccountTest
     */
    public AccountTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	public void testWithdrawSuccess()
	{
		Account account1 = new Account(10000, 5);
		account1.deposit(1000);
		account1.withdraw(400);
		assertEquals(10600, account1.getBalance());
	}

	public void testWithdrawFail()
	{
		Account account1 = new Account(0, 5);
		account1.deposit(600);
		account1.withdraw(800);
		assertEquals(600, account1.getBalance());
	}
}


