
/**
 * A class to represent Bicycles (using composition).
 * 
 * @author Tim Wahls
 * @author (YOUR NAME HERE) 
 * @version (PUT DATE HERE)
 */
public class Bicycle
{
	// add your fields here


	/**
	 * Initialize a Bicycle object as specified by the parameters
	 * @param initManufacturer the manufacturer of the Bicycle
	 * @param initGears the number of gears (speeds) that the Bicycle has, i.e.
	 *        10 for a 10 speed, 12 for a 12 speed ...
	 * @param initSeat the seat of the Bicycle
	 * @param initFrontTire the front tire of the Bicycle
	 * @param initRearTire the rear tire of the Bicycle
	 */
	public Bicycle(String initManufacturer, int initGears, BicycleSeat initSeat,
	               Tire initFrontTire, Tire initRearTire)
	{
        // add your code here
	}

	/**
	 * get the manufacturer
	 * @return the manufacturer
	 */
	public String getManufacturer()
	{
	    // modify this code to return the bicycle manufacturer
		return "Trex";
	}

	/**
	 * get the number of gears
	 * @return the number of gears
	 */
	public int getNumberOfGears()
	{
	    // modify this code to return the number of gears
		return 0;
	}
	
	// STOP HERE FOR CLASS #18 HOMEWORK
	
	/**
	 * get the size of the front tire
	 * @return the size of the front tire
	 */
	public int getFrontTireSize() {
	    // modify this code to return the front tire size
	    return 0;
	}
	
	/**
	 * get the size of the rear tire
	 * @return the size of the rear tire
	 */
	public int getRearTireSize() {
	    // modify this code to return the rear tire size
	    return 0;
	}	

    /**
     * get the size of the seat
     * @return the size of the seat
     */
    public int getSeatSize() {
        // modify this code to return the seat size
        return 0;
    }
                                                                            
    /**
     * get the color of the seat
     * @return the color of the seat
     */
    public String getSeatColor() {
        // modify this code to return the seat color
        return "";
    }

	/**
	 * set the size of the front tire
	 * @param newFTSize the new size for the front tire
	 */
	public void setFrontTireSize(int newFTSize) {
	    // add your code here
	}	
	
	/**
	 * set the size of the rear tire
	 * @param newRTSize the new size for the rear tire
	 */
	public void setRearTireSize(int newRTSize) {
	    // add your code here
	}
}

