
/**
 * A representation of Bicycle tires.
 * 
 * @author Tim Wahls
 * @author (YOUR NAME HERE) 
 * @version (PUT DATE HERE)
 */
public class Tire
{
	// add your fields here

	/**
	 * Initialize a Tire as specified by the parameters
	 * @param initSize the tire size
	 * @param initManufacturer the tire manufacturer
	 */
	public Tire(int initSize, String initManufacturer)
	{
        // add your code here
	}

	/**
	 * get the tire size
	 * @return the tire size
	 */
	public int getSize()
	{
	    // modify this code to return the tire size
		return 0;
	}

	/**
	 * change the tire size
	 * @param newSize the new tire size
	 */
	public void setSize(int newSize)
	{
        // add your code here
	}
	
	/**
	 * get the tire manufacturer
	 * @return the tire manufacturer
	 */
	public String getManufacturer()
	{
	    // modify this code to return the tire manufacturer
		return "Pep Boys";
	}	
}
