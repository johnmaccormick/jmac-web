
/**
 * Representation of a Cell Phone account.  The phone has
 * a number, a number of minutes to be used and may or may 
 * not have a text messaging plan.  The account also keeps 
 * track of how much the user will be billed at the end of
 * the month.
 * 
 * @author (YOUR NAME HERE)
 * @version (PUT DATE HERE)
 */
public class CellPhoneAccount
{
    // Add your fields here.
    
    /**
     * Constructor for objects of class CellPhoneAccount.  This constructor
     * sets the phone number, number of minutes and whether or not the 
     * account has a text messaging plan.  The bill is initially $0.00.
     * 
     * @param initNum the phone number for this account.
     * @param initMin the number of minutes in this account.
     * @param initTxt whether or not this account has a text messaging plan.
     */
    public CellPhoneAccount(String initNum, int initMin, boolean initTxt) {
        // Add your code here.
    }
    
    /**
     * Get the phone number for this account.
     * 
     * @return the phone number.
     */
    public String getPhoneNumber() {
        return "";   // Replace with your code.
    }
    
    /**
     * Get the number of minutes remaining on this account.
     * 
     * @return the number of remaining minutes.
     */
    public int getMinutes() {
        return -1;   // Replace with your code.
    }
    
    /**
     * Determine whether or not this account has a text messaging plan.
     * 
     * @return true if this account has a text messaging plan and false
     * if it does not.
     */
    public boolean hasTextPlan() {
        return false;   // Replace with your code.
    }
    
    /**
     * Get the current bill for this account as a decimal number of
     * dollars and cents (e.g. 3.45 is 3 dollars and 45 cents.)
     * 
     * @return the current bill.
     */
    public double getBill() {
        return -1.0;    // Replace with your code.
    }
    
    /**
     * Add additional minutes to this account.
     * 
     * @param newMin the number of additional minutes to be added.
     */
    public void addMinutes(int newMin) {
        // Add your code here.
    }
    
    /**
     * Adjust this account to reflect a call that was made.  If there are
     * sufficient minutes in the account for the entire call, then the length
     * of the call is deducted from the account's minutes.  Otherwise the 
     * full length of the call is added to the account's bill at $0.50 (50 cents) 
     * per minute, and the account's minutes are not used.
     * 
     * @param callLength the length of the call in minutes.
     */
    public void makeCall(int callLength) {
        // Add your code here.
    }
    
    /**
     * Adjust the bill for this account to reflect a text message that was sent.  
     * For accounts with a text message plan, each text message costs $0.05
     * (5 cents).  For an account that does not have a text message plan
     * the cost of a text message depends upon the number of characters in
     * the message as follows:
     * 
     *   - up to 99 characters: $0.01 per character.
     *   - between 100 and 500 characters inclusive: $0.02 per character.
     *   - 501 or more characters: $0.03 per character.
     * 
     * Any message containing an image costs an additional $1.00 regardless
     * of whether the account has a text messaging plan or not.  SUGGESTION: Solve
     * the problem without worrying about images, then add code to deal with
     * the cost of images later.
     * 
     * @param msgLength the number of characters in the text message.
     * @param withImage true if the text message has an image and false
     * if it does not.
     */
    public void sendText(int msgLength, boolean withImage) {
        // Add your code here.
    }
}
