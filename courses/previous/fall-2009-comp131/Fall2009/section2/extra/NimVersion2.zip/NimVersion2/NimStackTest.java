

/**
 * The test class NimStackTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class NimStackTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class NimStackTest
     */
    public NimStackTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	public void testConstructor()
	{
		NimStack nimStack1 = new NimStack(6);
		assertEquals(6, nimStack1.getNumChips());
	}

	public void testRemoveChipsEmptyStack()
	{
		NimStack nimStack1 = new NimStack(0);
		nimStack1.removeChips(9);
		assertEquals(0, nimStack1.getNumChips());
	}

	public void testRemoveChipsLT1Chips()
	{
		NimStack nimStack1 = new NimStack(7);
		nimStack1.removeChips(0);
		assertEquals(6, nimStack1.getNumChips());
	}

	public void testRemoveChipsTooMany()
	{
		NimStack nimStack1 = new NimStack(8);
		nimStack1.removeChips(9);
		assertEquals(0, nimStack1.getNumChips());
	}

	public void testRemoveChipsNormal()
	{
		NimStack nimStack1 = new NimStack(7);
		nimStack1.removeChips(3);
		assertEquals(4, nimStack1.getNumChips());
	}
}





