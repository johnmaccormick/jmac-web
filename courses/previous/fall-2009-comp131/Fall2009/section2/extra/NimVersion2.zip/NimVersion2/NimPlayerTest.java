

/**
 * The test class NimPlayerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class NimPlayerTest extends junit.framework.TestCase
{
	

    /**
     * Default constructor for test class NimPlayerTest
     */
    public NimPlayerTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {

	}

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	

	

    public void testPerfectLoser001()
    {
        NimStack nimStack1 = new NimStack(0);
        NimStack nimStack2 = new NimStack(0);
        NimStack nimStack3 = new NimStack(1);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(0, nimStack1.getNumChips());
        assertEquals(0, nimStack2.getNumChips());
        assertEquals(0, nimStack3.getNumChips());
    }


    public void testPerfectLoser019()
    {
        NimStack nimStack1 = new NimStack(0);
        NimStack nimStack2 = new NimStack(1);
        NimStack nimStack3 = new NimStack(9);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(0, nimStack1.getNumChips());
        assertEquals(1, nimStack2.getNumChips());
        assertEquals(1, nimStack3.getNumChips());
    }


    public void testPerfectLoser152()
    {
        NimStack nimStack1 = new NimStack(1);
        NimStack nimStack2 = new NimStack(5);
        NimStack nimStack3 = new NimStack(2);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(1, nimStack1.getNumChips());
        assertEquals(3, nimStack2.getNumChips());
        assertEquals(2, nimStack3.getNumChips());
    }


    public void testPerfectLoser164()
    {
        NimStack nimStack1 = new NimStack(1);
        NimStack nimStack2 = new NimStack(6);
        NimStack nimStack3 = new NimStack(4);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(1, nimStack1.getNumChips());
        assertEquals(5, nimStack2.getNumChips());
        assertEquals(4, nimStack3.getNumChips());
    }


    public void testPerfectLoser170()
    {
        NimStack nimStack1 = new NimStack(1);
        NimStack nimStack2 = new NimStack(7);
        NimStack nimStack3 = new NimStack(0);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(1, nimStack1.getNumChips());
        assertEquals(1, nimStack2.getNumChips());
        assertEquals(0, nimStack3.getNumChips());
    }


    public void testPerfectLoser200()
    {
        NimStack nimStack1 = new NimStack(2);
        NimStack nimStack2 = new NimStack(0);
        NimStack nimStack3 = new NimStack(0);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(0, nimStack1.getNumChips());
        assertEquals(0, nimStack2.getNumChips());
        assertEquals(0, nimStack3.getNumChips());
    }


    public void testPerfectLoser213() // already balanced
    {
        NimStack nimStack1 = new NimStack(2);
        NimStack nimStack2 = new NimStack(1);
        NimStack nimStack3 = new NimStack(3);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(1, nimStack1.getNumChips());
        assertEquals(1, nimStack2.getNumChips());
        assertEquals(3, nimStack3.getNumChips());
    }


    public void testPerfectLoser321() // already balanced
    {
        NimStack nimStack1 = new NimStack(3);
        NimStack nimStack2 = new NimStack(2);
        NimStack nimStack3 = new NimStack(1);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(2, nimStack1.getNumChips());
        assertEquals(2, nimStack2.getNumChips());
        assertEquals(1, nimStack3.getNumChips());
    }

    public void testPerfectLoser123() // already balanced
    {
        NimStack nimStack1 = new NimStack(1);
        NimStack nimStack2 = new NimStack(2);
        NimStack nimStack3 = new NimStack(3);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(0, nimStack1.getNumChips());
        assertEquals(2, nimStack2.getNumChips());
        assertEquals(3, nimStack3.getNumChips());
    }



    public void testPerfectLoser300()
    {
        NimStack nimStack1 = new NimStack(3);
        NimStack nimStack2 = new NimStack(0);
        NimStack nimStack3 = new NimStack(0);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(0, nimStack1.getNumChips());
        assertEquals(0, nimStack2.getNumChips());
        assertEquals(0, nimStack3.getNumChips());
    }


    public void testPerfectLoser322()
    {
        NimStack nimStack1 = new NimStack(3);
        NimStack nimStack2 = new NimStack(2);
        NimStack nimStack3 = new NimStack(2);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(0, nimStack1.getNumChips());
        assertEquals(2, nimStack2.getNumChips());
        assertEquals(2, nimStack3.getNumChips());
    }


    public void testPerfectLoser347() // already balanced
    {
        NimStack nimStack1 = new NimStack(3);
        NimStack nimStack2 = new NimStack(4);
        NimStack nimStack3 = new NimStack(7);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(2, nimStack1.getNumChips());
        assertEquals(4, nimStack2.getNumChips());
        assertEquals(7, nimStack3.getNumChips());
    }


    public void testPerfectLoser366()
    {
        NimStack nimStack1 = new NimStack(3);
        NimStack nimStack2 = new NimStack(6);
        NimStack nimStack3 = new NimStack(6);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(0, nimStack1.getNumChips());
        assertEquals(6, nimStack2.getNumChips());
        assertEquals(6, nimStack3.getNumChips());
    }


    public void testPerfectLoser397()
    {
        NimStack nimStack1 = new NimStack(3);
        NimStack nimStack2 = new NimStack(9);
        NimStack nimStack3 = new NimStack(7);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(3, nimStack1.getNumChips());
        assertEquals(4, nimStack2.getNumChips());
        assertEquals(7, nimStack3.getNumChips());
    }


    public void testPerfectLoser525()
    {
        NimStack nimStack1 = new NimStack(5);
        NimStack nimStack2 = new NimStack(2);
        NimStack nimStack3 = new NimStack(5);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(5, nimStack1.getNumChips());
        assertEquals(0, nimStack2.getNumChips());
        assertEquals(5, nimStack3.getNumChips());
    }


    public void testPerfectLoser569()
    {
        NimStack nimStack1 = new NimStack(5);
        NimStack nimStack2 = new NimStack(6);
        NimStack nimStack3 = new NimStack(9);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(5, nimStack1.getNumChips());
        assertEquals(6, nimStack2.getNumChips());
        assertEquals(3, nimStack3.getNumChips());
    }


    public void testPerfectLoser622()
    {
        NimStack nimStack1 = new NimStack(6);
        NimStack nimStack2 = new NimStack(2);
        NimStack nimStack3 = new NimStack(2);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(0, nimStack1.getNumChips());
        assertEquals(2, nimStack2.getNumChips());
        assertEquals(2, nimStack3.getNumChips());
    }


    public void testPerfectLoser643()
    {
        NimStack nimStack1 = new NimStack(6);
        NimStack nimStack2 = new NimStack(4);
        NimStack nimStack3 = new NimStack(3);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(6, nimStack1.getNumChips());
        assertEquals(4, nimStack2.getNumChips());
        assertEquals(2, nimStack3.getNumChips());
    }


    public void testPerfectLoser668()
    {
        NimStack nimStack1 = new NimStack(6);
        NimStack nimStack2 = new NimStack(6);
        NimStack nimStack3 = new NimStack(8);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(6, nimStack1.getNumChips());
        assertEquals(6, nimStack2.getNumChips());
        assertEquals(0, nimStack3.getNumChips());
    }


    public void testPerfectLoser753()
    {
        NimStack nimStack1 = new NimStack(7);
        NimStack nimStack2 = new NimStack(5);
        NimStack nimStack3 = new NimStack(3);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(6, nimStack1.getNumChips());
        assertEquals(5, nimStack2.getNumChips());
        assertEquals(3, nimStack3.getNumChips());
    }


    public void testPerfectLoser809()
    {
        NimStack nimStack1 = new NimStack(8);
        NimStack nimStack2 = new NimStack(0);
        NimStack nimStack3 = new NimStack(9);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(8, nimStack1.getNumChips());
        assertEquals(0, nimStack2.getNumChips());
        assertEquals(8, nimStack3.getNumChips());
    }


    public void testPerfectLoser941()
    {
        NimStack nimStack1 = new NimStack(9);
        NimStack nimStack2 = new NimStack(4);
        NimStack nimStack3 = new NimStack(1);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(5, nimStack1.getNumChips());
        assertEquals(4, nimStack2.getNumChips());
        assertEquals(1, nimStack3.getNumChips());
    }


    public void testPerfectLoser991()
    {
        NimStack nimStack1 = new NimStack(9);
        NimStack nimStack2 = new NimStack(9);
        NimStack nimStack3 = new NimStack(1);
        NimPlayer nimPlaye1 = new NimPlayer(nimStack1, nimStack2, nimStack3);
        nimPlaye1.perfectLoser();
        assertEquals(8, nimStack1.getNumChips());
        assertEquals(9, nimStack2.getNumChips());
        assertEquals(1, nimStack3.getNumChips());
    }

}


