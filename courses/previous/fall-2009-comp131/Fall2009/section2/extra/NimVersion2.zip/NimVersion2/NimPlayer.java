import java.util.ArrayList;

/**
 * This class implements different strategies for playing 3 stack Nim. During
 * each turn one of the strategy methods will be invoked by the GUI.  
 * The strategy must remove chips from one and only one stack during each turn. 
 * If a strategy removes chips from more than one stack during a single turn or 
 * does not remove any chips during a turn that player forfeits the game.
 * 
 * This implementation stores the stacks in an ArrayList and can thus easily scale 
 * up to a larger (or smaller) number of stacks.  The constructor takes 3 stacks 
 * and stores them in order in the ArrayList.
 * 
 * @author Grant Braught
 * @author Nathan Vaillette
 * @author (YOUR NAME HERE)
 * @version (PUT DATE HERE)
 */
public class NimPlayer {

    private ArrayList<NimStack> stacks;

    /**
     * Create a new NimPlayer that will play the game using the provided stacks.
     * 
     * @param stack1 the first stack of chips
     * @param stack2 the second stack of chips
     * @param stack3 the third stack of chips
     */
    public NimPlayer(NimStack stack1, NimStack stack2, NimStack stack3) {
        stacks = new ArrayList<NimStack>();
        stacks.add(stack1);
        stacks.add(stack2);
        stacks.add(stack3);
    }
    
    /**
     * Get the total number of chips remaining on all of the NimStacks.
     * 
     * @return the total number of chips.
     */
    public int getTotalChips() {
        return 0;
    }
    

    /**
     * This strategy plays by removing a single chip from the largest NimStack
     * (i.e. the one with the most chips). If there is a tie for the largest
     * stack then the chip may be removed from any stack that is tied.
     */
    public void takeOneFromLargest() {    
    }

    /**
     * This strategy plays by removing 5 chips from any NimStack with 5 or more
     * chips. If no stack has at least 5 chips then one chip is removed from the
     * largest remaining stack. If there is a tie for the largest stack then the
     * chip may be removed from any stack that is tied.
     */
    public void takeFiveFromAny() {   
    }

    /**
     * This strategy plays by removing half of the chips from any non-empty
     * stack.  If the stack has an even number of chips then exactly half
     * of the chips are removed.  If the stack has an odd number of chips then
     * half of one more than the number of chips are removed (e.g. if there 
     * are 5 chips then (5+1)/2 = 3 chips are removed).
     */
    public void takeHalfFromAny() {           
    }
        
    
    /**
     * This strategy is guaranteed to lose if a loss is possible (some situations 
     * may arise in which your opponent can force you to win, if s/he is so inclined).  
     * This strategy is slightly easier to implement than one that guarantees a win when
     * possible.  See http://en.wikipedia.org/wiki/Nim for more details.
     *
     * This strategy is based on the concept of a nimsum, which we will represent in 
     * these comments as x # y (note that # is not a Java operator).  The nimsum x # y 
     * of two integers x and y can be computed with the Java expression 
     * 
     *          (x | y) & ~(x & y)
     *          
     * (see http://java.sun.com/docs/books/tutorial/java/nutsandbolts/op3.html for more information).
     * 
     * To implement this strategy, start by finding the combined nimsum of the sizes of 
     * all the stacks, i.e.
     * 
     *         combinedNimSum = sizeOfStack1 # sizeOfStack2 # .... # sizeOfStackN
     *         
     * (You may find it useful to know that x # 0 = 0 # x = x for all x).  Then go through 
     * each stack in order and find the nimsum of its size with the combined nimsum of the sizes 
     * of all the stacks, i.e. find
     *         
     *         sizeOfStack # combinedNimSum
     * 
     * For the first stack that you find such that sizeOfStack # combinedNimSum < combinedNimSum, 
     * remove chips from that stack so that its new size is sizeOfStack # combinedNimSum.  
     * If you cannot find such a stack, then you not able to force a loss, so just take one chip 
     * from the first non-empty stack and hope for the best (or the worst, as it were).
     */
    
    public void perfectLoser() {
    }
}
