

/**
 * The test class AccountTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class AccountTest extends junit.framework.TestCase
{
    private Account account1;

    /**
     * Default constructor for test class AccountTest
     */
    public AccountTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
        account1 = new Account(23);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

    public void testOneParamConstructor()
    {
        assertEquals(23, account1.getAccountNumber());
        assertEquals(0, account1.getBalance());
        assertEquals(2, account1.getInterestRate());
    }
    
    public void testNoParamConstructor()
    {
        Account act1 = new Account();
        assertEquals(0, act1.getAccountNumber());
        assertEquals(0, act1.getBalance());
        assertEquals(2, act1.getInterestRate());
    }
    
    public void testTwoParamConstructor()
    {
        Account act1 = new Account(1234, 5);
        assertEquals(1234, act1.getAccountNumber());
        assertEquals(0, act1.getBalance());
        assertEquals(5, act1.getInterestRate());
    }
    
    public void testWithdrawValid()
    {
        account1.deposit(112);
        account1.withdraw(23);
        assertEquals(89, account1.getBalance());
    }
    
    public void testWithdrawOverdraft() {
        account1.deposit(85);
        account1.withdraw(111);
        assertEquals(85, account1.getBalance());
    }
    
    public void testDepositValid()
    {
        account1.deposit(100);
        account1.deposit(200);
        assertEquals(300, account1.getBalance());
    }
    
    public void testDepositNegative()
    {
        account1.deposit(-100);
        assertEquals(0, account1.getBalance());
    }
}




