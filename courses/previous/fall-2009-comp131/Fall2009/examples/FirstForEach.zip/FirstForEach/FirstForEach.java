import java.util.HashMap;
import java.util.Set;
import java.util.ArrayList;

/**
 * Demonstration of the use of KeySets and the for each loop.
 * 
 * @author Grant Braught
 * @version Nov 26, 2007
 */
public class FirstForEach
{
    private HashMap<String, String> phoneNumbers;
    
    public FirstForEach() {
        phoneNumbers = new HashMap<String, String>();
        phoneNumbers.put("Jenny", "867-5309eine");
        phoneNumbers.put("Tommy Tutone", "555-1234");
    }
    
    /**
     * Use a KeySet and a for each loop to print out the
     * list of keys in the HashMap.
     */
    public void printKeys() {
        Set<String> keys = phoneNumbers.keySet();
        for (String key : keys) {
            System.out.println(key);
        }
    }
    
    /**
     * Use a KeySet and a for each loop to retrieve and print
     * each of the values in the HashMap.
     */
    public void printValues() {
        Set<String> keys = phoneNumbers.keySet();
        for (String key : keys) {
            String value = phoneNumbers.get(key);
            System.out.println(value);
        }
    }
    
    /**
     * For each loops can be used to iterate over the elements
     * of an ArrayList as well.
     */
    public void forEachWithArrayList() {
        ArrayList<String> demo = new ArrayList<String>();
        demo.add("One");
        demo.add("Two");
        demo.add("Three");
        
        for (String val : demo) {
            System.out.println(val);
        }
        
        // The for each loop has the same effect as:
        for (int i=0; i<demo.size(); i++) {
            String val = demo.get(i);
            System.out.println(val);
        }
    }
    
    /**
     * For each loops can be used to iterate over the elements
     * of an array as well.
     */
    public void forEachWithArray() {
        int[] myArray = new int[5];
        myArray[0] = 10;
        myArray[1] = 9;
        myArray[2] = 8;
        myArray[3] = 7;
        myArray[4] = 6;
        
        for (int val : myArray) {
            System.out.println(val);
        }
        
        // The for each loop has the same effect as:
        for (int i=0; i<myArray.length; i++) {
            int val = myArray[i];
            System.out.println(val);
        }
    }       
}
