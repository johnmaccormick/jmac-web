

/**
 * The test class AccountTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class AccountTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class AccountTest
     */
    public AccountTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	public void testWithdrawSuccess()
	{
		Account account2 = new Account(123);
		account2.deposit(500);
		account2.withdraw(327);
		assertEquals(173, account2.getBalance());
	}

	public void testWithdrawFail()
	{
		Account account1 = new Account(123);
		account1.deposit(200);
		account1.withdraw(300);
		assertEquals(200, account1.getBalance());
	}
}


