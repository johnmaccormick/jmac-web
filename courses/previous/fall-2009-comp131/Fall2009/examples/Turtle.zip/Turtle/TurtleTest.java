

/**
 * The test class TurtleTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class TurtleTest extends junit.framework.TestCase
{
    /**
     * Default constructor for test class TurtleTest
     */
    public TurtleTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	public void testDefaultConstructor()
	{
		Turtle turtle1 = new Turtle();
		assertEquals(0, turtle1.getAngle());
		assertEquals(false, turtle1.isPenDown());
		assertEquals("black", turtle1.getColor());
		assertEquals(50.0, turtle1.getX(), 0.5);
		assertEquals(50.0, turtle1.getY(), 0.5);
	}

	public void testPutPenDown()
	{
		Turtle turtle2 = new Turtle();
		turtle2.putPenDown();
		assertEquals(true, turtle2.isPenDown());
	}

	public void testRotateToLT360()
	{
		Turtle turtle1 = new Turtle(0,0,50,"blue");
		turtle1.rotate(60);
		assertEquals(110, turtle1.getAngle());
	}

	public void testRotateToGT360()
	{
		Turtle turtle1 = new Turtle(0,0,50,"blue");
		turtle1.rotate(320);
		assertEquals(10, turtle1.getAngle());
	}

	public void testMoveForwardAt0Deg()
	{
		Turtle turtle1 = new Turtle();
		turtle1.moveForward(10);
		assertEquals(60.0, turtle1.getX(), 0.5);
		assertEquals(50.0, turtle1.getY(), 0.5);
		turtle1.moveForward(5);
		assertEquals(65.0, turtle1.getX(), 0.5);
		assertEquals(50.0, turtle1.getY(), 0.5);
	}

	public void testMoveForwardAt90Deg()
	{
		Turtle turtle1 = new Turtle();
		turtle1.rotate(90);
		turtle1.moveForward(10);
		assertEquals(50, turtle1.getX(), 0.5);
		assertEquals(40, turtle1.getY(), 0.5);
		turtle1.moveForward(5);
		assertEquals(50, turtle1.getX(), 0.5);
		assertEquals(35, turtle1.getY(), 0.5);
	}

	public void testMoveForwardAt30Deg()
	{
		Turtle turtle1 = new Turtle();
		turtle1.rotate(30);
		turtle1.moveForward(10);
		assertEquals(58.66, turtle1.getX(), 0.5);
		assertEquals(45, turtle1.getY(), 0.5);
	}
}