import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TurtleDialog 
    extends JDialog {

    private TurtleControls tc;
    
    private JTextField nameField;
    private JTextField xField;
    private JTextField yField;
    private JTextField thetaField;
    private JComboBox colorPicker;
    
    // Probably better to use a hash map here instead of parallel arrays. 
    public static final String[] colors = {"black", "red", "green", "blue"};
    public static final Color[] colorObjs = 
    {Color.black, Color.red, Color.green, Color.blue};
    
    //private JButton colorButton;

    public TurtleDialog(Frame owner, TurtleControls cont) {
    super(owner,"New Turtle Creation", true);
    
    tc = cont;
    Container pane = getContentPane();

    // Buttons...
    JPanel p = new JPanel();
    JButton b = new JButton("OK");
    ButtonHandler bh = new ButtonHandler(this);
    b.addActionListener(bh);
    p.add(b);
    b = new JButton("Cancel");
    b.addActionListener(bh);
    p.add(b);
    
    // Labels and Fields
    JPanel name = new JPanel();
    name.add(new JLabel("Name:"));
    nameField = new JTextField(20);
    name.add(nameField);
    
    JPanel xytheta = new JPanel();
    xytheta.add(new JLabel("x:"));
    xField = new JTextField("100",3);
    xytheta.add(xField);
    xytheta.add(new JLabel("y;"));
    yField = new JTextField("100",3);
    xytheta.add(yField);
    xytheta.add(new JLabel("angle:"));
    thetaField = new JTextField("0",3);
    xytheta.add(thetaField);

    colorPicker = new JComboBox();
    for (int i=0; i<colors.length; i++) {
        colorPicker.addItem(colors[i]);
    }
    
    /*
    colorButton = new JButton("Color");
    colorButton.setBackground(Color.black);
    colorButton.setForeground(Color.white);
    colorButton.addActionListener(bh);
    */

    JPanel center = new JPanel(new GridLayout(3,1));
    center.add(name);
    center.add(xytheta);
    center.add(colorPicker);
    //center.add(colorButton);

    pane.add(center, BorderLayout.CENTER);
    pane.add(p, BorderLayout.SOUTH);
    }

    
    // Add listener for OK button and then create
    // a new turtle and close the window.
    private class ButtonHandler 
    implements ActionListener {

    private TurtleDialog d;

    public ButtonHandler(TurtleDialog t) {
        d = t;
    }
    
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        if (cmd.equals("OK")) {
        // Create the new Turtle...

        try {
            int x = Integer.parseInt(xField.getText());
            int y = Integer.parseInt(yField.getText());
            int t = Integer.parseInt(thetaField.getText());
            String c = (String)colorPicker.getSelectedItem();

            tc.addTurtle(nameField.getText(), new Turtle(x,y,t,c));
            //d.hide(); deprecated in 1.5
            d.setVisible(false);
        }
        catch(NumberFormatException nfe) {
            
        }
        }
        else if (cmd.equals("Cancel")) {
        // d.hide(); Deprecated in 1.5
        d.setVisible(false);
        }
        /*
        else if (cmd.equals("Color")) {
        Color c = JColorChooser.showDialog(d,"Turtle Color",
                           colorButton.getBackground());
        if (c != null) {
            colorButton.setBackground(c);
        }
        }
        */
    }
    }
}
