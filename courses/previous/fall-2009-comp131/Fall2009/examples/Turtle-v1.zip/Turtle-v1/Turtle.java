/**
 * The Turtle class describes Turtle objects which
 * represent the drawing turtle in a turtle graphics
 * application. Each turtle has a position on the
 * screen, a color and an angle (in degrees) indicating 
 * the direction in which the turtle is traveling.  Also, 
 * a turtle's pen may either be down (drawing) or 
 * up (not drawing).
 */
public class Turtle {
    
    private double xPos;
    private double yPos;
    private int angle;
    private String penColor;
    private boolean penDown;  // true means pen is down.

    /**
     * Construct a new default Turtle.  The new Turtle will
     * appear at position 50,50, will have an angle of 0 degrees,
     * its pen will be "black" and will be up.
     */
    public Turtle() {   
        xPos = 50;
        yPos = 50;
        angle = 0;
        penColor = "black";
        penDown = false;
    }   
    
    /**
     * Construct a new Turtle with the specified parameters. The
     * new Turtle's pen will be up.
     *
     * @param initX the initial x position for the new Turtle.
     * @param initY the initial y position for the new Turtle.
     * @param initAngle the initial angle (in degrees) for the new Turtle.
     * @param initColor the color of the new Turtle's pen. Valid colors
     * are "black", "red", "green", "blue"
     */
    public Turtle(double initX, double initY, 
        int initAngle, String initColor) {
            xPos=initX;
            yPos=initY;
            angle=initAngle;
            penColor = initColor;
            penDown = false;
    }

    /**
     * Get the x position of this Turtle.
     *
     * @return the x position of this Turtle.
     */
    public double getX() {
        return xPos;
    }

    /**
     * Get the y position of this Turtle.
     *
     * @return the y position of this Turtle.
     */
    public double getY() {
        return yPos;
    }

    /**
     * Get the color of this Turtle's pen. The color is 
     * returned as a String containing the name of the color.
     *
     * @return a String indicating the color of this Turtle's pen.
     */
    public String getColor() {
        return penColor;
    }

    /**
     * Get the the angle to which this Turtle is turned.  
     * The angle of the Turtle is measured counter-clockwise
     * from horizontal.
     *
     * @return the angle to which this Turtle is turned. 
     */
    public int getAngle() {
        return angle;
    }
    
    /**
     * Ask this Turtle if its pen is down.
     * 
     * @return true if this Turtle's pen is down or
     *         false if this Turtle's pen is up.
     */
    public boolean isPenDown() {
        return penDown;
    }
    
    /**
     * Put this Turtle's pen down. When this Turtle's pen is
     * down it will draw a line in its color as it moves
     * forward.
     */
    public void putPenDown() {
        
    }

    /**
     * Pick this Turtle's pen up. When this Turtle's pen is
     * up it will not draw a line as it moves forward.
     */
    public void pickPenUp() {
        
    }

    /**
     * Rotate this Turtle counter-clockwise by the specified 
     * number of degrees. The angle should never be larger 
     * than 359 degrees.
     *
     * @param degrees the number of degrees by which to rotate
     *                this Turtle.
     */
    public void rotate(int degrees) {
        
    }
    
    /**
     * Move this Turtle forward by the specified number of
     * screen pixels.
     *
     * @param pixels the number of screen pixes by which
     *               to move this Turtle forward. 
     */
    public void moveForward(int pixels) {
        
    }
}

    
