
/**
 * Demonstrates a hybrid Of cascading and nested if statements.
 * 
 * @author jmac
 * @version 10/5/09
 */
public class Hybrid
{
    public Hybrid()
    {
        int x = 15;
        
        if (x < 0) {
            System.out.println("apple");
        }
        else if (x > 20) {
            System.out.println("banana");
        }
        else if (x > 10) {
            if (x < 17) {
                System.out.println("coconut");
            }
            else {
                System.out.println("donut");
            }
        }
        else {
            System.out.println("egg");
        }
        
            
    }

}
