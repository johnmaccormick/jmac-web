import java.util.ArrayList;

/**
 * A class to keep track of a library of books.
 * 
 * @author Tim Wahls 
 * @author (YOUR NAME HERE)
 * @version (PUT DATE HERE)
 */
public class Library
{
    private String libName;
    private ArrayList<Book> books;

    /**
     * Create a new Library with the specified name and no books
     * 
     * @param initName name of the library
     */
    public Library(String initName)
    {

    }

    /**
     * get the name of the library
     * 
     * @return the name of the library
     */
    public String getLibraryName()
    {
        return "";
    }

    /**
     * get the number of books in the library
     * 
     * @return the number of books in the library
     */
    public int getNumBooks() {
        return -1;
    }
    
    /**
     * add a book to the library
     * 
     * @param newBook the book to add
     */
    public void addBook(Book newBook) {

    }

    /**
     * get a book by call number
     * 
     * @param callNum the call number
     * @return the book with the specified call number, or null if no book
     * in the library has that call number
     */
    public Book getBook(String callNum) {
        return null;
    }
    
    /**
     * determine whether or not the library has a book by the specified author
     * 
     * @param author the author's name
     * @return true if the library has a book by the specified author, false o.w.
     */
    public boolean hasBookByAuthor(String author) {
        for (Book current : books) {
            if (author.equals(current.getAuthor())) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * remove a book by the specified author from the library's collection, and
     * display an error message if the library has no books by that author
     * 
     * @param author the author's name
     */
    public void deleteBookByAuthor(String author) {
        int pos = 0;
        boolean found = false;
        while (pos < books.size() && !found) {
            Book current = (Book) books.get(pos);
            if (author.equals(current.getAuthor())) {
                found = true;
            } else {
                pos++;
            }
        }
        if (found) {
            books.remove(pos);
        } else {
            System.out.println("Error: the library has no books by " + author);
        }
    }    
    
    /**
     * check out the specified book, displaying an error message if the library does
     * not have the book with the specified call number, or if the book is already
     * checked out.
     * 
     * @param callNum the call number of the book to check out
     */
    public void checkOutBook(String callNum) {

    }
     
    /**
     * return the specified book, displaying an error message if the library does
     * not have the book with the specified call number, or if the book is not
     * checked out.
     * 
     * @param callNum the call number of the book to check out
     */
    public void returnBook(String callNum) {

    }   
    
    /**
     * display information about the library
     */
    public void print() {        
        System.out.println(libName);
        
        for (Book current : books) {
            System.out.println();
            current.print();
        }
    }
}
