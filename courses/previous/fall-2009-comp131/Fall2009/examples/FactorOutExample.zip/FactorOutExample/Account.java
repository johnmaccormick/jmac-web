/**
 * A simple model of a bank account to demonstrate the concept
 * of factoring out repeated code. This class contains some
 * repeated code, and is therefore difficult to maintain.
 * 
 * @author jmac
 */
public class Account {
    // annual interest rate in percentage points
    private double interestRate;
    // account balance in dollars
    private double balance;
    
    /**
     * Create a new Account with the given interest rate and
     * balance.
     */
    public Account(double interestRate, double balance) {
        this.interestRate = interestRate;
        this.balance = balance;
    }

    /**
     * Accessor for the interestRate field
     */
    public double getInterestRate() {
        return interestRate;   
    }    
    
    /**
     * Accessor for the balance field
     */
    public double getBalance() {
        return balance;   
    }
    
    /**
     * Print the balance this account would
     * have after the given number of years
     */
    public void printFutureBalance(int years) {
        double newBalance = balance;
        for (int i = 0; i < years; i++) {
            newBalance = newBalance * (1 + interestRate / 100);
        }
        
        System.out.println("balance after " + years + 
                           " year(s) would be " + newBalance);
    }
     
    /**
     * Add the amount interest for the given
     * number of years to the current balance.
     */
    public void addAnnualInterest(int years) {
        double newBalance = balance;
        for (int i = 0; i < years; i++) {
            newBalance = newBalance * (1 + interestRate / 100);
        }
        
        balance = newBalance;
    }

}
