

/**
 * The test class AccountTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class AccountTest extends junit.framework.TestCase
{
	private Account account1;

    /**
     * Default constructor for test class AccountTest
     */
    public AccountTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
		account1 = new Account(10, 100);
	}

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	public void testConstructor()
	{
		Account account1 = new Account(5, 23.4);
		assertEquals(5, account1.getInterestRate(), 0.01);
		assertEquals(23.4, account1.getBalance(), 0.01);
	}

	public void testPrintFutureBalance()
	{
		account1.printFutureBalance(2);
	}

	public void testAddAnnualInterest()
	{
		account1.addAnnualInterest(2);
		assertEquals(121, account1.getBalance(), 0.01);
	}
}




