/**
 * A simple model of a bank account to demonstrate the
 * concept of factoring out repeated code. In this class,
 * the repeated code in the Account class has been factored
 * out into a new method, meaning that this class is easier
 * to maintain.
 * 
 * @author jmac
 */
public class RefactoredAccount {
    // annual interest rate in percentage points
    private double interestRate;
    // account balance in dollars
    private double balance;

    /**
     * Create a new Account with the given interest rate and
     * balance.
     */
    public RefactoredAccount(double interestRate, double balance) {
        this.interestRate = interestRate;
        this.balance = balance;
    }

    /**
     * Accessor for the interestRate field
     */
    public double getInterestRate() {
        return interestRate;   
    }    
    
    /**
     * Accessor for the balance field
     */
    public double getBalance() {
        return balance;   
    }
     
    
    /**
     * Print the balance this account would
     * have after the given number of years
     */
    public void printFutureBalance(int years) {
        double newBalance = balance;
        for (int i = 0; i < years; i++) {
            newBalance = newBalance * (1 + interestRate / 100);
        }
        
        System.out.println("balance after " + years + 
                           " year(s) would be " + newBalance);
    }
     
    /**
     * Add the amount interest for the given
     * number of years to the current balance.
     */
    public void addAnnualInterest(int years) {
        double newBalance = futureBalance(years);
        balance = newBalance;
    }   
    
    /**
     * Return the balance this account would
     * have after the given number of years
     */
    public double futureBalance(int years) {
        double newBalance = futureBalance(years);
        return newBalance;
    }    

}
