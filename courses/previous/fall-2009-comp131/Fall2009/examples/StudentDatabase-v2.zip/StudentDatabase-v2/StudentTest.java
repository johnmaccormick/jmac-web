

/**
 * The test class StudentTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class StudentTest extends junit.framework.TestCase
{
    private Student michael;
    private Course cs1311;
    private Course cs1312;
    private Course cs132;
    private Course math161;
    private Course math162;
    
    /**
     * Default constructor for test class StudentTest
     */
    public StudentTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    protected void setUp()
    {
		michael = new Student("Michael Jackson", "123", 2008, 3.68);
		cs1311 = new Course("COSCI", 1311, "Spring", 2006, "MWF 10:30 a.m.", "Tome 118", "Tim Wahls");
		cs1312 = new Course("COSCI", 1312, "Spring", 2006, "MWF 11:30 a.m.", "Tome 120", "Grant Braught");
		cs132 = new Course("COSCI", 132, "Spring", 2006, "MWF 11:30 a.m.", "Tome 118", "A.C. Chapin");
		math161 = new Course("MATH", 161, "Spring", 2006, "MWF 12:30 a.m.", "Tome 117", "Barry Tesman");
		math162 = new Course("MATH", 162, "Spring", 2006, "MWF 9:30 a.m.", "Tome 117", "Dave Richeson");
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    protected void tearDown()
    {
    }

	public void testConstructor()
	{
		assertEquals("Michael Jackson", michael.getName());
		assertEquals("123", michael.getStudentID());
		assertEquals(3.68, michael.getGPA(), 0.1);
		assertEquals(2008, michael.getGraduationYear());
		assertEquals(0, michael.getNumberOfCourses());
	}

	public void testSetGPA()
	{
		michael.setGPA(3.50);
		assertEquals(3.5, michael.getGPA(), .1);
	}

	public void testIsTakingEmpty()
	{
		assertEquals(false, michael.isTaking("COSCI", 1312));
	}

	public void testAddCourseAndIsTakingTrue()
	{
		michael.addCourse(cs1312);
		michael.addCourse(math161);
		assertEquals(2, michael.getNumberOfCourses());
		assertEquals(true, michael.isTaking("COSCI", 1312));
		assertEquals(true, michael.isTaking("MATH", 161));
	}

	public void testIsTakingFalse()
	{
		michael.addCourse(cs1312);
		michael.addCourse(math161);
		assertEquals(false, michael.isTaking("MATH", 162));
	}

	public void testToString()
	{
		michael.addCourse(cs1312);
		michael.addCourse(math161);
		String res = "Michael Jackson (student ID: 123) has a GPA of 3.68, is graduating in 2008 and is taking:\nCOSCI 1312, Spring 2006, MWF 11:30 a.m. Tome 120, Grant Braught\nMATH 161, Spring 2006, MWF 12:30 a.m. Tome 117, Barry Tesman\n";
		assertEquals(res, michael.toString());
	}

	public void testDropCourseEmpty()
	{
		michael.dropCourse("MATH", 161);
		assertEquals(0, michael.getNumberOfCourses());
	}

	public void testDropCourseNotTaken()
	{
		michael.addCourse(math161);
		michael.addCourse(cs132);
		michael.dropCourse("MATH", 162);
		assertEquals(2, michael.getNumberOfCourses());
	}

	public void testDropCourseFirst()
	{
		michael.addCourse(cs1311);
		michael.addCourse(cs132);
		michael.addCourse(math161);
		michael.dropCourse("COSCI", 1311);
		assertEquals(2, michael.getNumberOfCourses());
		assertEquals(false, michael.isTaking("COSCI", 1311));
		assertEquals(true, michael.isTaking("COSCI", 132));
		assertEquals(true, michael.isTaking("MATH", 161));
	}

	public void testDropCourseMiddle()
	{
		michael.addCourse(cs1311);
		michael.addCourse(cs132);
		michael.addCourse(math161);
		michael.dropCourse("COSCI", 132);
		assertEquals(2, michael.getNumberOfCourses());
		assertEquals(false, michael.isTaking("COSCI", 132));
		assertEquals(true, michael.isTaking("COSCI", 1311));
		assertEquals(true, michael.isTaking("MATH", 161));
	}

	public void testDropCourseLast()
	{
		michael.addCourse(cs1311);
		michael.addCourse(cs132);
		michael.addCourse(math161);
		michael.dropCourse("MATH", 161);
		assertEquals(2, michael.getNumberOfCourses());
		assertEquals(true, michael.isTaking("COSCI", 1311));
		assertEquals(true, michael.isTaking("COSCI", 132));
		assertEquals(false, michael.isTaking("MATH", 161));
	}

	public void testYearsLeftSenior()
	{
		assertEquals("senior", michael.getStanding(2008));
	}

	public void testYearsLeftJunior()
	{
		assertEquals("junior", michael.getStanding(2007));
	}	

	public void testYearsLeftSoph()
	{
		assertEquals("sophomore", michael.getStanding(2006));
	}

	public void testYearsLeftFstYear()
	{
		assertEquals("first year", michael.getStanding(2005));
	}

	public void testYearsLeftOther()
	{
		assertEquals("potential donor", michael.getStanding(2010));
	}	
}













