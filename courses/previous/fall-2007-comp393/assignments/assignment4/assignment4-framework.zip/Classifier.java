import java.util.Hashtable;

/**
 * The Classifier class represents an algorithm for classifying the instances of
 * a particular machine learning problem. Classifier is an abstract class, so
 * actual classification algorithms are implemented by extending this class and
 * implementing the abstract methods.
 * 
 * @author jmac
 * 
 */
public abstract class Classifier {
	public static final String missingData = "?";
	public static final String unknownClass = "unknown";

	/**
	 * The set of attributes used by a particular machine learning problem.
	 */
	protected AttributeSet attributeSet;

	/**
	 * Learn a classifier from the given training set
	 * 
	 * @param trainingSet
	 *            the training set from which to learn the classifier
	 * @throws Exception
	 */
	public abstract void learn(InstanceSet trainingSet) throws Exception;

	/**
	 * @param instance
	 *            the instance whose class is to be decided
	 * @return the class value of the instance
	 * @throws Exception
	 */
	public abstract String decide(Instance instance) throws Exception;

	/**
	 * @param instance
	 *            the instance whose class probabilities are to be computed
	 * @return a table mapping class values to their probabilities
	 * @throws Exception
	 */
	public abstract Hashtable<String, Double> computeClassProbabilities(
			Instance instance) throws Exception;

	/**
	 * print out a legible form of the classifier
	 * 
	 * @throws Exception
	 */
	public abstract void print() throws Exception;

	/**
	 * @param attributeSet the set of attributes to be used by this classifier
	 */
	public Classifier(AttributeSet attributeSet) {
		this.attributeSet = attributeSet;
	}

	/**
	 * @param testSet
	 *            the test set on which the error rate will be computed
	 * @return the error rate, expressed as a number between 0 and 1, of this
	 *         classifier on the given test set
	 * @throws Exception
	 */
	public double computeErrorRate(InstanceSet testSet) throws Exception {
		int num_errors = 0;
		for (Instance instance : testSet.getInstances()) {
			String decision = decide(instance);
			String mlClass = instance.getValues()[attributeSet.getClassAttributeIndex()];
			if (!decision.equals(mlClass))
				num_errors++;
		}
		return (double) num_errors / testSet.getInstances().size();
	}

	/**
	 * Print out the decision (i.e. which class does the classifier believe this
	 * instance belongs to) and class probabilities for each instance in the
	 * given test set
	 * 
	 * @param testSet
	 *            the test set whose decision and probabilities should be
	 *            printed out
	 * @throws Exception
	 */
	public void printDecisionsAndProbabilities(InstanceSet testSet)
			throws Exception {
		for (Instance instance : testSet.getInstances()) {
			String decision = decide(instance);
			Hashtable<String, Double> probabilities = computeClassProbabilities(instance);
			System.out.print("instance: ");
			instance.print();
			System.out.println("decision: " + decision);
			System.out.print("class probabilities: ");
			if (probabilities == null) {
				System.out.print("could not compute");
			} else {
				for (String value : probabilities.keySet()) {
					System.out.print(value + ":" + probabilities.get(value)
							+ " ");
				}
			}
			System.out.println();
		}
	}

	/**
	 * Run a user-selected algorithm on a user-selected data file
	 * @param arguments OneR|Bayes|Stump|Tree datafilename
	 */
	public static void main(String[] arguments) {
		try {
			if (arguments.length != 2) {
				throw new Exception(
						"usage: java Classifier OneR|Bayes|Stump|Tree datafilename");
			}
			String algorithmName = arguments[0];
			String inputFilename = arguments[1];
			InstanceSet trainingSet = new InstanceSet(inputFilename);
			Classifier classifier;
			if (algorithmName.equals("OneR"))
				classifier = new OneRClassifier(trainingSet.getAttributeSet());
			else if (algorithmName.equals("Bayes"))
				classifier = new NaiveBayes(trainingSet.getAttributeSet());
			else if (algorithmName.equals("Stump"))
				classifier = new DecisionStump(trainingSet.getAttributeSet());
			else if (algorithmName.equals("Tree"))
				classifier = new DecisionTree(trainingSet.getAttributeSet());
			else
				throw new Exception("Unknown algorithm" + algorithmName);

			classifier.learn(trainingSet);
			classifier.print();
			double error_rate = classifier.computeErrorRate(trainingSet);
			System.out.println("Error rate on training set: " + error_rate);
			System.out.println();
			classifier.printDecisionsAndProbabilities(trainingSet);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	/**
	 * @return the attributeSet used by this machine learning problem
	 */
	public AttributeSet getAttributeSet() {
		return attributeSet;
	}

}
