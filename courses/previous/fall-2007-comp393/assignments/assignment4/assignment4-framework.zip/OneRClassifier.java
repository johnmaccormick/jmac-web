import java.util.Hashtable;
import java.util.ArrayList;

/**
 * The OneRClassifier class implements the 1R classification algorithm
 * 
 * @author jmac
 * 
 */
public class OneRClassifier extends Classifier {
	// A list of the possible rules considered by the classifier --
	// one for each attribute
	private ArrayList<SingleAttributeRule> rules;

	// The single best rule found
	private SingleAttributeRule bestRule;

	public OneRClassifier(AttributeSet attributeSet) {
		super(attributeSet);
	}

	public void learn(InstanceSet trainingSet) {
		this.attributeSet = trainingSet.getAttributeSet();
		makeRules(trainingSet);
		computeBestAttribute();
	}

	// The 1R algorithm makes a decision by applying the best rule it
	// found
	public String decide(Instance instance) {
		String bestAttributeValue = instance.getValues()[bestRule
				.getAttributeIndex()];
		String decision;
		if (bestAttributeValue.equals(Classifier.missingData))
			decision = Classifier.unknownClass;
		else
			decision = bestRule.getDecisions().get(bestAttributeValue);
		assert decision != null;
		return decision;
	}

	// Class probabilities for the 1R algorithm are rather inaccurate,
	// but we compute them by simply looking at the distribution of
	// machine learning classes over those instances in the training
	// set whose "best" attribute agrees with the given instance
	public Hashtable<String, Double> computeClassProbabilities(Instance instance) {
		String bestAttributeValue = instance.getValues()[bestRule
				.getAttributeIndex()];
		return bestRule.computeClassProbabilities(bestAttributeValue);
	}

	public void print() {
		for (SingleAttributeRule rule : rules) {
			rule.print();
		}
		System.out.println("Best attribute is "
				+ bestRule.getAttribute().getName() + ", error rate "
				+ bestRule.getTotalErrors() + "/"
				+ bestRule.getTrainingSetSize());
	}

	private void makeRules(InstanceSet trainingSet) {
		this.rules = new ArrayList<SingleAttributeRule>();
		for (Attribute attribute : trainingSet.getAttributeSet()
				.getAttributes()) {
			// Don't build a rule for the machine learning class attribute
			if (attribute.getName().equals(
					trainingSet.getAttributeSet().getClassAttributeAsString())) {
				continue;
			}
			SingleAttributeRule rule = new SingleAttributeRule(trainingSet,
					attribute);
			rules.add(rule);
		}
	}

	// Find the rule with the smallest number of errors
	private void computeBestAttribute() {
		int best_num_errors = Integer.MAX_VALUE;
		for (SingleAttributeRule rule : rules) {
			int num_errors = rule.getTotalErrors();
			if (num_errors <= best_num_errors) {
				best_num_errors = num_errors;
				bestRule = rule;
			}
		}
	}

}