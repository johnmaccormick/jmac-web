/**
 * A class describing an attribute in a machine learning problem: in particular,
 * the name of the attribute and the values it can take
 * 
 * @author John MacCormick
 */
public class Attribute {
	private String name; // The name of the attribute
	private String[] values; // The possible values this attribute can take

	/**
	 * @param name the name of the attribute
	 * @param values the values this attribute can take
	 */
	public Attribute(String name, String[] values) {
		this.name = name;
		this.values = values;
	}

	/**
	 * print a description of the attribute
	 */
	public void print() {
		StringBuilder builder = new StringBuilder();
		builder.append(getName() + ": ");
		for (String value : values)
			builder.append(value + " ");
		System.out.println(builder);
	}

	/**
	 * @return the name of the attribute
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the values this attribute can take
	 */
	public String[] getValues() {
		return values;
	}

}