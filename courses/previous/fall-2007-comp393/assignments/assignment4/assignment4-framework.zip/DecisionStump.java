import java.util.ArrayList;
import java.util.Hashtable;

/**
 * The DecisionStump class implements a 1-level decision tree
 * 
 * @author John MacCormick
 * 
 */
public class DecisionStump extends Classifier {
	// A list of attributes from which this decision stump is permitted to
	// choose (it will choose to split the data on the attribute that results in
	// the lowest expected entropy).
	private ArrayList<Attribute> availableAttributes;

	// The best attribute to split on, and its associated rule
	private Attribute bestAttribute;
	private SingleAttributeRule bestRule;

	/**
	 * @param attributeSet
	 *            the set of attributes used by the machine learning problem
	 *            which this decision stump will tackle
	 */
	public DecisionStump(AttributeSet attributeSet) {
		this(attributeSet, attributeSet.getAttributes());
	}

	/**
	 * @param attributeSet
	 *            the set of attributes used by the machine learning problem
	 *            which this decision stump will tackle
	 * @param availableAttributes
	 *            A list of attributes from which this decision stump is
	 *            permitted to choose (it will choose to split the data on the
	 *            attribute that results in the lowest expected entropy).
	 */
	@SuppressWarnings("unchecked")
	public DecisionStump(AttributeSet attributeSet,
			ArrayList<Attribute> availableAttributes) {
		super(attributeSet);
		this.availableAttributes = (ArrayList<Attribute>) availableAttributes
				.clone();
		removeClassAttribute();
	}

	public void learn(InstanceSet trainingSet) {
		this.attributeSet = trainingSet.getAttributeSet();
		computeBestAttribute(trainingSet);
	}

	// The decision stump makes a decision by applying the best rule it
	// found
	public String decide(Instance instance) {
		String bestAttributeValue = instance.getValues()[bestRule
				.getAttributeIndex()];
		String decision;
		if (bestAttributeValue.equals(Classifier.missingData))
			decision = Classifier.unknownClass;
		else
			decision = bestRule.getDecisions().get(bestAttributeValue);
		return decision;
	}

	// Class probabilities are computed by simply looking at the distribution of
	// machine learning classes over those instances in the training
	// set whose "best" attribute agrees with the given instance
	public Hashtable<String, Double> computeClassProbabilities(Instance instance) {
		String bestAttributeValue = instance.getValues()[bestRule
				.getAttributeIndex()];
		return bestRule.computeClassProbabilities(bestAttributeValue);
	}

	public void print() {
		System.out.println("Best attribute is "
				+ bestRule.getAttribute().getName() + ", error rate "
				+ bestRule.getTotalErrors() + "/"
				+ bestRule.getTrainingSetSize());
	}

	// return the entropy that results from splitting the given
	// training set according to the given attribute
	private double computeSplitEntropy(InstanceSet trainingSet,
			Attribute attribute) {
		SingleAttributeRule rule = new SingleAttributeRule(trainingSet,
				attribute);
		int num_instances = trainingSet.getInstances().size();
		double split_entropy = 0.0;

		assert num_instances > 0;

		for (String value : attribute.getValues()) {
			Distribution distribution = rule.getFrequencies().get(value);
			distribution.moveFrequenciesToNormalizedProbabilities();
			double entropy = distribution.getEntropy();
			int num_this_value = distribution.getTotalFrequencies();
			split_entropy += (double) num_this_value / num_instances * entropy;
		}
		return split_entropy;
	}

	// Find the attribute that results in lowest entropy
	private void computeBestAttribute(InstanceSet trainingSet) {
		double best_entropy = Double.MAX_VALUE;
		for (Attribute attribute : availableAttributes) {
			double entropy = computeSplitEntropy(trainingSet, attribute);
			System.out.println("splitting on attribute " + attribute.getName()
					+ " resulted in entropy " + entropy);
			if (entropy <= best_entropy) {
				best_entropy = entropy;
				bestAttribute = attribute;
			}
		}
		System.out.println("  -- selected attribute " + bestAttribute.getName());
		bestRule = new SingleAttributeRule(trainingSet, bestAttribute);
	}

	/**
	 * @return the list of attributes from which this decision stump is
	 *         permitted to choose (it will choose to split the data on the
	 *         attribute that results in the lowest expected entropy)
	 */
	public ArrayList<Attribute> getAvailableAttributes() {
		return availableAttributes;
	}

	private void removeClassAttribute() {
		for (int i = 0; i < availableAttributes.size(); i++) {
			Attribute attribute = availableAttributes.get(i);
			if (attribute.getName().equals(
					this.attributeSet.getClassAttributeAsString())) {
				availableAttributes.remove(i);
				break;
			}
		}
	}

	/**
	 * @return the bestAttribute
	 */
	public Attribute getBestAttribute() {
		return bestAttribute;
	}

	public int getNumErrors() {
		return bestRule.getTotalErrors();
	}
}