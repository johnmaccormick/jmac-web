import java.util.Hashtable;
import java.lang.Math;

/**
 * For a given attribute, a Distribution object stores information about a
 * probability distribution over the possible attribute values in two different
 * ways: (i) frequencies -- how many times each attribute value was observed,
 * and (ii) probabilities -- the probability that this attribute has each of the
 * possible attribute values. Convenient methods are provided for translating
 * frequencies into probabilities, and for normalizing the probabilities so that
 * they add to one.
 * 
 * @author jmac
 * 
 */
class Distribution {
	// Key is the attribute value, value is the
	// number of instances for which this attribute value was
	// observed
	private Hashtable<String, Integer> frequencies = new Hashtable<String, Integer>();

	// Key is the name of the attribute value, value is the
	// (possibly unnormalized) probability of this attribute value
	private Hashtable<String, Double> probabilities = new Hashtable<String, Double>();

	/**
	 * Create a distribution on the values of a particular attribute
	 * 
	 * @param attribute
	 *            the attribute whose distribution this object records
	 */
	public Distribution(Attribute attribute) {
		// Initialize frequency and probability of every attribute value to 0
		for (String value : attribute.getValues()) {
			frequencies.put(value, 0);
			probabilities.put(value, 0.0);
		}
	}

	/**
	 * Initialize all frequencies to 1. This is useful for certain classifiers
	 * that require a "Laplace prior", which is a fancy way of saying that all
	 * frequencies are initialized to 1.
	 */
	public void installLaplacePrior() {
		// Initialize frequencies to 1
		for (String key : frequencies.keySet()) {
			frequencies.put(key, 1);
		}
	}

	/**
	 * @param attributeValue
	 *            the attribute value whose frequency will be incremented by 1
	 */
	public void incrementFrequency(String attributeValue) {
		int new_value = frequencies.get(attributeValue) + 1;
		frequencies.put(attributeValue, new_value);
	}

	/**
	 * @return the name of the most frequent attribute value
	 */
	public String getNameOfMaxFrequency() {
		int max = 0;
		String max_name = null;
		for (String attributeValue : frequencies.keySet()) {
			int frequency = frequencies.get(attributeValue);
			if (frequency >= max) {
				max = frequency;
				max_name = attributeValue;
			}
		}
		return max_name;
	}

	/**
	 * @return the frequency of the most frequent attribute value
	 */
	public int getValueOfMaxFrequency() {
		return frequencies.get(getNameOfMaxFrequency());
	}

	/**
	 * @return the name of the most probable attribute value
	 */
	public String getNameOfMaxProbability() {
		double max = 0.0;
		String max_name = null;
		for (String attributeValue : probabilities.keySet()) {
			double probability = probabilities.get(attributeValue);
			// System.out.println(attributeValue + ": " + probability);
			if (probability >= max) {
				max = probability;
				max_name = attributeValue;
			}
		}
		// System.out.println();
		assert max_name != null;
		return max_name;
	}

	/**
	 * @return the probability of the most probable attribute value
	 */
	public double getValueOfMaxProbability() {
		return probabilities.get(getNameOfMaxProbability());
	}

	/**
	 * @return the total of all frequencies in this distribution (i.e. the total
	 *         number of instances observed)
	 */
	public int getTotalFrequencies() {
		int total = 0;
		for (String attributeValue : frequencies.keySet()) {
			int frequency = frequencies.get(attributeValue);
			total += frequency;
		}
		return total;
	}

	/**
	 * @return the entropy of the probability distribution, assuming it is
	 *         already normalized.
	 */
	public double getEntropy() {
		double entropy = 0.0;
		for (double probability : probabilities.values()) {
			double this_term;
			if (probability == 0.0)
				this_term = 0.0;
			else
				this_term = -probability * Math.log(probability) / Math.log(2);

			entropy += this_term;
		}
		return entropy;
	}

	/**
	 * normalize the probability distribution so that it sums to 1.0
	 */
	public void normalizeProbabilities() {
		double total_probability = getTotalProbabilities();
		for (String attributeValue : probabilities.keySet()) {
			double probability = probabilities.get(attributeValue)
					/ total_probability;
			probabilities.put(attributeValue, probability);
		}
	}

	/**
	 * take the observed frequencies and create normalized probabilities from
	 * them, which can later be obtained using getProbabilities()
	 */
	public void moveFrequenciesToNormalizedProbabilities() {
		int total_frequency = getTotalFrequencies();
		if (total_frequency == 0)
			return;
		for (String attributeValue : probabilities.keySet()) {
			double probability = (double) frequencies.get(attributeValue)
					/ total_frequency;
			probabilities.put(attributeValue, probability);
		}

	}

	/**
	 * print out the table of observed frequencies
	 */
	public void printFrequencies() {
		for (String attributeValue : frequencies.keySet()) {
			System.out.print(" " + attributeValue + ": "
					+ frequencies.get(attributeValue));
		}
		System.out.println();
	}

	/**
	 * print out the table of probabilities
	 */
	public void printProbabilities() {
		for (String attributeValue : probabilities.keySet()) {
			System.out.print(" " + attributeValue + ": "
					+ probabilities.get(attributeValue));
		}
		System.out.println();
	}

	// compute the sum of all probabilities, to help with normalization
	private double getTotalProbabilities() {
		double total = 0.0;
		for (String attributeValue : probabilities.keySet()) {
			double probability = probabilities.get(attributeValue);
			total += probability;
		}
		return total;
	}

	/**
	 * @return the probabilities
	 */
	public Hashtable<String, Double> getProbabilities() {
		return probabilities;
	}

}