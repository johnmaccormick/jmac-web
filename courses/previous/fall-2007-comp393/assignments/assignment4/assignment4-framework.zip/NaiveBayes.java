import java.util.Hashtable;

/**
 * The NaiveBayes class implements the naive Bayes classification algorithm
 * (i.e. computes posterior probabilities by assuming that attribute values are
 * conditionally independent given the class value)
 * 
 * @author jmac
 * 
 */
public class NaiveBayes extends Classifier {
	// the prior probability distribution over the possible machine
	// learning classes i.e. proportion of each machine learning
	// class in the training set
	private Distribution prior;

	// key is a string of the form "A|B", where A is the name of an
	// attribute, and B is one of the machine learning classes; value
	// is a probability distribution of the possible values of A --
	// this is known as the "likelihood" of A|B
	private Hashtable<String, Distribution> likelihoods;

	/**
	 * @param attributeSet
	 *            the attribute set to be used for this machine learning problem
	 */
	public NaiveBayes(AttributeSet attributeSet) {
		super(attributeSet);
	}

	public void learn(InstanceSet trainingSet) {
		this.attributeSet = trainingSet.getAttributeSet();
		buildPrior(trainingSet);
		buildLikelihoods(trainingSet);
	}

	// Decision just returns the class with highest posterior
	// probability
	public String decide(Instance instance) {
		Distribution posterior = calculatePosterior(instance);
		String bestAttributeValue = posterior.getNameOfMaxProbability();
		return bestAttributeValue;
	}

	// Class probabilities are just the posterior probabilities
	// computed using the naive Bayes independence assumption
	public Hashtable<String, Double> computeClassProbabilities(Instance instance) {
		Distribution posterior = calculatePosterior(instance);
		return posterior.getProbabilities();
	}

	public void print() {
		System.out.print("prior: ");
		prior.printProbabilities();
		System.out.print("likelihoods: ");
		printLikelihoods();
	}

	private void buildPrior(InstanceSet trainingSet) {
		prior = new Distribution(attributeSet.getClassAttribute());
		prior.installLaplacePrior();
		int classAttributeIndex = attributeSet.getClassAttributeIndex();
		for (Instance instance : trainingSet.getInstances()) {
			String mlClass = instance.getValues()[classAttributeIndex];
			prior.incrementFrequency(mlClass);
		}
		prior.moveFrequenciesToNormalizedProbabilities();
	}

	private void buildLikelihoods(InstanceSet trainingSet) {
		int classAttributeIndex = attributeSet.getClassAttributeIndex();
		Attribute classAttribute = attributeSet.getAttributes().get(
				classAttributeIndex);
		likelihoods = new Hashtable<String, Distribution>();

		// Create empty distributions for all likelihoods
		for (Attribute attribute : attributeSet.getAttributes()) {
			for (String mlClass : classAttribute.getValues()) {
				String key = makeLikelihoodKey(attribute.getName(), mlClass);
				Distribution distribution = new Distribution(attribute);
				distribution.installLaplacePrior();
				likelihoods.put(key, distribution);
			}
		}

		// Loop through all training instances, incrementing relevant
		// frequencies
		for (Instance instance : trainingSet.getInstances()) {
			for (Attribute attribute : attributeSet.getAttributes()) {
				int attributeIndex = attributeSet.getAttributeIndex(attribute
						.getName());
				String mlClass = instance.getValues()[classAttributeIndex];
				String key = makeLikelihoodKey(attribute.getName(), mlClass);
				Distribution distribution = likelihoods.get(key);
				String instanceValue = instance.getValues()[attributeIndex];
				// ignore missing values
				if (!instanceValue.equals(Classifier.missingData)) {
					distribution
							.incrementFrequency(instance.getValues()[attributeIndex]);
				}
			}
		}

		// Normalize all distributions
		for (Attribute attribute : attributeSet.getAttributes()) {
			for (String mlClass : classAttribute.getValues()) {
				String key = makeLikelihoodKey(attribute.getName(), mlClass);
				Distribution distribution = likelihoods.get(key);
				distribution.moveFrequenciesToNormalizedProbabilities();
			}
		}
	}

	// Return the posterior probability distribution over the possible
	// machine learning classes, for this instance
	private Distribution calculatePosterior(Instance instance) {
		int classAttributeIndex = attributeSet.getClassAttributeIndex();
		Attribute classAttribute = attributeSet.getAttributes().get(
				classAttributeIndex);
		Distribution posterior = new Distribution(classAttribute);
		// Loop over the possible values of the machine learning class,
		// computing unnormalized posterior values
		// i.e. product of likelihoods multiplied by prior
		for (String mlClass : classAttribute.getValues()) {
			// First, compute the product of the likelihood for each attribute
			// (except for the machine learning class attribute)
			double product = 1.0;
			for (Attribute attribute : attributeSet.getAttributes()) {
				// Don't include the likelihood of the machine learning class
				// attribute
				if (attribute.getName().equals(
						attributeSet.getClassAttributeAsString())) {
					continue;
				}
				String key = makeLikelihoodKey(attribute.getName(), mlClass);
				Distribution likelihood = likelihoods.get(key);
				int attributeIndex = attributeSet.getAttributeIndex(attribute
						.getName());
				String attributeValue = instance.getValues()[attributeIndex];
				// ignore missing values
				if (!attributeValue.equals(Classifier.missingData))
					product *= likelihood.getProbabilities()
							.get(attributeValue);
			}
			// Second, multiply by the prior
			product *= prior.getProbabilities().get(mlClass);
			// Third, store the result
			posterior.getProbabilities().put(mlClass, product);
		}
		// normalize the posterior and return it
		posterior.normalizeProbabilities();
		return posterior;
	}

	private String makeLikelihoodKey(String attributeName, String mlClass) {
		return attributeName + "|" + mlClass;
	}

	private void printLikelihoods() {
		int classAttributeIndex = attributeSet.getClassAttributeIndex();
		Attribute classAttribute = attributeSet.getAttributes().get(
				classAttributeIndex);
		// Loop over the possible values of the machine learning class
		for (String mlClass : classAttribute.getValues()) {
			// Loop over attributes
			// (except for the machine learning class attribute)
			for (Attribute attribute : attributeSet.getAttributes()) {
				// Don't include the likelihood of the machine learning class
				// attribute
				if (attribute.getName().equals(
						attributeSet.getClassAttributeAsString())) {
					continue;
				}
				String key = makeLikelihoodKey(attribute.getName(), mlClass);
				Distribution likelihood = likelihoods.get(key);
				System.out.print("likelihood for " + key + ": ");
				likelihood.printProbabilities();
			}
		}
	}
}