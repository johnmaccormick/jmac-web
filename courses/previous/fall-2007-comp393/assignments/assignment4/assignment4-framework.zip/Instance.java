/**
 * An Instance object represents a single instance in a training or test set
 * 
 * @author John MacCormick
 * 
 */
class Instance {
	// An array of the attribute values for this instance.
	// Note that the order of elements in this array is determined by
	// the ordering of the attributes in the AttributeSet being used
	// for this machine learning problem.
	private String[] values;

	/**
	 * @param values
	 *            an array of strings naming the values this instance takes. The
	 *            ordering of this array is the same as the AttributeSet being
	 *            used for the current machine learning problem.
	 */
	public Instance(String[] values) {
		this.values = values;
	}

	/**
	 * print the instance in a legible format
	 */
	public void print() {
		StringBuilder builder = new StringBuilder();
		for (String value : values)
			builder.append(value + ", ");
		// remove the final ", "
		builder.delete(builder.length() - 2, builder.length());
		System.out.println(builder);
	}

	/**
	 * @return true if this instance contains any missing values
	 */
	public boolean containsMissingValue() {
		boolean missing = false;
		for (String value : values) {
			if (value.equals(Classifier.missingData))
				missing = true;
		}
		return missing;
	}

	/**
	 * @return the values
	 */
	public String[] getValues() {
		return values;
	}
}