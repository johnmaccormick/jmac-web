import java.util.Hashtable;

/**
 * A SingleAttributeRule is a decision rule that can be considered for use by
 * the 1R classification algorithm: a rule based on the frequencies observed
 * when restricting attention to a single attribute.
 * 
 * @author John MacCormick
 * 
 */
class SingleAttributeRule {
	// the attribute and associated index (in this.attributeSet) for
	// which this rule is built
	private Attribute attribute;
	private int attributeIndex;

	// Some fields describing the training set which it's convenient to keep
	// a local copy of
	private Attribute classAttribute;
	private int classAttributeIndex;
	private AttributeSet attributeSet;
	private int trainingSetSize;

	// Key is attribute value, value is a table of frequencies of each machine
	// learning class observed for instances whose attribute value is the given
	// key
	private Hashtable<String, Distribution> frequencies;

	// Key is attribute value, value is the class assigned to that attribute
	// value by this single attribute rule
	private Hashtable<String, String> decisions;

	// key is attribute value, value is the number of errors made by this rule
	// on the training set
	private Hashtable<String, Integer> numErrors;

	/**
	 * @param trainingSet
	 *            the set of instances in which this rule will be computed
	 * @param attribute
	 *            the attribute for which this rule will be computed
	 */
	public SingleAttributeRule(InstanceSet trainingSet, Attribute attribute) {
		this.attributeSet = trainingSet.getAttributeSet();
		this.attribute = attribute;
		this.attributeIndex = attributeSet.getAttributeIndex(attribute);
		this.classAttribute = attributeSet.getAttribute(attributeSet
				.getClassAttributeAsString());
		this.classAttributeIndex = attributeSet
				.getAttributeIndex(classAttribute);
		this.trainingSetSize = trainingSet.getInstances().size();

		buildFrequencies(trainingSet);
		computeDecisionsAndErrors();
	}

	private void buildFrequencies(InstanceSet trainingSet) {
		// create the empty frequencies Hashtable
		frequencies = new Hashtable<String, Distribution>();
		for (String value : attribute.getValues()) {
			frequencies.put(value, new Distribution(classAttribute));
		}

		// Loop over all instances, incrementing the relevant frequency
		for (Instance instance : trainingSet.getInstances()) {
			String mlClass = instance.getValues()[classAttributeIndex];
			String this_attribute_value = instance.getValues()[attributeIndex];
			// ignore missing data, otherwise increment frequency
			if (!this_attribute_value.equals(Classifier.missingData)) {
				Distribution table_to_modify = frequencies
						.get(this_attribute_value);
				table_to_modify.incrementFrequency(mlClass);
			}
		}
	}

	private void computeDecisionsAndErrors() {
		decisions = new Hashtable<String, String>();
		numErrors = new Hashtable<String, Integer>();
		for (String value : attribute.getValues()) {
			// Compute decision as most frequent machine learning
			// class for this value
			Distribution classFrequencies = frequencies.get(value);
			String decision = classFrequencies.getNameOfMaxFrequency();
			decisions.put(value, decision);

			// Compute number of errors as total frequency less
			// the number classified correctly
			int total = classFrequencies.getTotalFrequencies();
			int num_correct = classFrequencies.getValueOfMaxFrequency();
			int num_errors = total - num_correct;
			numErrors.put(value, num_errors);
		}
	}

	/**
	 * @return the total number of errors made on all instances in the training
	 *         set
	 */
	public int getTotalErrors() {
		int total = 0;
		for (String value : attribute.getValues())
			total += numErrors.get(value);
		return total;
	}

	/**
	 * Compute the machine learning class probabilities for the given attribute
	 * value
	 * 
	 * @param attributeValue
	 *            the attribute value for which probabilities are computed
	 * @return a table mapping machine learning classes (as strings) to their
	 *         probabilities (as doubles)
	 */
	public Hashtable<String, Double> computeClassProbabilities(
			String attributeValue) {
		// return null if the attribute value represents missing data
		if (attributeValue.equals(Classifier.missingData))
			return null;

		// We just need to return a copy of the relevant Distribution,
		// with probabilities updated to reflect the frequencies
		Distribution class_distribution = frequencies.get(attributeValue);
		class_distribution.moveFrequenciesToNormalizedProbabilities();
		return class_distribution.getProbabilities();
	}

	/**
	 * print a legible version of the single attribute rule
	 */
	public void print() {
		System.out.println("frequencies, decisions, and errors for attribute "
				+ attribute.getName() + ":");
		for (String value : attribute.getValues()) {
			System.out.print("  " + value + ": ");
			frequencies.get(value).printFrequencies();
			System.out.println("    decision: " + decisions.get(value));
			System.out.println("    errors: " + numErrors.get(value));
		}
		System.out.println("  Total errors: " + getTotalErrors());
	}

	/**
	 * @return the training set size for which this rule was computed
	 */
	public int getTrainingSetSize() {
		return trainingSetSize;
	}

	/**
	 * @return the attribute for which this rule was computed
	 */
	public Attribute getAttribute() {
		return attribute;
	}

	/**
	 * @return the index of this rule's attribute in the AttributeSet's array of
	 *         attributes
	 */
	public int getAttributeIndex() {
		return attributeIndex;
	}

	/**
	 * @return the frequencies
	 */
	public Hashtable<String, Distribution> getFrequencies() {
		return frequencies;
	}

	/**
	 * @return the decisions
	 */
	public Hashtable<String, String> getDecisions() {
		return decisions;
	}

}