import java.util.ArrayList;
import java.util.Hashtable;

/**
 * AttributeSet encapsulates the set of attributes for a given machine learning
 * problem.
 * 
 * @author John MacCormick
 * 
 */
public class AttributeSet {
	// A list of the attributes in this AttributeSet
	private ArrayList<Attribute> attributes;

	// Key is attribute name, value is the index of this attribute in
	// the ArrayList this.attributes
	private Hashtable<String, Integer> attributeIndices;

	// The name of the attribute that determines the machine learning
	// class of an instance
	private String classAttribute;

	// Index of the classAttribute in the ArrayList this.attributes
	private int classAttributeIndex;

	public AttributeSet() {
		attributes = new ArrayList<Attribute>();
		attributeIndices = new Hashtable<String, Integer>();
	}

	/**
	 * @param attribute
	 *            the attribute to be added to this attribute set
	 */
	public void addAttribute(Attribute attribute) {
		attributes.add(attribute);
		attributeIndices.put(attribute.getName(), attributes.size() - 1);
	}

	/**
	 * @param name
	 *            a string naming the machine learning class attribute
	 */
	public void setClassAttribute(String name) {
		classAttribute = name;
		classAttributeIndex = getAttributeIndex(classAttribute);
	}

	/**
	 * @param attribute
	 *            the attribute whose index is desired
	 * @return the attribute's index in this class's array list
	 */
	public int getAttributeIndex(Attribute attribute) {
		return attributeIndices.get(attribute.getName());
	}

	/**
	 * @param name
	 *            the name of the attribute whose index is desired
	 * @return the attribute's index in this class's array list
	 */
	public int getAttributeIndex(String name) {
		return attributeIndices.get(name);
	}

	/**
	 * @param name
	 *            the name of the desired attribute
	 * @return the attribute corresponding to the given name
	 */
	public Attribute getAttribute(String name) {
		return attributes.get(getAttributeIndex(name));
	}

	/**
	 * @return the machine learning class attribute for this attribute set
	 */
	public Attribute getClassAttribute() {
		return attributes.get(classAttributeIndex);
	}

	/**
	 * @return the name of the machine learning class attribute for this
	 *         attribute set
	 */
	public String getClassAttributeAsString() {
		return classAttribute;
	}

	/**
	 * the machine learning class attribute is the final attribute, by default.
	 * This method is used to set this default.
	 */
	public void setDefaultClassAttribute() {
		setClassAttribute(attributes.get(attributes.size() - 1).getName());
	}

	/**
	 * print legible version of the attribute set
	 */
	public void print() {
		for (Attribute attribute : attributes)
			attribute.print();
		System.out.println("Class attribute is " + classAttribute);
	}

	/**
	 * @return the attributes in the attribute set
	 */
	public ArrayList<Attribute> getAttributes() {
		return attributes;
	}

	/**
	 * @return the index of the machine learning class in this attribute set's
	 *         array of attributes, obtained via getAttributes()
	 */
	public int getClassAttributeIndex() {
		return classAttributeIndex;
	}

}