import java.util.Hashtable;

// For a given attribute, a Distribution object stores information
// about a probability distribution over the possible attribute values
// in two different ways: (i) frequencies -- how many times each
// attribute value was observed, and (ii) probabilities -- the
// probability that this attribute has each of the possible attribute
// values.  Convenient methods are provided for translating
// frequencies into probabilities, and for normalizing the
// probabilities so that they add to one.
class Distribution {
    // Key is the attribute value, value is the
    // number of instances for which this attribute value was
    // observed
    public Hashtable<String, Integer> frequencies = new Hashtable<String, Integer>();

    // Key is the name of the attribute value, value is the
    // (possibly unnormalized) probability of this attribute value
    public Hashtable<String, Double> probabilities = new Hashtable<String, Double>();

    Distribution(Attribute attribute) {
        // Initialize frequency  and probability of every attribute value to 0
        for(String value: attribute.values ) {
            frequencies.put(value, 0);
            probabilities.put(value, 0.0);
        }
    }

    void incrementFrequency(String attributeValue) {
        int new_value = frequencies.get(attributeValue) + 1;
        frequencies.put(attributeValue, new_value);
    }

    String getNameOfMaxFrequency() {
        int max = 0;
        String max_name = null;
        for(String attributeValue: frequencies.keySet()) {
            int frequency = frequencies.get(attributeValue);
            if (frequency >= max) {
                max = frequency;
                max_name = attributeValue;
            }
        }
        return max_name;
    }

    int getValueOfMaxFrequency() {
        return frequencies.get(getNameOfMaxFrequency());
    }

    String getNameOfMaxProbability() {
        double max = 0.0;
        String max_name = null;
        for(String attributeValue: probabilities.keySet()) {
            double probability = probabilities.get(attributeValue);
            if (probability >= max) {
                max = probability;
                max_name = attributeValue;
            }
        }
        return max_name;
    }

    double getValueOfMaxProbability() {
        return probabilities.get(getNameOfMaxProbability());
    }

    int getTotalFrequencies() {
        int total = 0;
        for(String attributeValue: frequencies.keySet()) {
            int frequency = frequencies.get(attributeValue);
            total += frequency;
        }  
        return total;
    }

    double getTotalProbabilities() {
        double total = 0.0;
        for(String attributeValue: probabilities.keySet()) {
            double probability = probabilities.get(attributeValue);
            total += probability;
        }  
        return total;
    }

    void normalizeProbabilities() {
        double total_probability = getTotalProbabilities();
        for(String attributeValue: probabilities.keySet()) {
            double probability = probabilities.get(attributeValue) / total_probability;
            probabilities.put(attributeValue, probability);
        }
    }

    void moveFrequenciesToNormalizedProbabilities() {
        for(String attributeValue: probabilities.keySet()) {
            int total_frequency = getTotalFrequencies();
            double probability = (double) frequencies.get(attributeValue) / total_frequency;
            probabilities.put(attributeValue, probability);
        }
         
    }

    void printFrequencies() {
        for(String attributeValue: frequencies.keySet()) {
            System.out.print(" " + attributeValue + ": " + frequencies.get(attributeValue));
        }
        System.out.println();
    }

    void printProbabilities() {
        for(String attributeValue: probabilities.keySet()) {
            System.out.print(" " + attributeValue + ": " + probabilities.get(attributeValue));
        }
        System.out.println();
    }

}