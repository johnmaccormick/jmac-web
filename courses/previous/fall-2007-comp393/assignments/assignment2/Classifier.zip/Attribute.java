class Attribute {
    String name;     // The name of the attribute
    String[] values; // The possible values this attribute can take

    public Attribute(String name, String[] values) {
        this.name = name;
        this.values = values;
    }

    public void print() {
        StringBuilder builder = new StringBuilder();
        builder.append(name + ": ");
        for(String value: values)
            builder.append(value + " ");
        System.out.println(builder);
    }
}