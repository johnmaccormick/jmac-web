import java.util.ArrayList;
import java.util.Hashtable;

// A SingleAttributeRule is a decision rule that can be considered for
// use by the 1R classification algorithm: a rule based on the
// frequencies observed when restricting attention to a single
// attribute.
class SingleAttributeRule {
    // the attribute and associated index (in this.attributeSet) for
    // which this rule is built
    Attribute attribute;
    int attributeIndex;

    // Some fields describing the training set which it's convenient to keep
    // a local copy of
    Attribute classAttribute;
    int classAttributeIndex;
    AttributeSet attributeSet;
    int trainingSetSize;

    // Key is attribute value, value is a table of frequencies of each
    // machine learning class observed for instances whose attribute
    // value is the given key
    public Hashtable<String, Distribution> frequencies;

    // Key is attribute value, value is the class assigned to that
    // attribute value by this single attribute rule
    public Hashtable<String, String> decisions;

    // key is attribute value, value is the number of errors made by
    // this rule on the training set
    public Hashtable<String, Integer> numErrors;

    SingleAttributeRule(InstanceSet trainingSet, Attribute attribute) {
        this.attributeSet = trainingSet.attributeSet;
        this.attribute = attribute;
        this.attributeIndex = attributeSet.getAttributeIndex(attribute);
        this.classAttribute = attributeSet.getAttribute(attributeSet.classAttribute);
        this.classAttributeIndex = attributeSet.getAttributeIndex(classAttribute);
        this.trainingSetSize = trainingSet.instances.size();

        buildFrequencies(trainingSet);
        computeDecisionsAndErrors();
    }

    private void buildFrequencies(InstanceSet trainingSet) {
        // create the empty frequencies Hashtable
        frequencies = new Hashtable<String, Distribution>();
        for(String value: attribute.values ) {
            frequencies.put( value, new Distribution(classAttribute));
        }

        // Loop over all instances, incrementing the relevant frequency
        for( Instance instance: trainingSet.instances ) {
            String mlClass = instance.values[classAttributeIndex];
            String this_attribute_value = instance.values[attributeIndex];
            Distribution table_to_modify = frequencies.get(this_attribute_value);
            table_to_modify.incrementFrequency(mlClass);
        }
    }

    private void computeDecisionsAndErrors() {
        decisions = new Hashtable<String, String>();
        numErrors = new Hashtable<String, Integer>();
        for(String value: attribute.values) {
            // Compute decision as most frequent machine learning
            // class for this value
            Distribution classFrequencies = frequencies.get(value);
            String decision = classFrequencies.getNameOfMaxFrequency();
            decisions.put(value, decision);

            // Compute number of errors as total frequency less
            // the number classified correctly
            int total = classFrequencies.getTotalFrequencies();
            int num_correct = classFrequencies.getValueOfMaxFrequency();
            int num_errors = total - num_correct;
            numErrors.put(value, num_errors);
        }        
    }

    //  return the total number of errors made on all instances in the
    //  training set
    int getTotalErrors() {
        int total = 0;
        for(String value: attribute.values) 
            total += numErrors.get(value);
        return total;
    }

    Hashtable<String, Double> computeClassProbabilities(String attributeValue) {
        // We just need to return a copy of the relevant Distribution, 
        // with probabilities updated to reflect the frequencies
        Distribution class_distribution = frequencies.get(attributeValue);
        class_distribution.moveFrequenciesToNormalizedProbabilities();
        return class_distribution.probabilities;
    }


    void print() {
        System.out.println("frequencies, decisions, and errors for attribute " + attribute.name + ":");
        for(String value: attribute.values ) {
            System.out.print("  " + value + ": ");
            frequencies.get(value).printFrequencies();
            System.out.println("    decision: " + decisions.get(value));
            System.out.println("    errors: " + numErrors.get(value));
        }
        System.out.println("  Total errors: " + getTotalErrors());
    }
    
}