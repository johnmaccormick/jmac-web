import java.util.Hashtable;

// The Classifier class represents an algorithm for classifying the
// instances of a particular machine learning problem.  Classifier is
// an abstract class, so actual classification algorithms are
// implemented by extending this class and implementing the abstract
// methods.
public abstract class Classifier {
    // The set of attributes used by a particular machine learning problem.
    AttributeSet attributeSet;

    // Learn a classifier from the given training set
    abstract void learn(InstanceSet trainingSet) throws Exception;

    // return the class value of an instance
    abstract String decide(Instance instance) throws Exception ;

    // return a table mapping class values to their probabilities
    abstract Hashtable<String, Double> computeClassProbabilities(Instance instance) throws Exception ;

    abstract void print() throws Exception;

    public Classifier(AttributeSet attributeSet) {
        this.attributeSet = attributeSet;
    }

    // Return the error rate, expressed as a number between 0 and 1,
    // of this classifier on the given test set
    public double computeErrorRate(InstanceSet testSet) throws Exception {
        int num_errors = 0;
        for( Instance instance: testSet.instances ) {
            String decision = decide(instance);
            String mlClass = instance.values[attributeSet.classAttributeIndex];
            if (!decision.equals(mlClass))
                num_errors++;
        }
        return (double) num_errors / testSet.instances.size();
    }

    // Print out the decision (i.e. which class does the classifier
    // believe this instance belongs to) and class probabilities for
    // each instance in the given test set
    public void printDecisionsAndProbabilities(InstanceSet testSet) throws Exception {
        for( Instance instance: testSet.instances ) {
            String decision = decide(instance);
            Hashtable<String, Double> probabilities = 
                computeClassProbabilities(instance);
            System.out.print("instance: ");
            instance.print();
            System.out.println("decision: " + decision);
            System.out.print("class probabilities: ");
            for(String value: probabilities.keySet()) {
                System.out.print( value + ":" + probabilities.get(value)  + " ");
            }
            System.out.println();
        }
    }

    // Run a user-selected algorithm on a user-selected data file
    public static void main(String[] arguments)
    {
        try {
            if(arguments.length != 2) {
                throw new Exception("usage: java Classifier OneR|Bayes datafilename");
            }
            String algorithmName = arguments[0];
            String inputFilename = arguments[1];
            InstanceSet trainingSet = new InstanceSet(inputFilename);
            Classifier classifier;
            if( algorithmName.equals("OneR") )
                classifier = new OneRClassifier(trainingSet.attributeSet);
            else if( algorithmName.equals("Bayes") )
                classifier = new NaiveBayes(trainingSet.attributeSet);
            else
                throw new Exception("Unknown algorithm" + algorithmName);

            classifier.learn(trainingSet);
            classifier.print();
            double error_rate = classifier.computeErrorRate(trainingSet);
            System.out.println("Error rate on training set: " + error_rate);
            System.out.println();
            classifier.printDecisionsAndProbabilities(trainingSet);
        }
        catch(Exception exception) {
            exception.printStackTrace();
        }
    }

}

