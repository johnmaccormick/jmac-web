import java.util.Hashtable;
import java.util.ArrayList;

// The OneRClassifier class implements the 1R classification algorithm
public class OneRClassifier extends Classifier {
    // A list of the possible rules considered by the classifier --
    // one for each attribute
    ArrayList<SingleAttributeRule> rules;

    // The single best rule found
    SingleAttributeRule bestRule;

    public OneRClassifier(AttributeSet attributeSet) {
        super(attributeSet);
    }

    void learn(InstanceSet trainingSet) {
        this.attributeSet = trainingSet.attributeSet;
        makeRules(trainingSet);
        computeBestAttribute();
    }

    // The 1R algorithm makes a decision by applying the best rule it
    // found
    String decide(Instance instance) {
        String bestAttributeValue = instance.values[bestRule.attributeIndex];
        return bestRule.decisions.get(bestAttributeValue);
    }

    // Class probabilities for the 1R algorithm are rather inaccurate,
    // but we compute them by simply looking at the distribution of
    // machine learning classes over those instances in the training
    // set whose "best" attribute agrees with the given instance
    Hashtable<String, Double> computeClassProbabilities(Instance instance) {
        String bestAttributeValue = instance.values[bestRule.attributeIndex];
        return bestRule.computeClassProbabilities(bestAttributeValue);
    }


    void print() {
        for(SingleAttributeRule rule: rules) {
            rule.print();
        }
        System.out.println("Best attribute is " + bestRule.attribute.name
                            + ", error rate " + bestRule.getTotalErrors() 
                           + "/" + bestRule.trainingSetSize);
    }
    
    private void makeRules(InstanceSet trainingSet) {
        this.rules = new ArrayList<SingleAttributeRule>();
        for(Attribute attribute: trainingSet.attributeSet.attributes) {
            // Don't build a rule for the machine learning class attribute
            if (attribute.name.equals(trainingSet.attributeSet.classAttribute)) {
                continue;
            }
            SingleAttributeRule rule = new SingleAttributeRule(trainingSet, attribute);
            rules.add(rule);
        }
    }

    // Find the rule with the smallest number of errors
    private void computeBestAttribute() {
        int best_num_errors = Integer.MAX_VALUE;
        for(SingleAttributeRule rule: rules) {
            int num_errors = rule.getTotalErrors();
            if (num_errors <= best_num_errors) {
                best_num_errors = num_errors;
                bestRule = rule;
            }
        }
    }


}