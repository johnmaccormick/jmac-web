import java.util.Hashtable;

// The NaiveBayes class implements the naive Bayes classification
// algorithm (i.e. computes posterior probabilities by assuming that
// attribute values are conditionally independent given the class
// value)
public class NaiveBayes extends Classifier {

    // Put some data members in here


    public NaiveBayes(AttributeSet attributeSet) {
        super(attributeSet);
    }

    void learn(InstanceSet trainingSet) throws Exception {
        throw new Exception("not implemented yet");
    }

    String decide(Instance instance) throws Exception {
        throw new Exception("not implemented yet");
    }

    Hashtable<String, Double> computeClassProbabilities(Instance instance) throws Exception {
        throw new Exception("not implemented yet");
    }

    void print() throws Exception {
        throw new Exception("not implemented yet");
    }

    // add private methods below

}