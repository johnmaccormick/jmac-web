import java.util.ArrayList;
import java.util.Hashtable;

// AttributeSet encapsulates the set of attributes for a given machine learning problem.
class AttributeSet {
    // A list of the attributes in this AttributeSet
    ArrayList<Attribute> attributes;

    // Key is attribute name, value is the index of this attribute in
    // the ArrayList this.attributes
    Hashtable<String, Integer> attributeIndices;

    // The name of the attribute that determines the machine learning
    // class of an instance
    String classAttribute;

    // Index of the classAttribute in the ArrayList this.attributes
    int classAttributeIndex;

    public AttributeSet() {
        attributes = new ArrayList<Attribute>();
        attributeIndices = new Hashtable<String, Integer>();
    }

    public void addAttribute(Attribute attribute) {
        attributes.add(attribute);
        attributeIndices.put(attribute.name, attributes.size() - 1);
    }

    void setClassAttribute(String name) {
        classAttribute = name;
        classAttributeIndex = getAttributeIndex(classAttribute);
    }

    int getAttributeIndex(Attribute attribute) {
        return attributeIndices.get(attribute.name);
    }

    int getAttributeIndex(String name) {
        return attributeIndices.get(name);
    }

    Attribute getAttribute(String name) {
        return attributes.get(getAttributeIndex(name));
    }

    Attribute getClassAttribute() {
        return attributes.get(classAttributeIndex);
    }

    // the machine learning class attribute is the final attribute, by
    // default
    void setDefaultClassAttribute() {
        setClassAttribute(attributes.get(attributes.size()-1).name);
    }

    public void print() {
        for(Attribute attribute: attributes)
            attribute.print();
        System.out.println("Class attribute is " + classAttribute);
    }
}