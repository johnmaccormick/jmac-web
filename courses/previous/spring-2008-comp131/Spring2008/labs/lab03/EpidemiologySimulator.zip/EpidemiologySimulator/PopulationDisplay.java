import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.util.*;

/**
 * Write a description of class PopulationDisplay here.
 * 
 * @author Grant Braught 
 * @version July 15, 2005
 */
public class PopulationDisplay extends JFrame implements Observer
{
    private Population pop;
    private PersonDisplay[][] pds;
    private JLabel stepNumber;
    
    public PopulationDisplay(Population pop, String name) {
        this.pop = pop;
        pds = new PersonDisplay[pop.getRows()][pop.getColumns()];
        
        setTitle(name);
        Container c = getContentPane();
        
        Box wholeWindow = Box.createVerticalBox();
        
        Box popBox = Box.createHorizontalBox();
        popBox.add(Box.createGlue());
        JPanel display = new JPanel();
        display.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        display.setLayout(new GridLayout(pop.getRows(), pop.getColumns()));  
        for (int i=0; i<pop.getRows(); i++) {
            for (int j=0; j<pop.getColumns(); j++) {
                pds[i][j] = new PersonDisplay();
                pds[i][j].setState(pop.getPerson(i,j).getState());
                display.add(pds[i][j]);
            }
        }
        popBox.add(display);
        popBox.add(Box.createGlue());
        wholeWindow.add(popBox);
        
        Box stepBox = Box.createHorizontalBox();
        stepBox.add(Box.createGlue());
        stepBox.add(new JLabel("Day: "));
        stepNumber = new JLabel("0");
        stepBox.add(stepNumber);
        stepBox.add(Box.createGlue());
        wholeWindow.add(Box.createVerticalStrut(5));
        wholeWindow.add(stepBox);
        
        wholeWindow.add(Box.createVerticalStrut(5));
        wholeWindow.add(new JSeparator(SwingConstants.HORIZONTAL));
        wholeWindow.add(Box.createVerticalStrut(5));
        
        Box key = Box.createHorizontalBox();
        Box leftKey = Box.createVerticalBox();
        Box rightKey = Box.createVerticalBox();
        
        Box sus = Box.createHorizontalBox();
        PersonDisplay p = new PersonDisplay();
        p.setState(Person.SUSCEPTIBLE);
        sus.add(p);
        sus.add(new JLabel(" Susceptible"));
        sus.add(Box.createGlue());
        leftKey.add(sus);
        
        sus = Box.createHorizontalBox();
        p = new PersonDisplay();
        p.setState(Person.EXPOSED);
        sus.add(p);
        sus.add(new JLabel(" Exposed"));
        sus.add(Box.createGlue());
        leftKey.add(sus);
        
        sus = Box.createHorizontalBox();
        p = new PersonDisplay();
        p.setState(Person.INFECTIOUS);
        sus.add(p);
        sus.add(new JLabel(" Infectious"));
        sus.add(Box.createGlue());
        leftKey.add(sus);

        sus = Box.createHorizontalBox();
        p = new PersonDisplay();
        p.setState(Person.QUARANTINED);
        sus.add(p);
        sus.add(new JLabel(" Quarantined"));
        sus.add(Box.createGlue());
        rightKey.add(sus);
        
        sus = Box.createHorizontalBox();
        p = new PersonDisplay();
        p.setState(Person.REMOVED);
        sus.add(p);
        sus.add(new JLabel(" Recovered"));
        sus.add(Box.createGlue());
        rightKey.add(sus);
        
        rightKey.add(Box.createGlue());
          
        key.add(Box.createHorizontalStrut(10));
        key.add(leftKey);
        key.add(Box.createHorizontalStrut(10));
        key.add(rightKey);
        key.add(Box.createHorizontalStrut(10));
        
        wholeWindow.add(key, BorderLayout.SOUTH);
        c.add(wholeWindow);
        
        setResizable(false);
        //setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.pack();
    }
    
    public void update(Observable o, Object arg) {       
        for (int i=0; i<pop.getRows(); i++) {
            for (int j=0; j<pop.getColumns(); j++) {
                pds[i][j].setState(pop.getPerson(i,j).getState());
            }
        }
        stepNumber.setText(Integer.toString(pop.getDay()));
        
        repaint();
    }
}
