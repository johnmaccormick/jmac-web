import javax.swing.*;
import java.awt.*;
import java.text.*;

/**
 * Write a description of class DataTable here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DataTable extends JFrame
{
    private JTextArea table;
    
    /**
     * Create a new data table.
     */
    public DataTable(String title) {
        setTitle(title);
        Container c = getContentPane();
        table = new JTextArea();
        table.setText("trial\tS\tE\tI\tQ\tR\tEIQR\n");
        table.setFont(new Font("Monospaced", Font.PLAIN, 12));
        table.setEditable(false);
        
        JScrollPane scroller = new JScrollPane(table);
        scroller.setPreferredSize(new Dimension(400,250));
        c.add(scroller);
        
        setResizable(false);
        //setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        pack();   
    }
    
    /**
     * Append a data line to this DataTable. 
     * 
     * @param t the trial number.
     * @param s the % of individuals in the susceptible state.
     * @param e the % of individuals in the exposed state.
     * @param i the % of individuals in the infectious state.
     * @param q the % of individuals in the quarantined state.
     * @param r the % of individuals in the removed state.
     */
    public void append(int t, double s, double e, double i, double q, double r, double eiqr) {
        DecimalFormat df = new DecimalFormat("0.00");
        table.append(t + "\t" + df.format(s) + "\t" + df.format(e) + 
        "\t" + df.format(i) + "\t" + df.format(q) + "\t" + df.format(r) + 
        "\t" + df.format(eiqr) + "\n");
    }
    
    /**
     * Append a summary data line to this DataTable. 
     * 
     * @param type the type of summary information (e.g. Mean, Standard Deviation)
     * @param s the % of individuals in the susceptible state.
     * @param e the % of individuals in the exposed state.
     * @param i the % of individuals in the infectious state.
     * @param q the % of individuals in the quarantined state.
     * @param r the % of individuals in the removed state.
     */    
    public void appendSummary(String type, double s, double e, double i, double q, double r, double eiqr) {
        DecimalFormat df = new DecimalFormat("0.00");
        table.append("\n" + type + "\n");
        table.append("\t" + df.format(s) + "\t" + df.format(e) + 
        "\t" + df.format(i) + "\t" + df.format(q) + "\t" + df.format(r) + 
        "\t" + df.format(eiqr) + "\n");
    }
    
    /**
     * Clear this DataTable.
     */
    public void clear() {
        table.setText("trial\tS\tE\tI\tQ\tR\tEIQR\n");
    }
}
