import java.util.*;

/**
 * The Person class represents an individual in the Population.
 * Each Person can be Susceptible, Exposed, Infectious or Removed
 * according to the SEIR model.  In addition this model allows for
 * a Person to be Quarantined, which prevents them from contacting
 * any other Person.
 * 
 * @author Grant Braught
 * @version July 14, 2005
 */
public class Person implements Cloneable
{
    /*
     * This person's current state. Either SUSCEPTIBLE, EXPOSED,
     * INFECTIOUS, REMOVED or QUAANTINED.
     */
    private int state;
    
    /*
     * Number of ticks that this Person has spent in the 
     * incubation period.
     */
    private int incubationTicks;
    
    /*
     * Number of ticks that this Person has spent in the 
     * latent period.
     */
    private int latentTicks;
    
    /*
     * Number of ticks that this person has spent in the
     * infectious state.
     */
    private int infectiousTicks;
    
    /*
     * Indicates if this person is showing symptoms or not.
     */
    private boolean showingSymptoms;
    
    /**
     * Constant indicating a person in the Susceptible state.
     */
    public static final int SUSCEPTIBLE = 0;
    
    /**
     * Constant indicating a person in the Exposed state.
     */
    public static final int EXPOSED = 1;
    
    /**
     * Constant indicating a person in the Infectious state.
     */    
    public static final int INFECTIOUS = 2;
    
    /**
     * Constant indicating a person in the Removed state.
     */    
    public static final int REMOVED = 3;
    
    /**
     * Constant indicating a person who has been Quarantined.
     */
    public static final int QUARANTINED = 4;
    
   /**
    * Construct a new Person that is in the SUSCEPTIBLE state.
    */
    public Person() {
        state = SUSCEPTIBLE;
        incubationTicks = 0;
        latentTicks = 0;
        infectiousTicks = 0;
        showingSymptoms = false;
    }
    
    /**
     * Construct a new Person that is in the specified state. The
     * specified state must be one of SUSCEPTIBLE, EXPOSED,
     * INFECTIOUS or REMOVED.
     * 
     * @param state the state for this Person.
     */
    public Person(int state) {
        this();
        this.state = state;
    }
    
    /**
     * Create an exact copy of this Person.
     * 
     * @return an exact copy of this Person.
     */
    public Object clone() {
        try {
            return super.clone();
        }
        catch (CloneNotSupportedException e) {
        }
        
        return null;
    }
    
    /**
     * Determine if this Person is susceptable.
     * 
     * @return true if this Person is susceptable and false otherwise.
     */
    public boolean isSusceptible() {
        return state == SUSCEPTIBLE;
    }
    
    /**
     * Determine if this Person is infectious.
     * 
     * @return true if this Person is infectious and false otherwise.
     */
    public boolean isInfectious() {
        return state == INFECTIOUS;
    }
    
    /**
     * Determine if this Person is exposed.
     * 
     * @return true if this Person is exposed and false otherwise.
     */
    public boolean isExposed() {
        return state == EXPOSED;
    }
    
    /**
     * Determine if this Person is showing symptoms of the Disease.
     * 
     * @return true if this Person is showing symptoms and false otherwise.
     */
    public boolean hasSymptoms() {
        return showingSymptoms;
    }
    
    /**
     * Determine if this Person has been Quarantined.
     * 
     * @return true if this Person is Quarantined and false otherwise.
     */
    public boolean isQuarantined() {
        return state == QUARANTINED;
    }
    
    /**
     * Quarantine this Person.
     */
    public void quarantine() {
        state = QUARANTINED;
    }
    
    /**
     * Get the state of this Person.
     * 
     * @return the state of this Person.
     */
    public int getState() {
        return state;
    }
    
    /**
     * Simulate a single time unit in the lifetime of this Person.
     * 
     * @param hood an ArrayList indicating all of the other people
     * that this person comes into contact with during the current
     * time step. Note that this list is only important when this
     * Person is in the SUSCEPTIBLE state.
     * @param disease the particular Disease that is spreading in the
     * Population.
     */
    public void tick(ArrayList hood, Disease disease) {
       
        if (state == SUSCEPTIBLE) {
            tickSusceptible(hood, disease);
        }
        else if (state == EXPOSED) {
            tickExposed(disease);
        }
        else if (state == INFECTIOUS) {
            tickInfectious(disease);
        }
        else if (state == QUARANTINED) {
            tickQuarantined(disease);
        }
        else if (state == REMOVED) {
            // Nothing to do here!
        }
        
    }
    
    private void tickSusceptible(ArrayList hood, Disease disease) {
        
        Iterator it = hood.iterator();
        while (it.hasNext()) {
            Person p = (Person)it.next();
            
            /*
             * If the neighbor is infectious, then see if this Person
             * becomes exposed as a result of the contact.
             */
            if (p.isInfectious()) {
                /*
                 * This Person will be exposed with a probabilty
                 * given by the infectivity of the Disease.
                 */
                if (disease.getInfectivity()/100.0 > Math.random()) {
                    state = EXPOSED;
                    
                    /*
                     * No sense continuing since once this Person is
                     * exposed they are exposed... so just bail.
                     */
                    return;
                }
            }
        }
    }
    
    private void tickExposed(Disease disease) {
        incubationTicks++;
        latentTicks++;
        
        /*
         * If the disease has incubated long enough then this
         * Person will start to show symptoms.
         */
        if (incubationTicks >= disease.getIncubationPeriod()) {
            showingSymptoms = true;
        }
        
        /*
         * Go from exposed to infectious after being in the
         * exposed state for the duration of the latency period.
         */
        if (latentTicks >= disease.getLatencyPeriod()) {
            state = INFECTIOUS;
        }
    }
    
    private void tickInfectious(Disease disease) {
        incubationTicks++;
        infectiousTicks++;
        
        /*
         * If the disease has incubated long enough then this
         * Person will start to show symptoms.
         */
        if (incubationTicks >= disease.getIncubationPeriod()) {
            showingSymptoms = true;
        }
        
        /*
         * Go from infectious to removed after being infectious
         * for the duration of the infectious period.
         */
        if (infectiousTicks >= disease.getInfectiousPeriod()) {
            state = REMOVED;
            showingSymptoms = false;
        }
    }
    
    private void tickQuarantined(Disease disease) {
        infectiousTicks++;
        
        /*
         * Go from quarantined to removed as soon as the 
         * infectious period is over.
         */
        if (infectiousTicks >= disease.getInfectiousPeriod()) {
            state = REMOVED;
            showingSymptoms = false;
        }
    }
}
