/** 
 * 
 * This class implements the behavior of Tribbles that move, age, reproduce
 * and die.
 * With apologies to Mr. Spock and all of the Klingons ...
 * 
 * @author Tim Wahls
 * @author (YOUR NAME HERE)
 * @version (PUT DATE HERE)
 */

public class Tribble {

    // define your fields here
  
    /** 
     * initialize Tribble object to default values and set the Tribble
     * number. <br>
     * default color is green, default age is 0, default x position is 0 and
     *  default y position is 0
     * @param initTribNumber the tribble number 
     */
    public Tribble(int initTribNumber) {
        // add your code here, and in the body of each following
        // constructor and method
    }
  
   
    /**  
     * initialize Tribble number, color and location to the specified values<br>
     * all other fields are set to the defaults<br>
     * This constructor is used by TribbleGUI when a tribble reproduces
     *  
     *  @param initTribNumber the tribble number 
     *  @param initTribColor the color of the tribble
     *  @param initX the initial x position of the tribble
     *  @param initY the initial y position of the tribble
     */
    public Tribble(int initTribNumber, String initTribColor, int initX,
                   int initY) {
    }
  
    /**
     * return a String containing the number, position, age and
     *   color of the Tribble 
     * @return all information about the Tribble as a String
     */
    public String toString() {
        return "a tribble";
    }
  
    /**
     * return the x coordinate of the Tribble
     * @return the x coordinate 
     */
    public int getXPos() {
        return 0;
    }
     
    /**
     * return the y coordinate of the Tribble
     * @return the y coordinate 
     */    
    public int getYPos() {
        return 0;
    }

    /**
     * return the color of the Tribble
     * @return the color
     */      
    public String getColor() {
        return "green";
    }
    
    /**
     * return the number of the Tribble
     * @return the tribble number
     */
    public int getNumber() {
        return 0;
    }

    /**
     * return the age of the Tribble (in days)
     * @return the age of the Tribble (in days)
     */
    public int getAge() {
        return 0;
    }

    /** 
     * increase the age of the Tribble by one day
     */
    public void age() {
    }

    /**
     * move the Tribble up one "square". <br>
     * subtract 1 from the y coordinate, wrapping to the bottom of 
     * the world (15) if the y coordinate becomes negative
     */
    public void moveUp() {
    }
  
    /**
     * move the Tribble down one "square". <br>
     * add 1 to the y coordinate, wrapping to the top of 
     * the world (0) if the y coordinate exceeds 15 
     */
    public void moveDown() {
    }
  
    /**
      * move the Tribble left one "square". <br>
      * subtract 1 from the x coordinate, wrapping to the right side of 
      * the world (75) if the x coordinate becomes negative
      */
    public void moveLeft() {
    }
  
    /**
     * move the Tribble right one "square". <br>
     * add 1 to the x coordinate, wrapping to the left side of 
     * the world (0) if the x coordinate exceeds 75 
     */
    public void moveRight() {
    }
}
