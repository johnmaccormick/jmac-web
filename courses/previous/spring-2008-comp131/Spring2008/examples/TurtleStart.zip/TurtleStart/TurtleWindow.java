import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class TurtleWindow {

    JMenuItem newTurtle;

    /*
    public static void main(String[] args) {
    new TurtleWindow();
    }
    */
   
    public TurtleWindow() {

    JFrame window = new JFrame("Turtle Graphics");
    window.setResizable(false);

    Container windowPane = window.getContentPane();
    windowPane.setLayout(new BorderLayout());

    TurtlePanel tp = new TurtlePanel(10);
    windowPane.add(tp, BorderLayout.CENTER);
    TurtleControls tc = new TurtleControls(tp);
    windowPane.add(tc, BorderLayout.SOUTH);

    // Add a menu for creating a new turtle
    // This will call addTurtle in the TurtleControls
    JMenuBar menuBar = new JMenuBar();
    JMenu menu = new JMenu("Turtle");

    TurtleMenuHandler h = new TurtleMenuHandler(window,tc);

    newTurtle = new JMenuItem("New Turtle...");
    newTurtle.addActionListener(h);
    menu.add(newTurtle);

    JMenuItem i = new JMenuItem("Exit");
    i.addActionListener(h);
    menu.add(i);

    menuBar.add(menu);
    window.setJMenuBar(menuBar);

    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.pack();
    window.setVisible(true);
    }

    private class TurtleMenuHandler
    implements ActionListener {

    private JFrame w;
    private TurtleControls tc;

    public TurtleMenuHandler(JFrame window, TurtleControls cont) {
        w = window;
        tc = cont;
    }

    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        if (cmd.equals("Exit")) {
        System.exit(0);
        }
        else if (cmd.equals("New Turtle...")) {
        JDialog d = new TurtleDialog(w,tc);
        d.pack();
        //d.show(); deprecated in 1.5
        d.setVisible(true);

        if (tc.getNumTurtles() >= TurtleControls.MAX_TURTLES) {
            newTurtle.setEnabled(false);
        }
        }
    }
    }
}

    
