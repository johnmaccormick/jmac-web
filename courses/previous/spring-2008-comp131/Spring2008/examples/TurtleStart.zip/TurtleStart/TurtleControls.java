import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class TurtleControls extends JPanel {

    public static final int MAX_TURTLES = 5;

    TurtlePanel tp;
    Turtle[] turtles;
    int numTurtles;

    JPanel turtlePicker;
    JPanel moveRotPanel;
    JPanel penPanel;
    
    JComboBox turtleList;
    JButton forwardButton;
    JButton rotateButton;
    JTextField forwardPixels;    
    JTextField rotateDegrees;
    JComboBox penPositionList;

    public TurtleControls(TurtlePanel turtlePanel) {

        tp = turtlePanel;
        turtles = new Turtle[MAX_TURTLES];
        turtles[0] = new Turtle(); // Create default turtle.
        numTurtles = 1;
        tp.addTurtle(new Point((int)(Math.round(turtles[0].getX())),
            (int)(Math.round(turtles[0].getY()))),
            turtles[0].getColor());
        tp.setActiveTurtle(0,turtles[0]);
        
        BoxLayout controlsLayout = new BoxLayout(this,BoxLayout.X_AXIS);
        this.setLayout(controlsLayout);

        // TurtlePicker
        turtlePicker = new JPanel(new GridLayout(2,1,5,1));
        Border emptyBorder = BorderFactory.createEmptyBorder(10,10,10,10);
        turtlePicker.setBorder(emptyBorder);

        turtlePicker.add(new JLabel("Turtle:"));
    
        turtleList = new JComboBox();
        turtleList.addItem("Default");

        turtlePicker.add(turtleList);
    
        turtleList.addActionListener(new TurtleComboHandler());

        // Move & Rotate
        moveRotPanel = new JPanel(new GridLayout(2,3,1,5));

        forwardPixels = new JTextField("10",3);
        rotateDegrees = new JTextField("90",3);
    
        forwardButton = new JButton("Forward");
        Border buttonBorder = BorderFactory.createRaisedBevelBorder();
        forwardButton.setBorder(buttonBorder);
        forwardButton.addActionListener(new ForwardButtonHandler());

        rotateButton = new JButton("Rotate");
        rotateButton.setBorder(buttonBorder);
        rotateButton.addActionListener(new RotateButtonHandler());

        moveRotPanel.add(forwardButton);
        moveRotPanel.add(forwardPixels);
        moveRotPanel.add(rotateButton);
        moveRotPanel.add(rotateDegrees);
    
        // penPanel
        penPanel = new JPanel(new GridLayout(2,1,5,1));

        penPanel.add(new JLabel("Pen Position:"));
        penPanel.setBorder(emptyBorder);

        penPositionList = new JComboBox();
        penPositionList.addItem("Pen Up");
        penPositionList.addItem("Pen Down");
        penPositionList.addActionListener(new PenComboHandler());

        penPanel.add(penPositionList);
    
        this.add(turtlePicker);
        this.add(moveRotPanel);
        this.add(penPanel);
    }

    public int getNumTurtles() {
        return numTurtles;
    }

    public void addTurtle(String name, Turtle t) {
        turtleList.addItem(name);
        turtles[numTurtles] = t;
        tp.addTurtle(new Point((int)(Math.round(t.getX())),
            (int)(Math.round(t.getY()))),
            t.getColor());

        // Set new turtle to be active!
        tp.setActiveTurtle(numTurtles,t);
        turtleList.setSelectedIndex(numTurtles);

        tp.repaint();

        numTurtles++;
    }

    private class ForwardButtonHandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            // Move the currently selected turtle by the specified amount.
            // Also add a TurtleDropping to the TurtlePanel for the
            // currently selected turtle. Use null as the color
            // if the pen is up.
            int turtle = turtleList.getSelectedIndex();
        
            try {       
                turtles[turtle].moveForward(Integer.parseInt(forwardPixels.getText()));
            }
            catch (NumberFormatException nfe) {
                forwardPixels.setText("10");
                turtles[turtle].moveForward(10);
            }   

            Point p = new Point((int)(Math.round(turtles[turtle].getX())), 
                (int)(Math.round(turtles[turtle].getY())));
        
            if (turtles[turtle].isPenDown()) {
                tp.addDropping(turtle, p, turtles[turtle].getColor());
            }
            else {
                // null Color for pen up.
                tp.addDropping(turtle, p, null);
            }
        }
    }

    private class RotateButtonHandler implements ActionListener {
    
        public void actionPerformed(ActionEvent e) {

            // Rotate the currently selected turtle by the specified amount.
            int turtle = turtleList.getSelectedIndex();

            try {
                turtles[turtle].rotate(Integer.parseInt(rotateDegrees.getText()));
            }
            catch (NumberFormatException nfe) {
                rotateDegrees.setText("90");
                turtles[turtle].rotate(90);
            }
            tp.repaint();
        }
    }
    
    private class TurtleComboHandler implements ActionListener {
    
        public void actionPerformed(ActionEvent e) {

            // Change the currently active turtle in the TurtlePanel.
            // Also set the PenCombo to the pen state of the new turtle.
            int turtle = turtleList.getSelectedIndex();
            tp.setActiveTurtle(turtle,turtles[turtle]);
            if (turtles[turtle].isPenDown()) {
                penPositionList.setSelectedIndex(1);
            }
            else {
                penPositionList.setSelectedIndex(0);
            }
            tp.repaint();
        }
    }

   private class PenComboHandler implements ActionListener {

       public void actionPerformed(ActionEvent e) {

           // Change the pen state of the currently active turtle.
           int turtle = turtleList.getSelectedIndex();
           if (penPositionList.getSelectedIndex() == 1) {
               turtles[turtle].putPenDown();
            }
            else {
                turtles[turtle].pickPenUp();
            }
       }
   }
}