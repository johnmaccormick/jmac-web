import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.*;

public class TurtlePanel 
    extends JPanel {

    public static final int WIDTH = 300;
    public static final int HEIGHT = 200;
    public static final int BORDER = 15;

    private TurtleDroppingVector[] turtleDroppings;
    private int numTurtles;
    private int activeTurtleIndex;
    private Turtle activeTurtle;

    private static int[] arrowX = {0,0,10,10,15,10,10,0};
    private static int[] arrowY = {0,-2,-2,-5,0,5,2,2};

    private Color stringToColor(String c) {
        int i=0;
        while (i < TurtleDialog.colors.length && 
               !TurtleDialog.colors[i].equals(c)) {
            i++;
        }
        
        if (i >= TurtleDialog.colors.length) {
            return null;
        }
        else {
            return TurtleDialog.colorObjs[i];
        }
    }
    
    // Kind of a hack to get around problems with creating an
    // array of generic Vectors.
    private class TurtleDroppingVector extends Vector<TurtleDropping>{}
    
    private class TurtleDropping {
        public Point p;
        public Color c;
       
        public TurtleDropping(Point p, String c) {
            this.p = p;
            this.c = stringToColor(c);
        }
    }

    public TurtlePanel(int maxTurtles) {
        turtleDroppings = new TurtleDroppingVector[maxTurtles];
        numTurtles=0;
        activeTurtleIndex=0;

    Border loweredbevel = BorderFactory.createLoweredBevelBorder();
        this.setBorder(loweredbevel);
    }

    public void addTurtle(Point p, String c) {
        turtleDroppings[numTurtles] = new TurtleDroppingVector();
        turtleDroppings[numTurtles].addElement(new TurtleDropping(p,c));
        numTurtles++;
    }

    public void addDropping(int turtle, Point p, String c) {
        TurtleDropping d = new TurtleDropping(p,c);
        turtleDroppings[turtle].addElement(d);
        repaint();
    }

    public void setActiveTurtle(int turtle, Turtle t) {
        activeTurtleIndex = turtle;
        activeTurtle = t;
    }

    public Dimension getPreferredSize() {
        return new Dimension(WIDTH + 2*BORDER,HEIGHT + 2*BORDER);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setColor(Color.black);
        g.drawRect(BORDER-1,BORDER-1,WIDTH+1,HEIGHT+1);

        int px,py;
        int x, y;
        Color c;

        for (int t=0; t<numTurtles; t++) {
            px = ((TurtleDropping)(turtleDroppings[t].get(0))).p.x + BORDER;
            py = ((TurtleDropping)(turtleDroppings[t].get(0))).p.y + BORDER;

            for (int d=1; d<turtleDroppings[t].size(); d++) {
                x = ((TurtleDropping)(turtleDroppings[t].get(d))).p.x + BORDER;
                y = ((TurtleDropping)(turtleDroppings[t].get(d))).p.y + BORDER;
                c = ((TurtleDropping)(turtleDroppings[t].get(d))).c;

                // null color is pen up so no line!
                if (c != null) {
                    g.setColor(c);
                    g.drawLine(px,py,x,y);
                }

                px = x;
                py = y;
            }
        }

        // Draw arrowhead on the active turtle.
        paintArrow(g);
    }

    private void paintArrow(Graphics g) {
        // Get information about the location of the currently
        // active turtle so that we can draw it on the screen.
        double turtleX = activeTurtle.getX();
        double turtleY = activeTurtle.getY();
        double turtleTheta = activeTurtle.getAngle();
        String turtleColor = activeTurtle.getColor();
        
        int[] x = new int[arrowX.length];
        int[] y = new int[arrowY.length];

        double theta = Math.toRadians(turtleTheta);

        for (int c=0; c<x.length; c++) {
            x[c] = (int)Math.round(arrowX[c]*Math.cos(theta) +
                arrowY[c]*Math.sin(theta));
            y[c] = (int)Math.round(-arrowX[c]*Math.sin(theta) + 
                   arrowY[c]*Math.cos(theta));

            x[c] = x[c] + (int)(Math.round(turtleX)) + BORDER;
            y[c] = y[c] + (int)(Math.round(turtleY)) + BORDER;
        }

        g.setColor(stringToColor(turtleColor));
        g.fillPolygon(x,y,x.length);
    }
}
 
