
/**
 * Write a description of class AccountAnalyzer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AccountAnalyzer
{
    private Account account;
    
    public AccountAnalyzer()
    {
        account = new Account(10, 50);    
    }
    
    public void doAnalysis()
    {
        account.printAnnualInterest();
        account.addAnnualInterest();
//         account.balanceWithAnnualInterest();
    }
}
