public class Account {
	// MONTHLY interest rate in percentage points
	private double interestRate;
	// account balance in DOLLARS
	private double balance;

	public Account(double interestRate, double balance) {
		this.interestRate = interestRate;
		this.balance = balance;
	}

	public void printAnnualInterest() {
		double newBalance = balance;
		for (int i = 0; i < 12; i++) {
			newBalance = newBalance * (1 + interestRate / 100);
		}
		double annualInterest = newBalance - balance;
		System.out.println("annual interest is " + annualInterest);
	}

	public void addAnnualInterest() {
		double newBalance = balance;
		for (int i = 0; i < 12; i++) {
			newBalance = newBalance	* (1 + interestRate / 100);
		}
		balance = newBalance;
	}

}
