public class RefactoredAccount {
	// MONTHLY interest rate in percentage points
	private double interestRate;
	// account balance in DOLLARS
	private double balance;

	public RefactoredAccount(double interestRate, double balance) {
		this.interestRate = interestRate;
		this.balance = balance;
	}

	public void printAnnualInterest() {
		double newBalance = balanceWithAnnualInterest();
		double annualInterest = newBalance - balance;
		System.out.println("annual interest is " + annualInterest);
	}

	public void addAnnualInterest() {
		balance = balanceWithAnnualInterest();
	}

	private double balanceWithAnnualInterest() {
		double newBalance = balance;
		for (int i = 0; i < 12; i++) {
			newBalance = newBalance	* (1 + interestRate / 100);
		}
		return newBalance;
	}	
}
