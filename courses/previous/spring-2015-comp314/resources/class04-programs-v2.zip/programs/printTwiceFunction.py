# Python program printTwiceFunction.py
def printTwice(input):
    return input + input
