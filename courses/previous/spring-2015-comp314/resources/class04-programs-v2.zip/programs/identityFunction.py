# Python program identityFunction.py
def identity(input):
    return input
