command = "print 'abc', 5+2"
exec command
