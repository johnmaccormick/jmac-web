def containsZ(input):
    if "Z" in input:
        return "yes"
    else:
        return "no"
