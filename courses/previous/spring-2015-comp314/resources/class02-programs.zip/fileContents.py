def fileContents(filename):
    with open(filename) as inputFile:
        return inputFile.read()
