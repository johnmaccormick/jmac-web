#include <iostream>
#include "cpp-global-example2.h"

using namespace std;

int NUM_STUDENTS = 9;



int main(int argc, char** argv)
{
  cout << "The value of NUM_STUDENTS is " << NUM_STUDENTS << endl;

  print_num_students();
}
