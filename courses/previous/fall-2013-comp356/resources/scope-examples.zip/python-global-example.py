# copied from p226 of Sebesta, with slight alterations

day = "Monday"

def tester1():
    print "The global day is:", day

tester1()

exit()

def tester2():
    print "The global day is:", day
    day = "Tuesday"   
    print "The new value of day is:", day

tester2();

def tester3():
    global day
    print "The global day is:", day
    day = "Tuesday"   
    print "The new value of day is:", day

tester3();

