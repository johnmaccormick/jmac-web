class ScopeExample {
    public static int x = 3;

    private int y = 15;

    public static void f()
    {
	System.out.println(x);
    }

    public static void main(String[] args) {
	int x = 5;
	System.out.println(x);
	int y = 5;
	System.out.println(y);
	f();
	// for(int i=0; i<2; i++){
	//     int y = 43;
	//     System.out.println(y);
	// }
    }
}