void print_num_students();
