java -cp "cup.jar:."  JFlex.Main example.lex
java  -cp "cup.jar:." java_cup.Main example.cup
javac  -cp "cup.jar:." *.java
java  -cp "cup.jar:." parser < input.txt
