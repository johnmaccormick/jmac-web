import java.util.*;
import java.net.*;
import java.io.*;

/**
 * The StockDataReader makes available closing prices for a specified
 * stock (specified by its ticker symbol) from the Yahoo finance web site. 
 * When constructing a StockDataReader a starting date is specified.  Then
 * each successive call to getNextDaysData will fetch the stock data for 
 * the next weekday. When the data has been fetched for all days up to but
 * not including the current day, the hasMoreData method will return false.
 * So, the StockDataReader will not return data for the current day.
 * 
 * @author Grant Braught
 * @version October 2005
 */
public class StockDataReader
{
    private String tickerSymbol;
    private GregorianCalendar calendar;
    private boolean hasMoreData;
                              
    /**
     * Construct a new StockDataReader that starts on the specified
     * date and reads data for the stock specified by the tickerSymbol.
     * If the specified date occurs on a weekend, then reading will
     * begin on the first weekday following the specified date.
     * 
     * @param tickerSymbol the ticker symbol for the stock.
     * @param year the year in which to start reading.
     * @param the month in which to start reading.
     * @param the day of the month on which to start reading.
     */
    public StockDataReader(String tickerSymbol, int year, int month, int day) {
        this.tickerSymbol = tickerSymbol;
        calendar = new GregorianCalendar(year, month-1, day);
        
        // If the specified day is a weekend day then advance to the next
        // weekday.
        if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ||
            calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            advanceToNextWeekday(calendar);
        }
        
        if (calendar.after(new GregorianCalendar())) {
            hasMoreData = false;
        }
        else {
            hasMoreData = true;
        }
    }
    
    /**
     * Get the ticker symbol of the stock for which the 
     * prices have been fetched.
     * 
     * @return the ticker symbol.
     */
    public String getTickerSymbol() {
        return tickerSymbol;
    }
    
    /**
     * Get the year from which the next stock price
     * will be read.
     * 
     * @return the year.
     */
    public int getCurrentYear() {
        return calendar.get(Calendar.YEAR);
    }
    
    /**
     * Get the month from which the next stock price
     * will be read.  (Jan = 1, Feb = 2, etc...).
     * 
     * @return the month.
     */
    public int getCurrentMonth() {
        return calendar.get(Calendar.MONTH) + 1;
    }
    
    /**
     * Get the day of the month from which the next
     * stock price will be read.
     * 
     * @return the day.
     */
    public int getCurrentDay() {
        return calendar.get(Calendar.DAY_OF_MONTH);
    }
    
    /**
     * Returns true if there is more stock data that can be read
     * from this StockDataReader and false if not.  More data can
     * be read as long as the current date for this reader is 
     * still in the past.
     * 
     * @return true if more data is available and false otherwise.
     */
    public boolean hasMoreData() {
        return hasMoreData;
    }
    
    /**
     * This method returns the stock data from Yahoo Finance for the
     * current day and then advances the current day to the next 
     * day for which stock data is avaialble.
     * 
     * @return the stock data for the current day.
     */
    public StockData getNextDaysData() {
        
        StockData data = null;
        
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);
        
        // Setup the URL to fetch one day of data.
        String url = "http://ichart.finance.yahoo.com/table.csv?s=" + tickerSymbol + 
            "&d=" + month + "&e=" + day + "&f=" + year + "&g=d&a=" + 
            month + "&b=" + day + "&c=" + year + "&ignore=.csv";
        
        //System.out.println(url);
        
        try {
            URL stockURL = new URL(url);
            BufferedReader in = new BufferedReader(new InputStreamReader(stockURL.openStream()));

            String inputLine;
            // discard first line... it is header info.
            inputLine = in.readLine();
            
            inputLine = in.readLine();
            // Incoming data is Date,Open,High,Low,Close,Volume,Adj. Close
            //System.out.println(inputLine);
            
            // Parse the data into a StockData object.
            String[] rawValues = inputLine.split(",");
            double open = Double.parseDouble(rawValues[1]);
            double high = Double.parseDouble(rawValues[2]);
            double low = Double.parseDouble(rawValues[3]);
            double close = Double.parseDouble(rawValues[4]);
            int volume = Integer.parseInt(rawValues[5]);
            
            data = new StockData(year, month+1, day, 
                open, high, low, close, volume);
                
            in.close();
        }
        catch (FileNotFoundException fne) {
            // No data for the specified day - advance to the next day and
            // try again.
            advanceToNextWeekday(calendar);
            // Assume no future data or data for the current day.
            if (calendar.after(new GregorianCalendar()) ||
                calendar.equals(new GregorianCalendar())) {
                hasMoreData = false;
                System.out.println("Ran out of data while attempting to fetch next day's data.");
                System.exit(-1);
            }
            
            return getNextDaysData();
        }
        catch (Exception e) {
            // Some other problem!
            System.out.println("Unable to read stock data for " + tickerSymbol + ".");
            System.exit(-1);
        }
        
        advanceToNextWeekday(calendar);
        // Assume no future data or data for the current day.
        if (calendar.after(new GregorianCalendar()) ||
            calendar.equals(new GregorianCalendar())) {
            hasMoreData = false;
        }

        return data;
    }
    
    /**
     * Advance the calendar to the next weekday.
     */
    private static void advanceToNextWeekday(GregorianCalendar cal) {   
        int weekDays = 0;
        while (weekDays < 1) {            
            cal.add(Calendar.DATE, +1);
            if (cal.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY &&
                cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
                weekDays++;
            }
        }
    }
}
