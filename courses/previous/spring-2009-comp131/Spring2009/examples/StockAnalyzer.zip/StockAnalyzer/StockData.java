
/**
 * A StockData object holds one day of stock data.  This
 * includes the Date, the opening price, the high price for
 * the day, the low price for the day, the closing price,
 * the volume of trading and the adjusted closing price.
 * 
 * @author Grant Braught 
 * @version April 2006
 */
public class StockData
{
    private int year;
    private int month;
    private int day;
    
    private double openingPrice;
    private double highPrice;
    private double lowPrice;
    private double closingPrice;
    private int volume;

    /**
     * Constructor for objects of class StockData
     */
    public StockData(int year, int month, int day, 
        double openingPrice, double highPrice, double lowPrice, 
        double closingPrice, int volume) {
            
        this.year = year;
        this.month = month;
        this.day = day;
        this.openingPrice = openingPrice;
        this.highPrice = highPrice;
        this.lowPrice = lowPrice;
        this.closingPrice = closingPrice;
        this.volume = volume;
    }

    /**
     * Get the year.
     * @return the year.
     */
    public int getYear() {
        return year;
    }
    
    /**
     * Get the month. Jan=1, Feb=2, etc.
     * @return the month.
     */
    public int getMonth() {
        return month;
    }
    
    /**
     * Get the day of the month.
     * @return the day.
     */
    public int getDay() {
        return day;
    }
    
    /**
     * Get the opening price.
     * @return the opening price.
     */
    public double getOpeningPrice() {
        return openingPrice;
    }
    
    /**
     * Get the high price for the day.
     * @return the high price.
     */
    public double getHighPrice() {
        return highPrice;
    }
    
    /**
     * Get the low price for the day.
     * @return the low price.
     */
    public double getLowPrice() {
        return lowPrice;
    }
    
    /**
     * Get the closing price.
     * @return the closing price.
     */
    public double getClosingPrice() {
        return closingPrice;
    }

    /**
     * Get the trading volume.
     * @return the trading volume.
     */
    public int getVolume() {
        return volume;
    }
}
