/**
 * A class that demonstrates the differing meanings of "=="
 * and ".equals()"
 * 
 * @author jmac
 */
public class EqualityExamples {
	void AccountEqualityDemo() {
		Account a1 = new Account(5, 300);
		Account a2 = new Account(5, 300);
		Account a3 = a1;

		System.out.println("a1 details: " + a1.toString());
		System.out.println("a2 details: " + a2.toString());
		System.out.println("a3 details: " + a3.toString());
		System.out.println();
		System.out.println("Various equality tests:");

		if (a1 == a2) {
			System.out.println("a1 == a2 is true");
		} else {
			System.out.println("a1 == a2 is false");
		}

		if (a1.equals(a2)) {
			System.out.println("a1.equals(a2) is true");
		} else {
			System.out.println("a1.equals(a2) is false");
		}

		if (a1 == a3) {
			System.out.println("a1 == a3 is true");
		} else {
			System.out.println("a1 == a3 is false");
		}

		if (a1.equals(a3)) {
			System.out.println("a1.equals(a3) is true");
		} else {
			System.out.println("a1.equals(a3) is false");
		}
	}

	void stringEqualityDemo() {
		String s0 = "abc";
		String s1 = s0 + "d";
		String s2 = "abcd"; // same characters as s1,
		// but compiler will store in a
		// separate object
		String s3 = s1;

		System.out.println("s1 is " + s1);
		System.out.println("s2 is " + s2);
		System.out.println("s3 is " + s3);
		System.out.println();
		System.out.println("Various equality tests:");

		if (s1 == s2) {
			System.out.println("s1 == s2 is true");
		} else {
			System.out.println("s1 == s2 is false");
		}

		if (s1.equals(s2)) {
			System.out.println("s1.equals(s2) is true");
		} else {
			System.out.println("s1.equals(s2) is false");
		}

		if (s1 == s3) {
			System.out.println("s1 == s3 is true");
		} else {
			System.out.println("s1 == s3 is false");
		}

		if (s1.equals(s3)) {
			System.out.println("s1.equals(s3) is true");
		} else {
			System.out.println("s1.equals(s3) is false");
		}
	}
}
