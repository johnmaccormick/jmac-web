/**
 * A very simple bank account model, which will be used for
 * demonstrating the use of .equals() methods
 * 
 * @author jmac
 */
public class Account {
    // annual percentage interest rate
    int interestRate;
    // account balance measured in cents
    int balance;

    /**
     * Create new account with given interest rate and
     * balance
     */
    public Account(int interestRate, int balance) {
        this.interestRate = interestRate;
        this.balance = balance;
    }

    /**
     * @return the interestRate
     */
    public int getInterestRate() {
        return interestRate;
    }

    /**
     * @return the balance
     */
    public int getBalance() {
        return balance;
    }

    /**
     * Return a string describing the details of the calling
     * object
     */
    public String toString() {
        return "interestRate is " + interestRate
                + ",  balance is " + balance;
    }

	/**
	 * Return true if the calling object and otherAccount
	 * have the same interest rate and balance, and false
	 * otherwise.
	 */
    public boolean equals(Account otherAccount) {
        if (this.interestRate == otherAccount.interestRate
                && this.balance == otherAccount.balance) {
            return true;
        } else {
            return false;
        }
    }
}
