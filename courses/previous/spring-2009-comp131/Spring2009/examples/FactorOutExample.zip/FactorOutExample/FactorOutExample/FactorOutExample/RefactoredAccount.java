/**
 * A simple model of a bank account to demonstrate the
 * concept of factoring out repeated code. In this class,
 * the repeated code in the Account class has been factored
 * out into a new method, meaning that this class is easier
 * to maintain.
 * 
 * @author jmac
 */
public class RefactoredAccount {
	// MONTHLY interest rate in percentage points
	private double interestRate;
	// account balance in DOLLARS
	private double balance;

	/**
	 * Create a new Account with the given interest rate and
	 * balance.
	 */
	public RefactoredAccount(double interestRate, double balance) {
		this.interestRate = interestRate;
		this.balance = balance;
	}

	/**
	 * Print the amount of interest this account would
	 * receive in one year
	 */
	public void printAnnualInterest() {
		double annualInterest = computeAnnualInterest();
		System.out.println("annual interest is " + annualInterest);
	}

	/**
	 * Add the amount of annual interest to the current
	 * balance.
	 */
	public void addAnnualInterest() {
		balance = balance + computeAnnualInterest();
	}

	/**
	 * Return the amount of interest this account would
	 * receive in one year
	 */
	public double computeAnnualInterest() {
		double newBalance = balance;
		for (int i = 0; i < 12; i++) {
			newBalance = newBalance	* (1 + interestRate / 100);
		}
		return newBalance - balance;
	}
}
