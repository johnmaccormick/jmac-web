/**
 * A simple model of a bank account to demonstrate the concept
 * of factoring out repeated code. This class contains some
 * repeated code, and is therefore difficult to maintain.
 * 
 * @author jmac
 */
public class Account {
	// MONTHLY interest rate in percentage points
	private double interestRate;
	// account balance in DOLLARS
	private double balance;

	/**
	 * Create a new Account with the given interest rate and
	 * balance.
	 */
	public Account(double interestRate, double balance) {
		this.interestRate = interestRate;
		this.balance = balance;
	}

	/**
	 * Print the amount of interest this account would
	 * receive in one year
	 */
	public void printAnnualInterest() {
		double newBalance = balance;
		for (int i = 0; i < 12; i++) {
			newBalance = newBalance	* (1 + interestRate / 100);
		}
		double annualInterest = newBalance - balance;
		System.out.println("annual interest is " + annualInterest);
	}

	/**
	 * Add the amount of annual interest to the current
	 * balance.
	 */
	public void addAnnualInterest() {
		double newBalance = balance;
		for (int i = 0; i < 12; i++) {
			newBalance = newBalance	* (1 + interestRate / 100);
		}
		balance = newBalance;
	}

}
