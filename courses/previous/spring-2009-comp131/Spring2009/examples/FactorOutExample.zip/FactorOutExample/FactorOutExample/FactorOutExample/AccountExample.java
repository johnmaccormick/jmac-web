/**
 * A simple class that uses RefactoredAccount objects. The
 * point of this class is to demonstrate the effect of
 * changing methods in the RefactoredAccount class from
 * "public" to "private"
 * 
 * @author jmac
 */
public class AccountExample {

	/**
	 * The constructor creates a new RefactoredAccount
	 * object and calls some of its methods
	 */
	public AccountExample() {
		RefactoredAccount account = new RefactoredAccount(
				5.2, 2100.00);
		account.printAnnualInterest();
		account.addAnnualInterest();
		double interest = account.computeAnnualInterest();
		System.out.println("Interest is " + interest);
	}
}
