
/**
 * A class to represent courses at a college.  Courses have a department, number,
 * semester, year, meeting time, meeting place and instructor.
 * 
 * @author Tim Wahls
 * @version 4/6/2006
 */
public class Course
{
	private String department; // for example: COSCI
	private int number; // for example: 131
	private String semester; // for example: Fall or Spring
	private int year;
	private String meetingTime; // for example: MWF 10:30
	private String meetingPlace; // for example: Tome 118
	private String instructor;
	

	/**
	 * Create a new course.
	 * 
	 * @param initDept the department
	 * @param initNumber the course number
	 * @param initSem the semester
	 * @param initYear the year
	 * @param initMeetTime the meeting time
	 * @param initMeetPlace the meeting place
	 * @param initInst the instructor
	 */
	public Course(String initDept, int initNumber, String initSem, int initYear,
	              String initMeetTime, String initMeetPlace, String initInst)
	{
		department = initDept;
		number = initNumber;
		semester = initSem;
		year = initYear;
		meetingTime = initMeetTime;
		meetingPlace = initMeetPlace;
		instructor = initInst;
	}

	/**
	 * get the department of the course
	 * @return the department
	 */
	public String getDepartment()
	{
		return department;
	}
	
	/**
	 * get the course number
	 * @return the course number
	 */
	public int getNumber() {
	    return number;
	}

	/**
	 * get the meeting place of the course
	 * @return the semester
	 */
	public String getSemester()
	{
		return semester;
	}
	
	/**
	 * get the course year
	 * @return the course year
	 */
	public int getYear() {
	    return year;
	}

	/**
	 * get the meeting time of the course
	 * @return the meeting time
	 */
	public String getMeetingTime()
	{
		return meetingTime;
	}	
	
	/**
	 * get the meeting place of the course
	 * @return the meeting place
	 */
	public String getMeetingPlace()
	{
		return meetingPlace;
	}

	/**
	 * get the instructor of the course
	 * @return the instructor
	 */
	public String getInstructor()
	{
		return instructor;
	}	
	
	/**
	 * change the instructor of the course
	 * @param newInstructor the new instructor
	 */
	public void setInstructor(String newInstructor) {
	    instructor = newInstructor;
	}
	
	/**
	 * get all info about the course as a String
	 * @return all info about the course as a String
	 */
	public String toString() {
	    return department + " " + number + ", " + semester + " " + year +
	           ", " + meetingTime + " " + meetingPlace + ", " + instructor;
	}
}
