import java.util.ArrayList;

/**
 * A class to represent students at a college.  Students have a name, student id
 * number, graduation year, GPA and a schedule, which is a collection of courses.
 * 
 * @author Tim Wahls
 * @version 4/9/2006
 */
public class Student
{
	private String name;
	private String studentID;
	private int graduationYear;
	private double gpa;
	private ArrayList<Course> schedule;

	/**
	 * Create a new student.  A new student is not taking any courses.
	 * 
	 * @param initName the student name
	 * @param initID the student ID
	 * @param initGradYear the graduation year
	 * @param initGPA the GPA
	 */
	public Student(String initName, String initID, int initGradYear, double initGPA)
	{
		name = initName;
		studentID = initID;
		graduationYear = initGradYear;
		gpa = initGPA;
		schedule = new ArrayList<Course>();
	}

	/**
	 * get the student's name
	 * @return the student's name
	 */
	public String getName()	{
		return name;
	}

	/**
	 * get the student's ID
	 * @return the student's ID
	 */
	public String getStudentID()	{
		return studentID;
	}

	/**
	 * get the student's graduation year
	 * @return the student's graduation year
	 */
	public int getGraduationYear()	{
		return graduationYear;
	}
	
	/**
	 * get the student's GPA
	 * @return the student's GPA
	 */
	public double getGPA()	{
		return gpa;
	}	
	
	/**
	 * set the student's GPA
	 * @param newGPA the new GPA
	 */
	public void setGPA(double newGPA)	{
		gpa = newGPA;
	}	
	
	/**
	 * get the number of courses that the student is taking
	 * @return the number of courses that the student is taking
	 */
	public int getNumberOfCourses() {
	    return schedule.size();
	}
	
	/** 
	 * add a course to the student's schedule
	 * @param newCourse the course to add
	 */
	public void addCourse(Course newCourse) {
	    schedule.add(newCourse);
	}
	
	/**
	 * return the index of a course in a student's schedule, or -1 if the course
	 * does not occur
	 * @param department the department of the course
	 * @param number the number of the course
	 * @return the index of a course in a student's schedule, or -1 if the course
	 * does not occur
	 */
	private int findCoursePosition(String department, int number) {
	    int pos = 0;
    	boolean found = false;
	    while (pos < schedule.size() && !found) {
	        Course current = schedule.get(pos);
	        if (department.equals(current.getDepartment()) &&
	            number == current.getNumber()) {
	            found = true;
	        } else {
	            pos++;
	        }
	    }
	    if (found) {
	        return pos;
	    } else {
	        return -1;
	    }
	}
	
	/**
	 * check whether the student is taking the specified course
	 * @param department the department of the course
	 * @param number the number of the course
	 * @return whether or not the student is taking the course
	 */
	public boolean isTaking(String department, int number) {
	    return findCoursePosition(department, number) != -1;
	}
	
	/**
	 * drop a course from the student's schedule.  Display an error message if
	 * the student is not taking the specified course.
	 * 
	 * @param department the department of the course
	 * @param number the number of the course
	 */
	public void dropCourse(String department, int number) {
	    int pos = findCoursePosition(department, number);
	    if (pos > -1) {
	        // course was found, pos is its index
	        schedule.remove(pos);
	    } else {
	        System.out.println("Error: " + name + " is not taking " + department + " " + number + ".");
	    }
	}
	
	/**
	 * get all information about the student 
	 * @return all student information in a String
	 */
	public String toString() {
	    String res = name + " (student ID: " + studentID + ") has a GPA of " + gpa +
	                 ", is graduating in " + graduationYear + " and is taking:\n";
	    for (int c=0; c < schedule.size(); c++) {
	        Course nextCourse = schedule.get(c);
	        res = res + nextCourse.toString() + "\n";
	    }
	    return res;
	}
	
	/** 
	 * display all information about the student in the terminal window
	 */
	public void print() {
	    System.out.println(toString());
	}
	
	/**
	 * return the standing (senior, junior, ...) of the student given the
	 * current year
	 * @param year the current year
	 */
	public String getStanding(int year) {
	    int yearsLeft = graduationYear - year;
	    if (yearsLeft == 0) {
	        return "senior";
	    } else if (yearsLeft == 1) {
	        return "junior";
	    } else if (yearsLeft == 2) {
	        return "sophomore";
	    } else if (yearsLeft == 3) {
	        return "first year";
	    } else {
	        // should check that yearsLeft < 0
	        return "alumnus";
	    }
	}
}
