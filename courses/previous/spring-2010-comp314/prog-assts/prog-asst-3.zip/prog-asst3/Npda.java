import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;

/**
 * An Npda object models a nondeterministic pushdown
 * automaton(npda). Please see the book <i>An Introduction
 * to Formal Languages and Automata</i>, by Peter Linz, for
 * a detailed description of npdas.
 * 
 * <P>
 * An Npda object has the capability of reading an npda from
 * a text file. An example of the format of an npda text
 * file is as follows (this file accepts the language a^n
 * b^n for n>=0):
 * 
 * <BLOCKQUOTE><TT>transitions<br>
 * Q0 Q1 a Z 1Z<br>
 * Q1 Q1 a 1 11<br>
 * Q1 Q2 L 1 1<br>
 * Q2 Q2 b 1 L<br>
 * Q2 Q3 L Z Z<br>
 * finalStates<br>
 * Q0 Q3</TT></BLOCKQUOTE>
 * <P>
 * 
 * The file consists of two sections: (i) a section listing
 * the npda's transitions, which starts with a line
 * consisting of the string "transitions"; (ii) a section
 * listing the npda's final states, which starts with a line
 * consisting of the string "finalStates".
 * 
 * <P>
 * The transitions section specifies one transition per
 * line. Each transition is specified by five strings
 * separated by whitespace. The five strings represent,
 * respectively: (i) the label of the state where the
 * transition begins; (ii) the label of the state where the
 * transition ends; (iii) the symbol read from the input
 * string; (iv) the symbol popped from the stack; (v) the
 * symbol(s) pushed onto the stack. The initial state of the
 * npda is hardwired as "Q0". Conventionally, the other
 * states are named "Q1", "Q2" etc., but this is not
 * enforced. The string alphabet, stack alphabet, and list
 * of labels for the npda are not defined explicitly;
 * rather, they are defined to be everything that is
 * encountered in the transitions section of the npda file.
 * <P>
 * Three special symbols are defined: 'Z' is the stack start
 * symbol; 'L' represents lambda, the empty symbol; and 'I'
 * represents an illegal symbol i.e. a symbol that is not in
 * the string alphabet or stack alphabet (this illegal
 * symbol does not form part of the usual definition of an
 * npda, but can be useful for implementing an npda).
 * <P>
 * It is suggested that the string alphabet consists only of
 * lowercase letters, and the stack alphabet consists only
 * of the digits 0-9 (and Z). However, this suggestion is
 * not enforced.
 * <P>
 * The finalStates section consists of a single line (in
 * addition to the line marking the start of the section).
 * This line contains a sequence of strings separated by
 * whitespace, where each string is the name of a label that
 * is a final state of the npda.
 * 
 * 
 * @author jmac
 * @date April 2010
 * 
 */
public class Npda {

	/**
	 * The label of the initial state of the npda.
	 */
	public static final String INITIAL_STATE = "Q0";
	/**
	 * Special symbol representing the empty symbol
	 */
	public static final char LAMBDA = 'L';
	/**
	 * Special symbol representing the stack start symbol
	 */
	public static final char STACK_START = 'Z';
	/**
	 * Special symbol representing an illegal symbol -- see
	 * the class documentation for more discussion of this.
	 */
	public static final char ILLEGAL = 'I';

	// A map containing the vertices in the npda. The keys
	// are the labels of the vertices (e.g. Q0, Q1, Q2), and
	// the values are the corresponding NpdaVertex objects.
	private HashMap<String, NpdaVertex> vertices;

	// A set containing the labels (e.g. Q0, Q1) of the
	// final states of the npda.
	private Set<NpdaVertex> finalStates;

	// When reading the npda from a file, lineNumber stores
	// the number of the most recently read line.
	private int lineNumber;

    // PROGASST3: add fields here if you wish, but the assignment
    // can be completed without adding any fields.  Hint: do not add
    // a field for the stack of the npda, since you will need a
    // different stack for each nondeterministic choice.


	/**
	 * Create a new, empty npda object
	 */
	public Npda() {
		vertices = new HashMap<String, NpdaVertex>();
		finalStates = new HashSet<NpdaVertex>();
		lineNumber = 0;
	}

	/**
	 * Read a description of the npda from a file. Please
	 * see the documentation of the npda class for a
	 * description of the file format.
	 * 
	 * @param filename
	 *            the name of the file to be read
	 * @throws FileNotFoundException
	 *             if the file isn't found
	 * @throws NpdaException
	 *             if the contents of the file does not
	 *             represent a legal npda
	 */
	public void readFromFile(String filename)
			throws FileNotFoundException, NpdaException {
		Scanner scanner = null;
		try {
			File file = new File(filename);
			scanner = new Scanner(file);
			readTransitions(scanner);
			readFinalStates(scanner);
		} finally {
			// ensure the underlying stream is always closed
			if (scanner != null)
				scanner.close();
		}

	}

	// Read the transitions from the npda file. The given
	// scanner is assumed to be at the very start of the
	// file, so the first line read should be "transitions"
	private void readTransitions(Scanner scanner)
			throws NpdaException {
		// read the first line, which should be
		// "transitions"
		checkForLine(scanner);
		lineNumber++;
		String line = scanner.nextLine();
		if (!line.equals("transitions")) {
			throw new NpdaException(
					"expected 'transitions' at line "
							+ lineNumber);
		}

		// read the transition information, which is
		// described by one line per transition. When the
		// transitions end, we encounter the list of final
		// states which are marked by the line "finalStates"
		boolean finishedTransitions = false;
		while (!finishedTransitions) {
			checkForLine(scanner);
			lineNumber++;
			line = scanner.nextLine();
			if (line.equals("finalStates")) {
				finishedTransitions = true;
			} else {
				processTransition(line);
			}
		}

		// check that the npda has a valid initial state
		if (!vertices.containsKey(INITIAL_STATE)) {
			throw new NpdaException(
					"finished processing transitions, but initial state "
							+ INITIAL_STATE
							+ " was not found");
		}

	}

	// process a single transition in the npda file (which
	// is specified by the given line of the file), by
	// adding the relevant information to this Npda object
	private void processTransition(String line)
			throws NpdaException {
		// split the line on whitespace
		String[] elements = line.split("\\s+");
		// the line should contain exactly 5 elements: the
		// source label, destination label, read symbol,
		// pop symbol, and push symbols
		if (elements.length != 5) {
			throw new NpdaException("transition at line "
					+ lineNumber
					+ " does not contain five elements");
		}
		String source = elements[0];
		String dest = elements[1];
		String readSymbolString = elements[2];
		String popSymbolString = elements[3];
		String pushSymbols = elements[4];

		if (readSymbolString.length() != 1) {
			throw new NpdaException(
					"transition at line "
							+ lineNumber
							+ " contains a read symbol that is not exactly 1 character.");
		}
		if (popSymbolString.length() != 1) {
			throw new NpdaException(
					"transition at line "
							+ lineNumber
							+ " contains a pop symbol that is not exactly 1 character.");
		}

		char readSymbol = readSymbolString.charAt(0);
		char popSymbol = popSymbolString.charAt(0);

		// add the vertices to the npda
		addVertex(source);
		addVertex(dest);

		// add the transition to the source vertex
		addTransition(source, dest, readSymbol, popSymbol,
				pushSymbols);
	}

	// add a new vertex with the given label if it is not
	// already present
	private void addVertex(String label) {
		if (!vertices.containsKey(label)) {
			NpdaVertex v = new NpdaVertex(label);
			vertices.put(label, v);
		}
	}

	// add a new transition with the given source label,
	// transition symbol, and destination label
	private void addTransition(String sourceString,
			String destString, char readSymbol,
			char popSymbol, String pushSymbols)
			throws NpdaException {
		NpdaVertex source = vertices.get(sourceString);
		NpdaVertex dest = vertices.get(destString);
		if (source == null) {
			throw new NpdaException(
					"source of transition at line "
							+ lineNumber
							+ " does not exist.");
		}
		if (dest == null) {
			throw new NpdaException(
					"destination of transition at line "
							+ lineNumber
							+ " does not exist.");
		}
		NpdaTransition t = new NpdaTransition(source, dest,
				readSymbol, popSymbol, pushSymbols);
		source.addTransition(t);
	}

	// read the list of final states from the npda file and
	// store them in this Npda object. When this method is
	// called, the scanner has already read the line
	// "finalStates", so it need only read the single line
	// containing the final state labels themselves.
	private void readFinalStates(Scanner scanner)
			throws NpdaException {
		// read the next line
		checkForLine(scanner);
		lineNumber++;
		String line = scanner.nextLine();

		// split on whitespace
		String[] elements = line.split("\\s+");

		// add each label to the set of final states
		for (String label : elements) {
			if (!vertices.containsKey(label)) {
				throw new NpdaException("final state "
						+ label + " is not a valid vertex");
			}
			finalStates.add(vertices.get(label));
		}
	}

	// check that another line is available to be read
	private void checkForLine(Scanner scanner)
			throws NpdaException {
		if (!scanner.hasNextLine()) {
			throw new NpdaException(
					"Unexpected end of file at line "
							+ lineNumber);
		}

	}

    // PROGASST3: add private methods here


	/**
	 * Return true if this npda accepts the given string,
	 * and false otherwise.
	 */
	public boolean accepts(String input) {
        // PROGASST3:  edit the body of this method
        return false;
	}

	public static void main(String[] args) {
		Npda pda = new Npda();
		try {
			pda.readFromFile("testpda.txt");
			String[] testCases = { "", "a", "b", "aa",
					"bb", "ab", "ba", "aaa", "bba", "aba",
					"baa", "aab", "bbb", "abb", "bab",
					"aaaa", "bbaa", "abaa", "baaa", "aaba",
					"bbba", "abba", "baba", "aaab", "bbab",
					"abab", "baab", "aabb", "bbbb", "abbb",
					"babb", "aaaaaaaaa", "aaaaaaaaab",
					"aaaaabbbbb", "aaaaaabbbbb",
					"aaaaabbbbbb" };
			for (String testCase : testCases) {
				boolean accepted = pda.accepts(testCase);
				System.out.println(testCase + ": "
						+ accepted);
			}
		} catch (FileNotFoundException e) {
			System.err.println(e);
		} catch (NpdaException e) {
			System.err.println(e);
		}
	}

}