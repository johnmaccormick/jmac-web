/**
 * An NpdaException is thrown by unexpected errors in npda
 * code. NpdaExceptions behave exactly like Exception
 * objects; all inherited methods call the superclass method
 * and do nothing else.
 * 
 * @author jmac
 * 
 */
public class NpdaException extends Exception {

	public NpdaException() {
	}

	public NpdaException(String message) {
		super(message);
	}

	public NpdaException(Throwable cause) {
		super(cause);
	}

	public NpdaException(String message, Throwable cause) {
		super(message, cause);
	}

}
