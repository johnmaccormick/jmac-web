import java.util.HashMap;

/**
 * A DfaVertex object models a single vertex in a dfa. This
 * includes a label for the vertex, such as Q0, Q1, or Q2,
 * and a set of transitions from the vertex to other
 * vertices.
 * 
 * @author jmac
 * 
 */
public class DfaVertex {
	// the label of this vertex e.g. Q0, Q1, Q2
	private String label;

	// A map containing all the transitions from this vertex
	// to other vertices. The key is the symbol of the
	// transition (e.g. a,b,c), and the value is the label
	// of the vertex which is the destination of the
	// transition.
	private HashMap<String, String> transitions;

	/**
	 * Create a new vertex with the given label. (e.g. Q0,
	 * Q1, Q2)
	 */
	public DfaVertex(String label) {
		this.label = label;
		this.transitions = new HashMap<String, String>();
	}

	/**
	 * Add a new transition from this vertex to some other,
	 * destination vertex.
	 * 
	 * @param symbol
	 *            the symbol (e.g. a,b,c) that causes the
	 *            transition
	 * @param dest
	 *            the label of the destination vertex for
	 *            the transition
	 */
	public void addTransition(String symbol, String dest) {
		transitions.put(symbol, dest);
	}

	/**
	 * Find out the destination vertex to which the given
	 * symbol will cause a transition.
	 * 
	 * @param symbol
	 *            the symbol (e.g. a,b,c) that causes the
	 *            transition
	 * @return the label of the destination vertex for the
	 *         transition
	 */
	public String getTransition(String symbol) {
		return transitions.get(symbol);
	}

	/**
	 * return the label of this vertex
	 */
	public String getLabel() {
		return label;
	}

}
