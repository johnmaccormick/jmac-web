/**
 * A DfaException is thrown by unexpected errors in dfa
 * code. DfaExceptions behave exactly like Exception
 * objects; all inherited methods call the superclass method
 * and do nothing else.
 * 
 * @author jmac
 * 
 */
public class DfaException extends Exception {

	public DfaException() {
	}

	public DfaException(String message) {
		super(message);
	}

	public DfaException(Throwable cause) {
		super(cause);
	}

	public DfaException(String message, Throwable cause) {
		super(message, cause);
	}

}
