/** An exception that is thrown when no car with the specified VIN is in 
    inventory. */

public class NoSuchCarException extends Exception {

    /** initialize and return a new exception with no message */
    public NoSuchCarException() {}

    /** initialize and return a new exception with the indicated message */
    public NoSuchCarException(String msg) {
        super(msg);
    }
}
