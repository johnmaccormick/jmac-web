import java.util.Scanner;
import java.util.ArrayList;

/**
 * A class to represent a car dealership.
 * 
 * @author Tim Wahls
 * @version 1/09/2009 (modified 12/14/2009)
 */

public class CarDealership {
	private ArrayList<SalableVehicle> carLot;  // inventory
	private String name; // name of the dealership

	/** initialize a default car dealership */
	public CarDealership() {
		carLot = new ArrayList<SalableVehicle>();
		name = null;
	}

	/** initialize a dealership with the specified name
	 * 
	 * @param name the name of the dealership
	 */
	public CarDealership(String name) {
		carLot = new ArrayList<SalableVehicle>();
		this.name = name;
	}

	/** @return the name of the dealership */
	public String getName() {
		return name;
	}

	/** change the name of the dealership
	 * 
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/** add the car to the lot 
	 * @param c the car to add
	 */
	public void addCar(SalableVehicle c) {
		carLot.add(c);
	}

	/** print all cars on the lot */
	public void showCars() {
		System.out.println(name + " has in stock TODAY at low low prices:");
		for (SalableVehicle c : carLot) {
			System.out.println(c);
		}
	}

        /** return the car with the specified VIN
            @throws NoSuchCarException if no car with that VIN is 
                    in inventory */
        public SalableVehicle findCar(String vin) throws NoSuchCarException {
 	    for (SalableVehicle c : carLot) {
	        if (c.getVin().equals(vin)) {
                    return c;
                }
	    }
            throw new NoSuchCarException("Error: no car with specified VIN");
        }

        /** sell the car with the specified VIN (remove it from inventory)
            @throws NoSuchCarException if no car with that VIN is 
                    in inventory */
        public void sellCar(String vin) throws NoSuchCarException {
 	    for (SalableVehicle c : carLot) {
	        if (c.getVin().equals(vin)) {
                    carLot.remove(c);
                    return;
                }
	    }
            throw new NoSuchCarException("Error: no car with specified VIN");
        }

	public static void main(String argv[]) throws NoSuchCarException {

	}
}
