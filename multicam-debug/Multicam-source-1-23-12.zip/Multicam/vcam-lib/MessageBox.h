// Copyright John MacCormick 2012. Modified BSD license. NO WARRANTY.
#pragma once
const int MSG_STRING_MAXLEN = 1024;
void Msg(CHAR *szFormat, ...);