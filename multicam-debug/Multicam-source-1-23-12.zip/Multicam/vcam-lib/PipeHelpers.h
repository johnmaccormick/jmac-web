// Copyright John MacCormick 2012. Modified BSD license. NO WARRANTY.
char *MULTICAM_KEYPRESS_PIPE_NAME = "\\\\.\\pipe\\MulticamKeypressPipe";