package wcbc;

/**
 * SISO program TrueInPeano.java
 * 
 * This is only an oracle function; no implementation is provided.
 * 
 */
public class TrueInPeano implements Siso {

	@Override
	public String siso(String inString) {
		return "not implemented";
	}

}
