# SISO program crashOnString.py

# This is only an oracle function; no implementation is provided.
import utils; from utils import rf
def crashOnString(p,x):    
    pass                   

def testcrashOnString():
    # There is nothing meaningful to assert in this test, because
    # crashOnString is an oracle function that does nothing in our
    # implementation.
    crashOnString('asdf', 'ghjk')
