# SISO program trueInPeano.py

# This is only an oracle function; no implementation is provided.
import utils; from utils import rf
def trueInPeano(inString):
    return 'not implemented'


def testtrueInPeano():
    # Nothing to assert. Just execute the function.
    trueInPeano('asdf')
    
